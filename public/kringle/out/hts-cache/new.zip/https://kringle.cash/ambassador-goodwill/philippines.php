<html>
<title>Kringle.Cash</title>
<head>
    <meta http-equiv="Content-Type" content="application/xhtml+xml; charset=UTF-8" />
    <link rel="shortcut icon" href="favicon.ico" />
    <!-- mobile settings -->
    <meta name="viewport" content="width=device-width, maximum-scale=1, initial-scale=1, user-scalable=0" />	
    <meta property="og:image" content="https://kringle.cash/images/linkimage2c.jpg" />
	<meta property="og:description" content="Become a Millionaire automatically FREE of CHARGE.   This Cash Giveaway expires soon!  Click NOW and collect your GIFT!" />
	<meta property="og:url" content="https://kringle.cash/" />
    <meta property="og:title" content="Kringle.Cash" />
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css"/>
      
      <script type="text/javascript" src="js/jquery.js"></script> 
	  <script type="text/javascript" src="js/bootstrap.js"></script>
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
	<style>

	</style>
    <link href="css/style.css" media="screen" rel="stylesheet" type="text/css">
    <link href="css/ownstyle.css" media="screen" rel="stylesheet" type="text/css">
    <link href="css/mystyle.css" media="screen" rel="stylesheet" type="text/css">
    <link href="css/info1.css" media="screen" rel="stylesheet" type="text/css">
    <script type="text/javascript">
        function googleTranslateElementInit() {
            new google.translate.TranslateElement({pageLanguage: 'en', layout: google.translate.TranslateElement.InlineLayout.SIMPLE}, 'google_translate_element');
        }
    </script>
    <script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
    <!--<div id="google_translate_element"></div>-->
    <style>
        .goog-te-menu-value img {
           display: none;
        }
        .goog-te-gadget-simple img {
        background-image: url('images/KringleCoin.gif')!important;
        }
    </style>
</head>
<body>
<header>
    <div class="header-top" id="menuUser">
        <div class="container">
            <div class="row">
                <div class="col">
                <!--<div class="col-sm-2 col-xs-12" style="width: 13.666667%;    margin-top: -3px;" id="google_translate_element">
                </div>-->
                <div class="float-right" style="display: inline-block;margin-right: 16px;height: 36px;float: right;">
                    <div id="google_translate_element"></div>
                </div>
                    </div>
            </div>
        </div>
    </div>
</header>


<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://fonts.googleapis.com/css2?family=Fugaz+One&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Roboto+Condensed&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/grid-gallery.min.css">
    <link rel="stylesheet" href="css/style.css?20210128">
    <title>Kluv Coin</title>
  </head>

  <body>

  <div class="goodwill-box d-flex align-center justify-space-around">
    <div class="box">
      <h2>Nonito Rabel has Accepted the Call to Become the Goodwill Ambassador of the Philippines</h2>
      <img src="https://www.kluvcoin.io/img/nonito-rabel.jpg" />
      <p>
        Nonito Rabel is a Leader that really stands out within the Kringle Community for his selfless 
        service among Filipinos.  In fact he has served all of us to a fault.  Far too often we have 
        heard of him going way beyond the call of duty to help anyone that comes across his path within 
        our community with practically no regard to his time or personal pocketbook.  We wonder how he 
        can keep this up, because he gives so much of himself to this cause of ours.  His fellow 
        Filipinos cheered with great joy when they first heard the announcement that Nonito Rabel would 
        be our next Goodwill Ambassador.  We have spent most of the year 2022 supporting the fastest 
        growing countries within the Kringle Society and now it is time to branch out to other countries 
        like the Philippines, a place well known for its friendly and sweet people.  Our Chief Justice 
        Mbeh Derick hopes to be there at the Philippine Goodwill event, in fact all of the Privy council 
        would love to go too.  We believe that by bringing Goodwill to the Philippines that it will help 
        us to grow our Kringle community there faster. We want to speed up our growth in countries like 
        the Philippines. We hope all the great Kringle Leaders of the Philippines will unite and fully 
        support our effort to do Goodwill in their country having Nonito Rabel as their Goodwill Ambassador. 
        Our Active Membership globally continues to grow and now we have about 27,000 Active Members and 
        just over 4,000 Holders of the KLUV coin. We have raised the total amount of money for Goodwill to 
        $130,000.00 within the first 9 months of the existence of the KLUV coin. THAT'S AMAZING! $10,000.00 
        of that will be spent on food to feed the poor in the Philippines on December 17th, 2022.
      </p>
      <p>
        $5,000 of BNB was sent to Ambassador Nonito Rabel on December 6th, 2022 as a required deposit to purchase food:
        <a href="https://bscscan.com/tx/0x2c89598c0e588d120ea48a2e5a5bdc05f4b906ba11986cc983cb67250b730251" target="new">
          https://bscscan.com/tx/0x2c89598c0e588d120ea48a2e5a5bdc05f4b906ba11986cc983cb67250b730251
        </a>
      </p>
      <p>
        The remaining $5,000 for a total of $10,000 was sent to Ambassador Nonito Rabel on December 12th, 2022 to purchase food:
        <a href="https://bscscan.com/tx/0xa6b6adbd849761f5b8ebfcb5e16f7fa9f8f3a491cc3511228d1bba395eec91cc" target="new">
          https://bscscan.com/tx/0xa6b6adbd849761f5b8ebfcb5e16f7fa9f8f3a491cc3511228d1bba395eec91cc
        </a>
      </p>

      <!--
      <p><b>Receipts</b></p>
      <div class="gg-container" style="padding: 0 30px;">
        <div class="gg-box gallery goodwill-gallery">
          <img src="https://www.kluvcoin.io/img/mbeh_round3/receipt/1.jpg" />
          <img src="https://www.kluvcoin.io/img/mbeh_round3/receipt/2.jpg" />
          <img src="https://www.kluvcoin.io/img/mbeh_round3/receipt/3.jpg" />
          <img src="https://www.kluvcoin.io/img/mbeh_round3/receipt/4.jpg" />
        </div>
      </div>
      -->

      <br/><br/>
      <p><b>Event Photos</b></p>
      <div class="gg-container" style="padding: 0 30px;">
        <div class="gg-box gallery goodwill-gallery">
          <img src="https://www.kluvcoin.io/img/ph/event/1.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/2.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/3.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/4.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/5.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/6.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/7.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/8.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/9.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/10.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/11.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/12.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/13.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/14.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/15.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/16.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/17.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/18.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/19.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/20.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/21.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/22.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/23.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/24.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/25.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/26.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/27.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/28.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/29.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/30.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/31.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/32.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/33.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/34.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/35.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/36.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/37.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/38.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/39.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/40.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/41.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/42.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/43.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/44.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/45.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/46.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/47.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/48.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/49.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/50.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/51.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/52.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/53.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/54.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/55.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/56.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/57.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/58.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/59.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/60.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/61.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/62.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/63.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/64.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/65.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/66.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/67.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/68.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/69.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/70.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/71.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/72.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/73.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/74.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/75.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/76.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/77.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/78.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/79.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/80.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/81.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/82.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/83.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/84.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/85.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/86.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/87.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/88.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/89.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/90.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/91.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/92.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/93.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/94.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/95.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/96.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/97.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/98.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/99.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/100.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/101.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/102.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/103.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/104.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/105.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/106.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/107.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/108.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/109.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/110.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/111.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/112.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/113.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/114.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/115.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/116.jpg" />
          <img src="https://www.kluvcoin.io/img/ph/event/117.jpg" />
        </div>
      </div>

      <br/>
      <br/>
      <hr/>
      <p><b>Event Videos:</b></p>
      <iframe width="560" height="315" src="https://www.youtube.com/embed/Lc3-ixPNyW0" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
      <iframe width="560" height="315" src="https://www.youtube.com/embed/9486DaU_UgA" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
    </div>
  </div>

    <script src="https://www.kluvcoin.io/js/grid-gallery.min.js"></script>
    
    <script>
      gridGallery({
        selector: ".gallery",
        darkMode: true,
        layout: "square",
        gapLength: 10,
        rowHeight: 300,
        columnWidth: 300
      });
    </script>
  </body>
</html>