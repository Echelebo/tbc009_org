<html>
<title>Kringle.Cash</title>
<head>
    <meta http-equiv="Content-Type" content="application/xhtml+xml; charset=UTF-8" />
    <link rel="shortcut icon" href="favicon.ico" />
    <!-- mobile settings -->
    <meta name="viewport" content="width=device-width, maximum-scale=1, initial-scale=1, user-scalable=0" />	
    <meta property="og:image" content="https://kringle.cash/images/linkimage2c.jpg" />
	<meta property="og:description" content="Become a Millionaire automatically FREE of CHARGE.   This Cash Giveaway expires soon!  Click NOW and collect your GIFT!" />
	<meta property="og:url" content="https://kringle.cash/" />
    <meta property="og:title" content="Kringle.Cash" />
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css"/>
      
      <script type="text/javascript" src="js/jquery.js"></script> 
	  <script type="text/javascript" src="js/bootstrap.js"></script>
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
	<style>

	</style>
    <link href="css/style.css" media="screen" rel="stylesheet" type="text/css">
    <link href="css/ownstyle.css" media="screen" rel="stylesheet" type="text/css">
    <link href="css/mystyle.css" media="screen" rel="stylesheet" type="text/css">
    <link href="css/info1.css" media="screen" rel="stylesheet" type="text/css">
    <script type="text/javascript">
        function googleTranslateElementInit() {
            new google.translate.TranslateElement({pageLanguage: 'en', layout: google.translate.TranslateElement.InlineLayout.SIMPLE}, 'google_translate_element');
        }
    </script>
    <script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
    <!--<div id="google_translate_element"></div>-->
    <style>
        .goog-te-menu-value img {
           display: none;
        }
        .goog-te-gadget-simple img {
        background-image: url('images/KringleCoin.gif')!important;
        }
    </style>
</head>
<body>
<header>
    <div class="header-top" id="menuUser">
        <div class="container">
            <div class="row">
                <div class="col">
                <!--<div class="col-sm-2 col-xs-12" style="width: 13.666667%;    margin-top: -3px;" id="google_translate_element">
                </div>-->
                <div class="float-right" style="display: inline-block;margin-right: 16px;height: 36px;float: right;">
                    <div id="google_translate_element"></div>
                </div>
                    </div>
            </div>
        </div>
    </div>
</header>


<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://fonts.googleapis.com/css2?family=Fugaz+One&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Roboto+Condensed&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/grid-gallery.min.css">
    <link rel="stylesheet" href="css/style.css?20210128">
  </head>

  <body>
    <div class="goodwill-box d-flex align-center justify-space-around">
      <div class="box">
	      <h2>India Gets Second Round of Goodwill this September 2022</h2><br/>

          <img src="https://www.kluvcoin.io/img/Syed2.jpg" />
          <p>
          Is India taking over TBC?  The recent growth of the TBC Community in India can NOT be ignored!  We currently have over 18,000 Active Members in the world and thousands of them come from India.
          <br/><br/>
          We must support the strength we find within this TBC community and that is why it makes sense to do Round 2 of Goodwill in India. We only have about 3,000 Holders of the KLUV coin and this second round of Goodwill will mean that we have raised the total amount of money for Goodwill to $100,000.00 within the first 7 months of the existence of the KLUV coin. THAT'S AMAZING! $10,000.00 of that will be spent on food to feed the poor again in India on September 24th, 2022.
         </p>
         <p>
		    $10,000 of BNB was sent to Ambassador Syed Rahman of India on September 19th, 2022 to purchase food: 
			<a href="https://bscscan.com/tx/0x2133c307b16bf9f301ca500ccc1b90cf5e87445489aae0fcd661ed31602307d0" target="new"> https://bscscan.com/tx/0x2133c307b16bf9f301ca500ccc1b90cf5e87445489aae0fcd661ed31602307d0 </a>
         </p>
		<p><br/>
		    <b>TBC Goodwill report for India by Syed Rahman, Ambassador of India</b><br/><br/>

			Our Goodwill event in Imphal West District, Manipur, India took place on 24th September 2022 was a remarkable day of the Country. Rickshaw driver, disable person including blind, deaf, orthopedic handicap person, widow and orphan are benefited by the Goodwill Mission, Manipur. <br/><br/>

			Goodwill Mission, India received a total of 520 persons from the Kluv. 50 kgs of rice bags, 1 litre refine oil, 1 kg potato, 1 kg onion, 1 kg sugar, 250 gm tealeaf, 1 kg Masoor dal, 1 kg of dry peanut, ½ kg GISKAA Black Lentils Nuggets (Local name bori) and 1 kg salt was distributed to 520 persons. The meeting was preceded by State Committee under the leadership of United TBC, Manipur India. <br/><br/>

			Local youth club of Langthabal Lep where the meeting was conducted, with its volunteer supported the meeting. All the recipients were very happy as because there is no one to support to them except TBC and KLUV. We the TBCian Manipur India thankful the admin of TBC and Kismet International Ltd for supporting to needy people of India to achieve the goal of TBC.<br/><br/>
			
			<b>Kluv Shares, Kluv Cares</b>
        </p><br/>
		
	  <p><b>Receipts</b></p>
		<div class="gg-container" style="padding: 0 30px;">
          <div class="gg-box gallery goodwill-gallery">
			<img src="https://www.kluvcoin.io/img/india-round2/84.jpg" />
			<img src="https://www.kluvcoin.io/img/india-round2/85.jpg" />
			<img src="https://www.kluvcoin.io/img/india-round2/86.jpg" />
			<img src="https://www.kluvcoin.io/img/india-round2/87.jpg" />
			<img src="https://www.kluvcoin.io/img/india-round2/88.jpg" />
			<img src="https://www.kluvcoin.io/img/india-round2/89.jpg" />
          </div>
        </div>
        <br/>
        <br/>
        <hr/>
		
		<p><b>State News Papers - Editions,  Press Conference, Event Materials</b></p>
		<div class="gg-container" style="padding: 0 30px;">
          <div class="gg-box gallery goodwill-gallery">
			<img src="https://www.kluvcoin.io/img/india-round2/76.jpg" />
			<img src="https://www.kluvcoin.io/img/india-round2/77.jpg" />
			<img src="https://www.kluvcoin.io/img/india-round2/78.jpg" />
			<img src="https://www.kluvcoin.io/img/india-round2/79.jpg" />
			<img src="https://www.kluvcoin.io/img/india-round2/80.jpg" />
			<img src="https://www.kluvcoin.io/img/india-round2/81.jpg" />
			<img src="https://www.kluvcoin.io/img/india-round2/82.jpg" />
			<img src="https://www.kluvcoin.io/img/india-round2/83.jpg" />
          </div>
        </div>
        <br/>
        <br/>
        <hr/>
		
        <p><b>Event Photos</b></p>
		    <div class="gg-container" style="padding: 0 30px;">
          <div class="gg-box gallery goodwill-gallery">
			<img src="https://www.kluvcoin.io/img/india-round2/1.jpg" />
			<img src="https://www.kluvcoin.io/img/india-round2/2.jpg" />
			<img src="https://www.kluvcoin.io/img/india-round2/3.jpg" />
			<img src="https://www.kluvcoin.io/img/india-round2/4.jpg" />
			<img src="https://www.kluvcoin.io/img/india-round2/5.jpg" />
			<img src="https://www.kluvcoin.io/img/india-round2/6.jpg" />
			<img src="https://www.kluvcoin.io/img/india-round2/7.jpg" />
			<img src="https://www.kluvcoin.io/img/india-round2/8.jpg" />
			<img src="https://www.kluvcoin.io/img/india-round2/9.jpg" />
			<img src="https://www.kluvcoin.io/img/india-round2/10.jpg" />
			<img src="https://www.kluvcoin.io/img/india-round2/11.jpg" />
			<img src="https://www.kluvcoin.io/img/india-round2/12.jpg" />
			<img src="https://www.kluvcoin.io/img/india-round2/13.jpg" />
			<img src="https://www.kluvcoin.io/img/india-round2/14.jpg" />
			<img src="https://www.kluvcoin.io/img/india-round2/15.jpg" />
			<img src="https://www.kluvcoin.io/img/india-round2/16.jpg" />
			<img src="https://www.kluvcoin.io/img/india-round2/17.jpg" />
			<img src="https://www.kluvcoin.io/img/india-round2/18.jpg" />
			<img src="https://www.kluvcoin.io/img/india-round2/19.jpg" />
			<img src="https://www.kluvcoin.io/img/india-round2/20.jpg" />
			<img src="https://www.kluvcoin.io/img/india-round2/21.jpg" />
			<img src="https://www.kluvcoin.io/img/india-round2/22.jpg" />
			<img src="https://www.kluvcoin.io/img/india-round2/23.jpg" />
			<img src="https://www.kluvcoin.io/img/india-round2/24.jpg" />
			<img src="https://www.kluvcoin.io/img/india-round2/25.jpg" />
			<img src="https://www.kluvcoin.io/img/india-round2/26.jpg" />
			<img src="https://www.kluvcoin.io/img/india-round2/27.jpg" />
			<img src="https://www.kluvcoin.io/img/india-round2/28.jpg" />
			<img src="https://www.kluvcoin.io/img/india-round2/29.jpg" />
			<img src="https://www.kluvcoin.io/img/india-round2/30.jpg" />
			<img src="https://www.kluvcoin.io/img/india-round2/31.jpg" />
			<img src="https://www.kluvcoin.io/img/india-round2/32.jpg" />
			<img src="https://www.kluvcoin.io/img/india-round2/33.jpg" />
			<img src="https://www.kluvcoin.io/img/india-round2/34.jpg" />
			<img src="https://www.kluvcoin.io/img/india-round2/35.jpg" />
			<img src="https://www.kluvcoin.io/img/india-round2/36.jpg" />
			<img src="https://www.kluvcoin.io/img/india-round2/37.jpg" />
			<img src="https://www.kluvcoin.io/img/india-round2/38.jpg" />
			<img src="https://www.kluvcoin.io/img/india-round2/39.jpg" />
			<img src="https://www.kluvcoin.io/img/india-round2/40.jpg" />
			<img src="https://www.kluvcoin.io/img/india-round2/41.jpg" />
			<img src="https://www.kluvcoin.io/img/india-round2/42.jpg" />
			<img src="https://www.kluvcoin.io/img/india-round2/43.jpg" />
			<img src="https://www.kluvcoin.io/img/india-round2/44.jpg" />
			<img src="https://www.kluvcoin.io/img/india-round2/45.jpg" />
			<img src="https://www.kluvcoin.io/img/india-round2/46.jpg" />
			<img src="https://www.kluvcoin.io/img/india-round2/47.jpg" />
			<img src="https://www.kluvcoin.io/img/india-round2/48.jpg" />
			<img src="https://www.kluvcoin.io/img/india-round2/49.jpg" />
			<img src="https://www.kluvcoin.io/img/india-round2/50.jpg" />
			<img src="https://www.kluvcoin.io/img/india-round2/51.jpg" />
			<img src="https://www.kluvcoin.io/img/india-round2/52.jpg" />
			<img src="https://www.kluvcoin.io/img/india-round2/53.jpg" />
			<img src="https://www.kluvcoin.io/img/india-round2/54.jpg" />
			<img src="https://www.kluvcoin.io/img/india-round2/55.jpg" />
			<img src="https://www.kluvcoin.io/img/india-round2/56.jpg" />
			<img src="https://www.kluvcoin.io/img/india-round2/57.jpg" />
			<img src="https://www.kluvcoin.io/img/india-round2/58.jpg" />
			<img src="https://www.kluvcoin.io/img/india-round2/59.jpg" />
			<img src="https://www.kluvcoin.io/img/india-round2/60.jpg" />
			<img src="https://www.kluvcoin.io/img/india-round2/61.jpg" />
			<img src="https://www.kluvcoin.io/img/india-round2/62.jpg" />
			<img src="https://www.kluvcoin.io/img/india-round2/63.jpg" />
			<img src="https://www.kluvcoin.io/img/india-round2/64.jpg" />
			<img src="https://www.kluvcoin.io/img/india-round2/65.jpg" />
			<img src="https://www.kluvcoin.io/img/india-round2/66.jpg" />
			<img src="https://www.kluvcoin.io/img/india-round2/67.jpg" />
			<img src="https://www.kluvcoin.io/img/india-round2/68.jpg" />
			<img src="https://www.kluvcoin.io/img/india-round2/69.jpg" />
			<img src="https://www.kluvcoin.io/img/india-round2/70.jpg" />
			<img src="https://www.kluvcoin.io/img/india-round2/71.jpg" />
			<img src="https://www.kluvcoin.io/img/india-round2/72.jpg" />
			<img src="https://www.kluvcoin.io/img/india-round2/73.jpg" />
			<img src="https://www.kluvcoin.io/img/india-round2/74.jpg" />
			<img src="https://www.kluvcoin.io/img/india-round2/75.jpg" />
          </div>
        </div>
        <br/>
        <br/>
        <hr/>
        <p><b>Media Coverage:</b></p>
        <br/><br/>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/RW11Z14wT0s" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
		<iframe width="560" height="315" src="https://www.youtube.com/embed/RzXlN5Xs35I" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <br/>
        <br/>
        <hr/>
        <p><b>Event Videos:</b></p>
        <br/><br/>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/o_Hl92t28Vs" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        
      </div>
    </div>

    <script src="js/grid-gallery.min.js"></script>
    <script>
      gridGallery({
        selector: ".gallery",
        darkMode: true,
        layout: "square",
        gapLength: 10,
        rowHeight: 300,
        columnWidth: 300
      });
    </script>
  </body>
</html>