<html>
<title>Kringle.Cash</title>
<head>
    <meta http-equiv="Content-Type" content="application/xhtml+xml; charset=UTF-8" />
    <link rel="shortcut icon" href="favicon.ico" />
    <!-- mobile settings -->
    <meta name="viewport" content="width=device-width, maximum-scale=1, initial-scale=1, user-scalable=0" />	
    <meta property="og:image" content="https://kringle.cash/images/linkimage2c.jpg" />
	<meta property="og:description" content="Become a Millionaire automatically FREE of CHARGE.   This Cash Giveaway expires soon!  Click NOW and collect your GIFT!" />
	<meta property="og:url" content="https://kringle.cash/" />
    <meta property="og:title" content="Kringle.Cash" />
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css"/>
      
      <script type="text/javascript" src="js/jquery.js"></script> 
	  <script type="text/javascript" src="js/bootstrap.js"></script>
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
	<style>

	</style>
    <link href="css/style.css" media="screen" rel="stylesheet" type="text/css">
    <link href="css/ownstyle.css" media="screen" rel="stylesheet" type="text/css">
    <link href="css/mystyle.css" media="screen" rel="stylesheet" type="text/css">
    <link href="css/info1.css" media="screen" rel="stylesheet" type="text/css">
    <script type="text/javascript">
        function googleTranslateElementInit() {
            new google.translate.TranslateElement({pageLanguage: 'en', layout: google.translate.TranslateElement.InlineLayout.SIMPLE}, 'google_translate_element');
        }
    </script>
    <script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
    <!--<div id="google_translate_element"></div>-->
    <style>
        .goog-te-menu-value img {
           display: none;
        }
        .goog-te-gadget-simple img {
        background-image: url('images/KringleCoin.gif')!important;
        }
    </style>
</head>
<body>
<header>
    <div class="header-top" id="menuUser">
        <div class="container">
            <div class="row">
                <div class="col">
                <!--<div class="col-sm-2 col-xs-12" style="width: 13.666667%;    margin-top: -3px;" id="google_translate_element">
                </div>-->
                <div class="float-right" style="display: inline-block;margin-right: 16px;height: 36px;float: right;">
                    <div id="google_translate_element"></div>
                </div>
                    </div>
            </div>
        </div>
    </div>
</header>


<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://fonts.googleapis.com/css2?family=Fugaz+One&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Roboto+Condensed&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/grid-gallery.min.css">
    <link rel="stylesheet" href="css/style.css?20210128">
    <title>Kluv Coin</title>
  </head>

  <body>
    <div class="goodwill-box d-flex align-center justify-space-around">
      <div class="box">
	      <h2>REPORT ON THE TBC/KLUV GOODWILL PROJECT IN ABUJA – NIGERIA</h2>
        <img src="https://www.kluvcoin.io/img/augustine-obidimma.jpg" />
        <p>
          The TBC/KLUV Goodwill project for Nigeria took place on 21st May, 2022. The event was held at 
          a Physically Challenged People’s Camp in a village called Karamajiji in Abuja, Nigeria’s 
          capital city.
        </p>
        <p>Receipts:</p>
		    <div class="gg-container" style="padding: 0 30px;">
          <div class="gg-box gallery goodwill-gallery">
            <img src="https://www.kluvcoin.io/img/augustinne_receipt/1.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_receipt/2.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_receipt/3.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_receipt/4.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_receipt/5.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_receipt/6.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_receipt/7.jpg" />
          </div>
        </div>
        <p>
          <br/>
          <b>NEEDS ASSESSMENT VISITS</b>
          <br/>
          Initially, the 4-man organizing committee had identified an Internally Displaced People’s Camp 
          at a location called Kuchigoro. But after several visits to the camp, the hostility of the 
          community members and the lack of cooperation on the part of the community leaders left us no 
          choice than to seek out another community.
          <br/>
          Hence the identification of the Physically Challenged People’s Camp in Karamajiji, the community 
          is mainly inhabited by over 3,000 people, both men, women and children with various forms of 
          disabilities, like the blind, the lame and the crippled. These people were obviously living a 
          life of abject poverty and complete hopelessness! It was, therefore a good choice for this 
          goodwill project.
          <br/>
          Right from our first visit the community leaders and members welcomed us wholeheartedly. They 
          were excited about our visit and were very cooperative in assisting us with all the necessary 
          arrangements we needed to make. They were asked to draw up a list of 360 beneficiaries that 
          will be allowed into the premises to avoid any form of rowdiness or stampede.
        </p>
        <p>
          <br/>
          <b>IDENTIFICATION AND ASSIGNMENT OF ROLES</b>
          <br/>
          The community assisted the organizing committee to select some able bodied men among them to 
          serve in different capacities at the event:
          <br/><br/>
          1. Leaders – Six community leaders were identified. These ones wore the black TBC/KLUV T-Shirts. Their responsibility was to help coordinate all the activities to ensure only those earmarked as beneficiaries were allowed into the premises.
          <br/><br/>
          2. Helpers – 10 able bodied men were selected as “helpers”; they wore the red TBC/KLUV T-Shirts. 
          Their job was to help offload the goods from the trucks, pack the goods into a storehouse, bring 
          out and arrange the goods on the day of the event, help in the distribution of the goods to the 
          selected beneficiaries.
          <br/><br/>
          3. Security (Police and Local Vigilante) – their role was to help maintain law and order in the 
          premises of the event, to avoid any form of commotion and ward off uninterrupted intruders.
          <br/><br/>
          4. The goodwill project organizing committee members – there were 4 of us, we wore the white 
          TBC/KLUV T-Shirts, we handled the planning and execution of the event.
          <br/><br/>
          The event went as planned and without any hitches, the beneficiaries sat patiently and waited for their turns to receive the items that were distributed to them. Each beneficiary got 1 bag of 10kg rice, 1 carton of Noodles and 4 measures of garri (a local popular food in Nigeria made from cassava).
        </p>
        <p>
          <br/>
          <b>FEEDBACK</b>
          <br/>
          The outpouring of excitement expressed by the beneficiaries was heart-touching and mind blowing. 
          Intermittently they kept chanting AMBASSADOR!! AMBASSADOR!! AMBASSADOR!! MAY GOD BLESS YOU 
          ABUNDANTLY. Those who could dance danced on their wheelchairs, others could barely contain their 
          excitement.
        </p>
        <p>
          <br/>
          <b>APPRECIATION</b>
          <br/>
          The community leaders took turns to appreciate the members of the organizing committee and the man 
          behind the mask – the TBC Amin, they were unanimous in ascertaining that never in their lives have 
          they experienced such magnitude of love.
        </p>
        <p>
          <br/>
          <b>CONCLUSION</b>
          <br/>
          The pictures and the videos may not have captured effectively the impact of this goodwill project 
          in the lives of these helpless physically challenged individuals, but suffice it to say that it 
          was a worthwhile outreach. The Nigerian TBC Community heartily appreciates TBC Admin for this 
          generous gesture. LONG LIVE TBC ADMIN, LONG LIVE TBC COMMUNITY, LONG LIVE GOODWILL PROGRAMS ALL 
          OVER THE WORLD.
          <br/><br/>
          Collectively, we will lift humanity out of the Morass of Poverty, Misery and Lack, into a World 
          built of the Principle of Abundance for ALL.
          <br/><br/>
          Cheers and God bless you all.
        </p>

        <p>Event Photos in ABUJA – NIGERIA</p>
        <div class="gg-container" style="padding: 0 30px;">
          <div class="gg-box gallery2 goodwill-gallery">
            <img src="https://www.kluvcoin.io/img/augustinne_step1/1.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_step1/2.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_step1/3.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_step1/4.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_step1/5.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_step1/6.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_step1/7.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_step1/8.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_step1/9.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_step1/10.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_step1/11.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_step1/12.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_step1/13.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_step1/14.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_step1/15.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_step1/16.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_step1/17.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_step1/18.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_step1/19.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_step1/20.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_step1/21.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_step1/22.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_step1/23.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_step1/24.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_step1/25.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_step1/26.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_step1/27.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_step1/28.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_step1/29.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_step1/30.jpg" />
			      <img src="https://www.kluvcoin.io/img/augustinne_step1/31.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_step1/32.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_step1/33.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_step1/34.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_step1/35.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_step1/36.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_step1/37.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_step1/38.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_step1/39.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_step1/40.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_step1/41.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_step1/42.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_step1/43.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_step1/44.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_step1/45.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_step1/46.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_step1/47.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_step1/48.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_step1/49.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_step1/50.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_step1/51.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_step1/52.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_step1/53.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_step1/54.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_step1/55.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_step1/56.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_step1/57.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_step1/58.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_step1/59.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_step1/60.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_step1/61.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_step1/62.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_step1/63.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_step1/64.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_step1/65.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_step1/66.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_step1/67.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_step1/68.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_step1/69.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_step1/70.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_step1/71.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_step1/72.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_step1/73.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_step1/74.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_step1/75.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_step1/76.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_step1/77.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_step1/78.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_step1/79.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_step1/80.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_step1/81.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_step1/82.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_step1/83.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_step1/84.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_step1/85.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_step1/86.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_step1/87.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_step1/88.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_step1/89.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_step1/90.jpg" />
            <img src="https://www.kluvcoin.io/img/augustinne_step1/91.jpg" />
          </div>
          <br/>
          <hr/>
          <h2>Here are the videos from the event.</h2>
          <iframe width="560" height="315" src="https://www.youtube.com/embed/kIOjT3ELlKY" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
          <iframe width="560" height="315" src="https://www.youtube.com/embed/f8cY1G7hqAg" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
          <iframe width="560" height="315" src="https://www.youtube.com/embed/tTrCvBYAgm4" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
          <iframe width="560" height="315" src="https://www.youtube.com/embed/ur9A4tcaqFM" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
          <iframe width="560" height="315" src="https://www.youtube.com/embed/TV6OZJEz1eU" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
          <iframe width="560" height="315" src="https://www.youtube.com/embed/T9eThb0hLrY" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
          <iframe width="560" height="315" src="https://www.youtube.com/embed/RMpcfCAFw4A" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
          <iframe width="560" height="315" src="https://www.youtube.com/embed/Qs9r-FCEARQ" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
          <iframe width="560" height="315" src="https://www.youtube.com/embed/O2urp_1o2pc" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
          <iframe width="560" height="315" src="https://www.youtube.com/embed/iXjXXzkiyHw" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
          <iframe width="560" height="315" src="https://www.youtube.com/embed/bMnA9t8-HPc" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
          <iframe width="560" height="315" src="https://www.youtube.com/embed/_OkYRCDjiQU" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
          <iframe width="560" height="315" src="https://www.youtube.com/embed/U3GbFxS0LQc" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
          <iframe width="560" height="315" src="https://www.youtube.com/embed/D8LjbKcdbz0" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
          <iframe width="560" height="315" src="https://www.youtube.com/embed/9pcRkzKG5AY" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
          <iframe width="560" height="315" src="https://www.youtube.com/embed/TC1oXA2d-rM" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
          <iframe width="560" height="315" src="https://www.youtube.com/embed/vKKUbk3Up68" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
          <iframe width="560" height="315" src="https://www.youtube.com/embed/HCS1wjdRFRs" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
          <iframe width="560" height="315" src="https://www.youtube.com/embed/bSjW1_vxPD4" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
          <iframe width="560" height="315" src="https://www.youtube.com/embed/FzBta4HjXh8" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
          <iframe width="560" height="315" src="https://www.youtube.com/embed/Thlm3Sj8QZY" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
          <iframe width="560" height="315" src="https://www.youtube.com/embed/RnWmlsU59o4" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
          <iframe width="560" height="315" src="https://www.youtube.com/embed/ihdmOYlAr40" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
          <iframe width="560" height="315" src="https://www.youtube.com/embed/w_xzPEv2yy8" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
          <iframe width="560" height="315" src="https://www.youtube.com/embed/OZFi7dcSCg8" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
          <iframe width="560" height="315" src="https://www.youtube.com/embed/c4W_RBR8l8w" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
          <iframe width="560" height="315" src="https://www.youtube.com/embed/ku8IS5AajKI" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
          <iframe width="560" height="315" src="https://www.youtube.com/embed/iMNnTUvw6PY" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
          <iframe width="560" height="315" src="https://www.youtube.com/embed/uNRL-qX0xAQ" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
          <iframe width="560" height="315" src="https://www.youtube.com/embed/xO-HD5I5FI8" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
          <iframe width="560" height="315" src="https://www.youtube.com/embed/NLNFOwNMRyQ" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
          <iframe width="560" height="315" src="https://www.youtube.com/embed/lhcg_utH734" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
          <iframe width="560" height="315" src="https://www.youtube.com/embed/7QWIQay8iNU" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
          <iframe width="560" height="315" src="https://www.youtube.com/embed/xHJ0uxFBXOk" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
          <iframe width="560" height="315" src="https://www.youtube.com/embed/uqw9wQL2Up4" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
          <iframe width="560" height="315" src="https://www.youtube.com/embed/oAU66nHZ70M" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        </div>
      </div>
    </div>

    <script src="js/grid-gallery.min.js"></script>
    <script>
      gridGallery({
        selector: ".gallery",
        darkMode: true,
        layout: "square",
        gapLength: 10,
        rowHeight: 300,
        columnWidth: 300
      });
      gridGallery({
        selector: ".gallery2",
        darkMode: true,
        layout: "square",
        gapLength: 10,
        rowHeight: 300,
        columnWidth: 300
      });

      var openMenu = false
      var menu = document.querySelector('.menu');
      var mobileNenu = document.querySelector('.mobile-menu');
      menu.onclick = function (e) {
        openMenu = !openMenu
        if (openMenu) {
          mobileNenu.classList.add("show");
        } else {
          mobileNenu.classList.remove("show");
        }
      }

      var submenu = document.querySelector('.sub-menu');
      var submenyDelay = ''
      submenu.addEventListener("mouseenter", function () {
        if (submenyDelay) clearTimeout(submenyDelay)
        submenu.classList.add("hover");
      })
      submenu.addEventListener("mouseleave", function () {
        if (submenyDelay) clearTimeout(submenyDelay)

        submenyDelay = setTimeout(function () {
          submenu.classList.remove("hover");
        }, 1000)
      })
      var submenuDiv = document.querySelector('.sub-menu div');
      submenu.addEventListener("mouseenter", function () {
        if (submenyDelay) clearTimeout(submenyDelay)
        submenu.classList.add("hover");
      })
      submenu.addEventListener("mouseleave", function () {
        if (submenyDelay) clearTimeout(submenyDelay)
        submenyDelay = setTimeout(function () {
          submenu.classList.remove("hover");
        }, 1000)
      })
    </script>
  </body>
</html>