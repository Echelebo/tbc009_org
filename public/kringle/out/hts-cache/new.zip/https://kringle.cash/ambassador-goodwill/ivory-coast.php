<html>
<title>Kringle.Cash</title>
<head>
    <meta http-equiv="Content-Type" content="application/xhtml+xml; charset=UTF-8" />
    <link rel="shortcut icon" href="favicon.ico" />
    <!-- mobile settings -->
    <meta name="viewport" content="width=device-width, maximum-scale=1, initial-scale=1, user-scalable=0" />	
    <meta property="og:image" content="https://kringle.cash/images/linkimage2c.jpg" />
	<meta property="og:description" content="Become a Millionaire automatically FREE of CHARGE.   This Cash Giveaway expires soon!  Click NOW and collect your GIFT!" />
	<meta property="og:url" content="https://kringle.cash/" />
    <meta property="og:title" content="Kringle.Cash" />
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css"/>
      
      <script type="text/javascript" src="js/jquery.js"></script> 
	  <script type="text/javascript" src="js/bootstrap.js"></script>
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
	<style>

	</style>
    <link href="css/style.css" media="screen" rel="stylesheet" type="text/css">
    <link href="css/ownstyle.css" media="screen" rel="stylesheet" type="text/css">
    <link href="css/mystyle.css" media="screen" rel="stylesheet" type="text/css">
    <link href="css/info1.css" media="screen" rel="stylesheet" type="text/css">
    <script type="text/javascript">
        function googleTranslateElementInit() {
            new google.translate.TranslateElement({pageLanguage: 'en', layout: google.translate.TranslateElement.InlineLayout.SIMPLE}, 'google_translate_element');
        }
    </script>
    <script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
    <!--<div id="google_translate_element"></div>-->
    <style>
        .goog-te-menu-value img {
           display: none;
        }
        .goog-te-gadget-simple img {
        background-image: url('images/KringleCoin.gif')!important;
        }
    </style>
</head>
<body>
<header>
    <div class="header-top" id="menuUser">
        <div class="container">
            <div class="row">
                <div class="col">
                <!--<div class="col-sm-2 col-xs-12" style="width: 13.666667%;    margin-top: -3px;" id="google_translate_element">
                </div>-->
                <div class="float-right" style="display: inline-block;margin-right: 16px;height: 36px;float: right;">
                    <div id="google_translate_element"></div>
                </div>
                    </div>
            </div>
        </div>
    </div>
</header>


<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://fonts.googleapis.com/css2?family=Fugaz+One&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Roboto+Condensed&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/grid-gallery.min.css">
    <link rel="stylesheet" href="css/style.css?20210128">
  </head>

  <body>
    <div class="goodwill-box d-flex align-center justify-space-around">
      <div class="box">
	      <h2>Innocent Keiba has accepted the position of Goodwill Ambassador for Ivory Coast within the Kringle Society.</h2>
        <img src="img/keiba.jpg" />
        <p>
          It only took a week 
          since the launch of our KLUV Coin and with only about 500 people 
          that have bought it we were able to raise $10,000.  KLUV has 
          raised $10,000 to buy food for the needy in support of the Kringle 
          Society Goodwill program.  The food will be distributed to the poor 
          and needy on February 19th, 2022.
        </p>
        <p>
          $10,000 of BNB was sent to Ambassador Innocent Keiba on February 14th, 2022 to purchase food: 
          <a href="https://bscscan.com/tx/0x5a62c6d22cf621a9dc73ba98a979a90e6fb4f9c137459464bf8ca1a0fd3a055f" target="new">
            https://bscscan.com/tx/0x5a62c6d22cf621a9dc73ba98a979a90e6fb4f9c137459464bf8ca1a0fd3a055f
          </a>
        </p>
        <p>Receipts:</p>
		    <div class="gg-container" style="padding: 0 30px;">
          <div class="gg-box gallery goodwill-gallery">
            <img src="https://www.kluvcoin.io/img/innocentreceipt/1.jpg" />
            <img src="https://www.kluvcoin.io/img/innocentreceipt/2.jpg" />
            <img src="https://www.kluvcoin.io/img/innocentreceipt/3.jpg" />
            <img src="https://www.kluvcoin.io/img/innocentreceipt/4.jpg" />
            <img src="https://www.kluvcoin.io/img/innocentreceipt/5.jpg" />
            <img src="https://www.kluvcoin.io/img/innocentreceipt/6.jpg" />
            <img src="https://www.kluvcoin.io/img/innocentreceipt/7.jpg" />
            <img src="https://www.kluvcoin.io/img/innocentreceipt/8.png" />
          </div>
        </div>

		    <p>
		      <b>TBC Goodwill report for Ivory Coast by KEIBA N. Innocent</b><br/><br/>
          Very concerned about increasingly degraded and degrading human relations, the Administrator of 
          TBC is implementing a personal development plan within the community to enable each member to 
          embody the Culture of LOVE of Sharing and RESPECT for human dignity.<br/>
          To make this program a success and offer members the opportunity in each country to experience 
          these two fundamental criteria of the Kringle community, the TBC Administrator relies on the 
          ambassadors to organize the distribution of food and not to live with the lowest social strata. 
          more vulnerable. This is what was launched here in C&ocirc;te d'Ivoire to provide food and non-food 
          items to more than 800 families and 5 institutes (3 orphanages, 1 institute for the blind and 2 
          associations (widows and disabled)<br/>
          This goodwill program was first initiated in March in Nigeria with the two goodwill ambassadors 
          Steven Cuffee and Mbeh Derick. Because of the COVID scam.
          This program has been suspended. Thanks to the great determination of the Administrator of TBC 
          and to see real Leaders tomorrow leading this world towards a better horizon, he puts an 
          infallible strategy for the continuation of the GOODWILL program in the rest of the world. It 
          opens the Community to the public market with the sensational KLUV token and allows us to 
          organize the 3rd world stage of GOOWILL after only 1 month. It should be noted that the TBC 
          administrator sent funds worth $10,000 to C&ocirc;te d'Ivoire to feed the social strata of vulnerable 
          people.<br/><br/>
          Last February 19, 2022, we are delighted to share these to vulnerable people and institute for 
          the 1st stage in Abobo. Centered on this municipality which is one of the poorest municipalities 
          in the District and which has just over 1,500,000 inhabitants. It's 420 people included orphans 
          (78), handicapped (50: blind-dumb - infirm), widowed women (100), very poor families (192) from 
          the 32 ethnic communities living in the municipality from Abobo. Each of them went home with at 
          least 5 kg of rice, cooking oil and spaghetti.
          For institutes caring for orphaned children who have toilets and play areas to clean, we have 
          added canisters of detergent to keep the play areas clean and protect them from certain 
          infections for a while. Below are some photos from the launch and distribution ceremony in Abobo.<br/>
		      On February 22 we were in Yopougon and on February 25 we were in Port Bouet for the 3rd stage. A stage that was very full of experiences. 
        </p>
		    <p>Step 1 (ABOBO) - The WEEK of GOODWILL in Ivory Coast</p>
        <div class="gg-container" style="padding: 0 30px;">
          <div class="gg-box gallery goodwill-gallery">
            <img src="https://www.kluvcoin.io/img/Innocent Step 1/1.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 1/2.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 1/3.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 1/4.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 1/5.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 1/6.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 1/7.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 1/8.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 1/9.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 1/10.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 1/11.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 1/12.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 1/13.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 1/14.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 1/15.jpg" />
          </div>
        </div>
        <p>Step 2 - Goodwill Event in Yopougon</p>
        <div class="gg-container" style="padding: 0 30px;">
          <div class="gg-box gallery2 goodwill-gallery">
            <img src="https://www.kluvcoin.io/img/Innocent Step 2/1.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 2/2.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 2/3.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 2/4.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 2/5.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 2/6.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 2/7.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 2/8.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 2/9.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 2/10.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 2/11.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 2/12.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 2/13.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 2/14.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 2/15.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 2/16.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 2/17.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 2/18.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 2/19.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 2/20.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 2/21.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 2/22.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 2/23.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 2/24.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 2/25.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 2/26.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 2/27.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 2/28.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 2/29.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 2/30.jpg" />
          </div>
        </div>
		    <p>
          This is Step 3 Port Bouet et the Public Conference in our HQ the final point of the End of 
          One week for Goodwill in Ivory Coast from Feb. 19th, to 26th 2022
          </br></br>
          Opening Ceremony Speech. We are grateful for our Chiefs.
		  
		    <div class="gg-container" style="padding: 0 30px;">
          <div class="gg-box gallery2 goodwill-gallery">
            <img src="https://www.kluvcoin.io/img/Innocent Step 3/1.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 3/2.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 3/3.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 3/4.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 3/5.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 3/6.jpg" />
          </div>
        </div>
		  
		    People who attended the event and the recipient of FOOD Kits
		  
        <div class="gg-container" style="padding: 0 30px;">
          <div class="gg-box gallery2 goodwill-gallery">
            <img src="https://www.kluvcoin.io/img/Innocent Step 3/7.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 3/8.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 3/9.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 3/10.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 3/11.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 3/12.jpg" />
          </div>
        </div>
		  
		    Let's practice the culture of Sharing and Respect for Human Dignity
		    <div class="gg-container" style="padding: 0 30px;">
          <div class="gg-box gallery2 goodwill-gallery">
            <img src="https://www.kluvcoin.io/img/Innocent Step 3/13.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 3/14.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 3/15.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 3/16.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 3/17.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 3/18.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 3/18.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 3/19.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 3/20.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 3/21.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 3/22.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 3/23.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 3/24.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 3/25.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 3/26.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 3/27.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 3/28.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 3/29.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 3/30.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 3/31.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 3/32.jpg" />
          </div>
        </div>
		    Let's practice the culture of Sharing and Respect for Human Dignity to newborns and their mothers at the maternity hospital of Port Bouet
		    <div class="gg-container" style="padding: 0 30px;">
          <div class="gg-box gallery2 goodwill-gallery">
            <img src="https://www.kluvcoin.io/img/Innocent Step 3/33.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 3/34.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 3/35.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 3/36.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 3/37.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 3/38.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 3/39.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 3/40.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 3/41.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 3/42.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 3/43.jpg" />
          </div>
        </div>
		
		    Victory Day! Celebration of a Week of Food Sharing to Poor and Needy Families and the TBC Public Conference
		    <div class="gg-container" style="padding: 0 30px;">
          <div class="gg-box gallery2 goodwill-gallery">
            <img src="https://www.kluvcoin.io/img/Innocent Step 3/44.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 3/45.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 3/46.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 3/47.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 3/48.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 3/49.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 3/50.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 3/51.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 3/52.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 3/53.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 3/54.jpg" />
          </div>
        </div>
     
		    Published Articles and Buzz About the Events!
        <div class="gg-container" style="padding: 0 30px;">
          <div class="gg-box gallery2 goodwill-gallery">
            <img src="https://www.kluvcoin.io/img/Innocent Step 3/55.jpg" />
            <img src="https://www.kluvcoin.io/img/Innocent Step 3/56.jpg" />
          </div>
        </div>
		
		    </br>
		    <a href = 'https://www.kluvcoin.io/img/Innocent%20Step%203/NOTRE-VOIE-6813_-see-page-6.pdf' target='_blank'>Read also the published article in NOTRE-VOIE-6813 (See Page 6)</a>
		    </br></br></br>
		    The TBC Music!
		    </br>
		    <iframe width="560" height="315" src="https://www.youtube.com/embed/SAWGaOmJFMU" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
		
		    </br>
      </p>
        <hr/>
		    <h2>Here are the videos from the ceremonies.</h2>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/v1msAybjHNI" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/SIlI6FJZ-OE" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/e3BTChDEX9E" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/fnDejqDv83g" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/DetjTOj_I0I" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/NsPQ_uwVApQ" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/5-Ap7TMMxyk" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/5Kz_dUtHyxg" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/1fbB2jilZ3U" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/CcurlwnocW0" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/gQpHies5mec" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/qKQJvBwzK7Y" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/eH9JUBGz21c" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/g1r8vdOPEtA" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/9D36g0w6QBU" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/P2iKoSTswSs" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/R1CSSYlbjqI" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/ssh7T9vjOVk" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
      </div>
    </div>

    <script src="js/grid-gallery.min.js"></script>
    <script>
      gridGallery({
        selector: ".gallery",
        darkMode: true,
        layout: "square",
        gapLength: 10,
        rowHeight: 300,
        columnWidth: 300
      });
      gridGallery({
        selector: ".gallery2",
        darkMode: true,
        layout: "square",
        gapLength: 10,
        rowHeight: 300,
        columnWidth: 300
      });
    </script>
  </body>
</html>