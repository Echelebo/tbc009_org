<html>
<title>Kringle.Cash</title>
<head>
    <meta http-equiv="Content-Type" content="application/xhtml+xml; charset=UTF-8" />
    <link rel="shortcut icon" href="favicon.ico" />
    <!-- mobile settings -->
    <meta name="viewport" content="width=device-width, maximum-scale=1, initial-scale=1, user-scalable=0" />	
    <meta property="og:image" content="https://kringle.cash/images/linkimage2c.jpg" />
	<meta property="og:description" content="Become a Millionaire automatically FREE of CHARGE.   This Cash Giveaway expires soon!  Click NOW and collect your GIFT!" />
	<meta property="og:url" content="https://kringle.cash/" />
    <meta property="og:title" content="Kringle.Cash" />
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css"/>
      
      <script type="text/javascript" src="js/jquery.js"></script> 
	  <script type="text/javascript" src="js/bootstrap.js"></script>
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
	<style>

	</style>
    <link href="css/style.css" media="screen" rel="stylesheet" type="text/css">
    <link href="css/ownstyle.css" media="screen" rel="stylesheet" type="text/css">
    <link href="css/mystyle.css" media="screen" rel="stylesheet" type="text/css">
    <link href="css/info1.css" media="screen" rel="stylesheet" type="text/css">
    <script type="text/javascript">
        function googleTranslateElementInit() {
            new google.translate.TranslateElement({pageLanguage: 'en', layout: google.translate.TranslateElement.InlineLayout.SIMPLE}, 'google_translate_element');
        }
    </script>
    <script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
    <!--<div id="google_translate_element"></div>-->
    <style>
        .goog-te-menu-value img {
           display: none;
        }
        .goog-te-gadget-simple img {
        background-image: url('images/KringleCoin.gif')!important;
        }
    </style>
</head>
<body>
<header>
    <div class="header-top" id="menuUser">
        <div class="container">
            <div class="row">
                <div class="col">
                <!--<div class="col-sm-2 col-xs-12" style="width: 13.666667%;    margin-top: -3px;" id="google_translate_element">
                </div>-->
                <div class="float-right" style="display: inline-block;margin-right: 16px;height: 36px;float: right;">
                    <div id="google_translate_element"></div>
                </div>
                    </div>
            </div>
        </div>
    </div>
</header>


<style type="text/css">
   
    h1 {
        color: #00F;
        font-family: "Monotype Corsiva";
        font-style: italic;
        font-weight: bold;
        text-decoration: none;
        font-size: 26pt;
    }

    h2 {
        color: #F00;
        font-family: "Monotype Corsiva";
        font-style: italic;
        font-weight: bold;
        text-decoration: none;
        font-size: 16pt;
    }

    .s1 {
        color: #000090;
        font-family: "Adobe Caslon Pro Bold", serif;
        font-style: normal;
        font-weight: bold;
        text-decoration: none;
        font-size: 16pt;
    }

    .p, p {
        color: #000090;
        font-family: Cambria, serif;
        font-style: normal;
        font-weight: normal;
        text-decoration: none;
        font-size: 12pt;
        margin: 0pt;
    }

    .s2 {
        color: #000090;
        font-family: Cambria, serif;
        font-style: normal;
        font-weight: normal;
        text-decoration: none;
        font-size: 12pt;
    }

    .s3 {
        color: #000090;
        font-family: Cambria, serif;
        font-style: normal;
        font-weight: normal;
        text-decoration: none;
        font-size: 8pt;
        vertical-align: 3pt;
    }

    .s4 {
        color: #000090;
        font-family: Cambria, serif;
        font-style: normal;
        font-weight: normal;
        text-decoration: none;
        font-size: 8pt;
    }

    a {
        color: #00F;
        font-family: Calibri, sans-serif;
        font-style: normal;
        font-weight: normal;
        text-decoration: underline;
        font-size: 10pt;
    }

    .s6 {
        color: #00F;
        font-family: Cambria, serif;
        font-style: normal;
        font-weight: normal;
        text-decoration: underline;
        font-size: 12pt;
    }

    li {
        display: block;
    }

	#l1 {
        padding-left: 0pt;
    }

    #l1 > li:before {
        content: " ";
        color: #000090;
        font-family: Wingdings;
        font-style: normal;
        font-weight: normal;
        text-decoration: none;
        font-size: 12pt;
    }

	body {
        background-image: url(images/notice_back.jpg); 
        background-repeat:repeat;
	}
</style>
<style>
	.embed-container { position: relative; padding-bottom: 56.25%; height: 0; overflow: hidden; max-width: 100%; }
	.embed-container iframe, .embed-container object, .embed-container embed { position: absolute; top: 0; left: 0; width: 100%; height: 100%; }
	</style>


	
	<div class="container text-center">

		<div class="row">
			<div class="col">

				<br />
				<img src="Kringle-armorial-1A--doc-version.png" class="img-fluid" />
				<br />
				<br />
				<br />
				<h1 style="text-align: center;">Kringle Private Society “The  Billion Coin”</h1>
				<h2 style="text-align: center;">A Global Sharing &amp; Eleemosynary Society</h2>
				<p class="s1" style="text-align: center;">Kringle Society Mission Statement</p>
				<p style="padding-top: 13pt;padding-left: 5pt;text-indent: 0pt;line-height: 114%;text-align: justify;">The Kringle Society is a global initiative as a Sharing and Eleemosynary Society founded upon the principle that humanity is capable of lifting itself out of the morass of poverty, disease, lack, limitation, suffering and ignorance into a new dawn of abundance and prosperity for all. We are here to empower each of our members with the means to spread abundance, in all its forms, to the entire community of humanity with a clear plan to eliminate poverty worldwide and to assist each and every being that we touch to find their unique purpose that their Creator intended for them. The Kringle Sharing and Eleemosynary Society is here to support all of its members, and all of humanity, by providing the means and methods to have the support and practical tools so that every member of our society and every human being shall have what they need to make manifest their essential needs to create lives of abundance and integrity.</p>
				<p>
					<a href="https://kringle.cash/publicnotice.php#ksmstextversion" target="_blank">...Click Here to Read More...</a>
				</p>

				<br />
			</div>
		</div>
		
		
<div class="row">
			<div class="col">
				<br />
				<br />
				<br />
				<br />

			</div>
		</div>

		
<div class="row">
			<div class="col">
				<br />
				<br />
				<br />
				<h3>CONGRATULATIONS to Augustine Obidimma who has accepted the calling to become the newest Goodwill Ambassador for Nigeria.</h3>
				<br />

			</div>
		</div>

		<div class="row">
			<div class="col">
			
				<img class="img-fluid" alt="" src="/content/img/photo_2022-03-30_18-53-21.jpg" />
			
			
				<p style="padding-top: 13pt;padding-left: 5pt;text-indent: 0pt;line-height: 200%;text-align: justify;">
					<span style="color:#000000">
						<span style="font-size:22px">Augustine Obidimma has accepted the calling to become the newest Goodwill Ambassador for Nigeria. This is not the first time the Kringle Society has spread Goodwill in Nigeria.  Early 2020 $21,000.00 of Goodwill was spread over three locations; $7,000.00 each by the Kringle Society.  It only took about 9 weeks since the launch of the KLUV Coin and that with less than 1,200 people that have bought it, KLUV raised $50,000. ($10,000 was used in Ivory Coast in February and another $10,000 was used in March for India.  $10,000 will be used in Mid-April for Bangladesh and $10,000 will be used at the end of April for Cameroon). That's amazing; KLUV has already raised $50,000 to buy food for the needy under the Kringle Society Goodwill program.   Since 2020, the TBC community in Nigeria has become divided, so perhaps this new Ambassador will reunite them as the TBC Admin continues to show favor to those in Nigeria.  $10,000 of food will be distributed to the poor and needy of Abuja Nigeria on May 21st, 2022.
						</br>
        </p></span>
				</p>

				<p></p>
				<hr />
				<p></p>
				<p></p>

			</div>
		</div>


		<div class="row">
			<div class="col">
			
				<img class="img-fluid" alt="" src="/goodwill/photo_2022-03-16_16-52-11.jpg" />
			
			
				<p style="padding-top: 13pt;padding-left: 5pt;text-indent: 0pt;line-height: 200%;text-align: justify;">
					<span style="color:#000000">
						<span style="font-size:22px">With over 600 Members of the Core Team coming from Cameroon they deserve a second round of Goodwill lead by one of the original Ambassadors Mbeh Derick.  CONGRATULATIONS CAMEROON!  In less than 9 weeks KLUV has been able to pull out $40,000.00 from the market to support the Goodwill Efforts of the Kringle Society.  $10,000.00 of that will be spent on food to feed the poor in Cameroon on April 30th, 2022.
						</br>
        </p></span>
				</p>

				<p></p>
				<hr />
				<p></p>
				<p></p>

			</div>
		</div>
		
		
		
		
<div class="row">
			<div class="col">
				<br />
				<br />
				<br />
				<h3>CONGRATULATIONS SALEH AHMED MIAH for Accepting the Calling to Become Our Newest Goodwill Ambassador for Bangladesh</h3>
				<br />

			</div>
		</div>

		<div class="row">
			<div class="col">
			
				<img class="img-fluid" alt="" src="/content/img/saleh.jpeg" />
			
			
				<p style="padding-top: 13pt;padding-left: 5pt;text-indent: 0pt;line-height: 200%;text-align: justify;">
					<span style="color:#000000">
						<span style="font-size:22px">SALEH AHMED MIAH aka TBC Champion has accepted the calling to become our newest Goodwill Ambassador for Bangladesh. It only took about 6 weeks since the launch of the KLUV Coin and that with less than 1,000 people that have bought it, they raised $30,000.  ($10,000 was used in Ivory Coast in February and another $10,000 will be used in March for India).  That’s amazing; KLUV has already raised $30,000 to buy food for the needy under the Kringle Society Goodwill program. $10,000 of food will be distributed to the poor and needy of an area of Bangladesh on April 16th, 2022.
						</br>
        </p></span>
				</p>

				<p></p>
				<hr />
				<p></p>
				<p></p>

			</div>
		</div>


				
<div class="row">
			<div class="col">
				<br />
				<br />
				<br />
				<h3>CONGRATULATIONS Syed Rahman for Accepting the Calling to Become Our Newest Goodwill Ambassador for India </h3>
				<br />

			</div>
		</div>

		<div class="row">
			<div class="col">
			
				<img class="img-fluid" alt="" src="/content/img/syed.jpeg" />
			
			
				<p style="padding-top: 13pt;padding-left: 5pt;text-indent: 0pt;line-height: 200%;text-align: justify;">
					<span style="color:#000000">
						<span style="font-size:22px">Syed Rahman has accepted the calling to become our newest Goodwill Ambassador for India. It only took a month since the launch of the KLUV Coin and that with less than 1,000 people that have bought it, they raised $20,000.  ($10,000 was used in Ivory Coast in February).  That’s amazing; KLUV has already raised $20,000 to buy food for the needy under the Kringle Society Goodwill program. $10,000 of food will be distributed to the poor and needy of an area of India on March 26th, 2022.
						</br>
						</br>
                    $10,000 of BNB was sent to Ambassador Syed Rahman of India on March 20th, 2022 to purchase food: 
                    <a href="https://bscscan.com/tx/0x8205485d543fd33bdeeaa4163335bab336a80098673c1c97f068a1249e7a078f?fbclid=IwAR1EThZSHSZ3TyuL1JF9Y2liF8krBmLbf4nX92AZlq-KO9ytrzCufkmN6zU" target="new">
                    View Transaction</a>
                    </br></br>
        </p></span>
				</p>

				<p></p>
				<hr />
				<p></p>
				<p></p>

			</div>
		</div>


		
<div class="row">
			<div class="col">
				<br />
				<br />
				<br />
				<h3>Announcement of New Goodwill Ambassador Innocent Keiba</h3>
				<br />

			</div>
		</div>

		<div class="row">
			<div class="col">
			
				<img class="img-fluid" alt="" src="/content/img/photo_2022-01-27_18-30-06.jpg" />
			
			
				<p style="padding-top: 13pt;padding-left: 5pt;text-indent: 0pt;line-height: 200%;text-align: justify;">
					<span style="color:#000000">
						<span style="font-size:22px">Innocent Keiba has accepted the calling to become our newest Goodwill Ambassador for Ivory Coast.  It only took a week since the launch of the KLUV Coin and with only about 500 people that have bought it they raised $10,000.  That’s amazing; KLUV has already raised $10,000 to buy food for the needy under the Kringle Society Goodwill program.  The food will be distributed to the poor and needy on February 19th, 2022.
						</br>
</br>
                    $10,000 of BNB was sent to Ambassador Innocent Keiba on February 14th, 2022 to purchase food: 
                    <a href="https://bscscan.com/tx/0x5a62c6d22cf621a9dc73ba98a979a90e6fb4f9c137459464bf8ca1a0fd3a055f" target="new">
                    View Transaction</a>
                    </br></br>
                    
              <b>Receipts:</b>
              <br/><br/>      
             <p style="text-align:center">
            <img class="img-fluid" alt="" src="content/img/Goodwill/innocentreceipt/1.jpg" />
            <img class="img-fluid" alt="" src="content/img/Goodwill/innocentreceipt/2.jpg" />
            <img class="img-fluid" alt="" src="content/img/Goodwill/innocentreceipt/3.jpg" />
            <img class="img-fluid" alt="" src="content/img/Goodwill/innocentreceipt/4.jpg" />
            <img class="img-fluid" alt="" src="content/img/Goodwill/innocentreceipt/5.jpg" />
			<img class="img-fluid" alt="" src="content/img/Goodwill/innocentreceipt/6.jpg" />
			<img class="img-fluid" alt="" src="content/img/Goodwill/innocentreceipt/7.jpg" />
			<img class="img-fluid" alt="" src="content/img/Goodwill/innocentreceipt/8.png" />
			</p>
              <br/><br/>   
              <p style="padding-top: 13pt;padding-left: 5pt;text-indent: 0pt;line-height: 200%;text-align: justify;">
					<span style="color:#000000">
						<span style="font-size:22px">
		      <b>TBC Goodwill report for Ivory Coast by KEIBA N. Innocent</b><br/><br/>
		      
          Very concerned about increasingly degraded and degrading human relations, the Administrator of 
          TBC is implementing a personal development plan within the community to enable each member to 
          embody the Culture of LOVE of Sharing and RESPECT for human dignity.<br/>
          To make this program a success and offer members the opportunity in each country to experience 
          these two fundamental criteria of the Kringle community, the TBC Administrator relies on the 
          ambassadors to organize the distribution of food and not to live with the lowest social strata. 
          more vulnerable. This is what was launched here in Côte d'Ivoire to provide food and non-food 
          items to more than 800 families and 5 institutes (3 orphanages, 1 institute for the blind and 2 
          associations (widows and disabled)<br/>
          This goodwill program was first initiated in March in Nigeria with the two goodwill ambassadors 
          Steven Cuffee and Mbeh Derick. Because of the COVID scam.
          This program has been suspended. Thanks to the great determination of the Administrator of TBC 
          and to see real Leaders tomorrow leading this world towards a better horizon, he puts an 
          infallible strategy for the continuation of the GOODWILL program in the rest of the world. It 
          opens the Community to the public market with the sensational KLUV token and allows us to 
          organize the 3rd world stage of GOOWILL after only 1 month. It should be noted that the TBC 
          administrator sent funds worth $10,000 to Côte d'Ivoire to feed the social strata of vulnerable 
          people.<br/><br/>
          Last February 19, 2022, we are delighted to share these to vulnerable people and institute for 
          the 1st stage in Abobo. Centered on this municipality which is one of the poorest municipalities 
          in the District and which has just over 1,500,000 inhabitants. It's 420 people included orphans 
          (78), handicapped (50: blind-dumb - infirm), widowed women (100), very poor families (192) from 
          the 32 ethnic communities living in the municipality from Abobo. Each of them went home with at 
          least 5 kg of rice, cooking oil and spaghetti.
          For institutes caring for orphaned children who have toilets and play areas to clean, we have 
          added canisters of detergent to keep the play areas clean and protect them from certain 
          infections for a while. Below are some photos from the launch and distribution ceremony in Abobo.
               <br/><br/>      
                    <br/><br/>      <b>Step One: (ABOBO) - The WEEK of GOODWILL in Ivory Coast</b>
        </p>
         
              <br/><br/>      

            <img class="img-fluid" alt="" src="content/img/Goodwill/Innocent Step 1/1.jpg" />
            <img class="img-fluid" alt="" src="content/img/Goodwill/Innocent Step 1/2.jpg" />
            <img class="img-fluid" alt="" src="content/img/Goodwill/Innocent Step 1/3.jpg" />
            <img class="img-fluid" alt="" src="content/img/Goodwill/Innocent Step 1/4.jpg" />
            <img class="img-fluid" alt="" src="content/img/Goodwill/Innocent Step 1/5.jpg" />
            <img class="img-fluid" alt="" src="content/img/Goodwill/Innocent Step 1/6.jpg" />
            <img class="img-fluid" alt="" src="content/img/Goodwill/Innocent Step 1/7.jpg" />
            <img class="img-fluid" alt="" src="content/img/Goodwill/Innocent Step 1/8.jpg" />
            <img class="img-fluid" alt="" src="content/img/Goodwill/Innocent Step 1/9.jpg" />
            <img class="img-fluid" alt="" src="content/img/Goodwill/Innocent Step 1/10.jpg" />
            <img class="img-fluid" alt="" src="content/img/Goodwill/Innocent Step 1/11.jpg" />
            <img class="img-fluid" alt="" src="content/img/Goodwill/Innocent Step 1/12.jpg" />
            <img class="img-fluid" alt="" src="content/img/Goodwill/Innocent Step 1/13.jpg" />
            <img class="img-fluid" alt="" src="content/img/Goodwill/Innocent Step 1/14.jpg" />
            <img class="img-fluid" alt="" src="content/img/Goodwill/Innocent Step 1/15.jpg" />
                          <br/><br/>    
                          </p>
              <p style="padding-top: 13pt;padding-left: 5pt;text-indent: 0pt;line-height: 200%;text-align: justify;">
					<span style="color:#000000">
						<span style="font-size:22px">
                    <br/><br/>      <b>Step Two:Goodwill Event in Yopougon</b><br/><br/>    
                    <p style="text-align:center">
                    
            <img class="img-fluid" alt="" src="content/img/Goodwill/Innocent Step 2/1.jpg" />
            <img class="img-fluid" alt="" src="content/img/Goodwill/Innocent Step 2/2.jpg" />
            <img class="img-fluid" alt="" src="content/img/Goodwill/Innocent Step 2/3.jpg" />
            <img class="img-fluid" alt="" src="content/img/Goodwill/Innocent Step 2/4.jpg" />
            <img class="img-fluid" alt="" src="content/img/Goodwill/Innocent Step 2/5.jpg" />
            <img class="img-fluid" alt="" src="content/img/Goodwill/Innocent Step 2/6.jpg" />
            <img class="img-fluid" alt="" src="content/img/Goodwill/Innocent Step 2/7.jpg" />
            <img class="img-fluid" alt="" src="content/img/Goodwill/Innocent Step 2/8.jpg" />
            <img class="img-fluid" alt="" src="content/img/Goodwill/Innocent Step 2/9.jpg" />
            <img class="img-fluid" alt="" src="content/img/Goodwill/Innocent Step 2/10.jpg" />
            <img class="img-fluid" alt="" src="content/img/Goodwill/Innocent Step 2/11.jpg" />
            <img class="img-fluid" alt="" src="content/img/Goodwill/Innocent Step 2/12.jpg" />
            <img class="img-fluid" alt="" src="content/img/Goodwill/Innocent Step 2/13.jpg" />
            <img class="img-fluid" alt="" src="content/img/Goodwill/Innocent Step 2/14.jpg" />
            <img class="img-fluid" alt="" src="content/img/Goodwill/Innocent Step 2/15.jpg" />
            <img class="img-fluid" alt="" src="content/img/Goodwill/Innocent Step 2/16.jpg" />
            <img class="img-fluid" alt="" src="content/img/Goodwill/Innocent Step 2/17.jpg" />
            <img class="img-fluid" alt="" src="content/img/Goodwill/Innocent Step 2/18.jpg" />
            <img class="img-fluid" alt="" src="content/img/Goodwill/Innocent Step 2/19.jpg" />
            <img class="img-fluid" alt="" src="content/img/Goodwill/Innocent Step 2/20.jpg" />
            <img class="img-fluid" alt="" src="content/img/Goodwill/Innocent Step 2/21.jpg" />
            <img class="img-fluid" alt="" src="content/img/Goodwill/Innocent Step 2/22.jpg" />
            <img class="img-fluid" alt="" src="content/img/Goodwill/Innocent Step 2/23.jpg" />
            <img class="img-fluid" alt="" src="content/img/Goodwill/Innocent Step 2/24.jpg" />
            <img class="img-fluid" alt="" src="content/img/Goodwill/Innocent Step 2/25.jpg" />
            <img class="img-fluid" alt="" src="content/img/Goodwill/Innocent Step 2/26.jpg" />
            <img class="img-fluid" alt="" src="content/img/Goodwill/Innocent Step 2/27.jpg" />
            <img class="img-fluid" alt="" src="content/img/Goodwill/Innocent Step 2/28.jpg" />
            <img class="img-fluid" alt="" src="content/img/Goodwill/Innocent Step 2/29.jpg" />
            <img class="img-fluid" alt="" src="content/img/Goodwill/Innocent Step 2/30.jpg" />
                    
                    
                    
                    
                    
                    
        </p>                          
    <p style="padding-top: 13pt;padding-left: 5pt;text-indent: 0pt;line-height: 200%;text-align: justify;">
					<span style="color:#000000">
						<span style="font-size:22px">
                    <br/><br/>      <b>Step Three: Port Bouet et the Public Conference in our HQ the final point of the End of 
          One week for Goodwill in Ivory Coast from Feb. 19th, to 26th 2022</b><br/><br/>    
          Opening Ceremony Speech. We are grateful for our Chiefs.
          <br/><br/>
                    <p style="text-align:center">
            <img class="img-fluid" alt="" src="content/img/Goodwill/Innocent Step 3/1.jpg" />
            <img class="img-fluid" alt="" src="content/img/Goodwill/Innocent Step 3/2.jpg" />
            <img class="img-fluid" alt="" src="content/img/Goodwill/Innocent Step 3/3.jpg" />
            <img class="img-fluid" alt="" src="content/img/Goodwill/Innocent Step 3/4.jpg" />
            <img class="img-fluid" alt="" src="content/img/Goodwill/Innocent Step 3/5.jpg" />
            <img class="img-fluid" alt="" src="content/img/Goodwill/Innocent Step 3/6.jpg" />                    
        </p>                                                    

<p style="padding-top: 13pt;padding-left: 5pt;text-indent: 0pt;line-height: 200%;text-align: justify;">
					<span style="color:#000000">
						<span style="font-size:22px">
                    <br/><br/>
          People who attended the event and the recipient of FOOD Kits
          <br/><br/>
                    <p style="text-align:center">
            <img class="img-fluid" alt="" src="content/img/Goodwill/Innocent Step 3/7.jpg" />
            <img class="img-fluid" alt="" src="content/img/Goodwill/Innocent Step 3/8.jpg" />
            <img class="img-fluid" alt="" src="content/img/Goodwill/Innocent Step 3/9.jpg" />
            <img class="img-fluid" alt="" src="content/img/Goodwill/Innocent Step 3/10.jpg" />
            <img class="img-fluid" alt="" src="content/img/Goodwill/Innocent Step 3/11.jpg" />
            <img class="img-fluid" alt="" src="content/img/Goodwill/Innocent Step 3/12.jpg" />                 
        </p>                                                    
<p style="padding-top: 13pt;padding-left: 5pt;text-indent: 0pt;line-height: 200%;text-align: justify;">
					<span style="color:#000000">
						<span style="font-size:22px">
                    <br/><br/>
          Let's practice the culture of Sharing and Respect for Human Dignity to newborns and their mothers at the maternity hospital of Port Bouet
          <br/><br/>
                    <p style="text-align:center">
            <img class="img-fluid" alt="" src="content/img/Goodwill/Innocent Step 3/33.jpg" />
            <img class="img-fluid" alt="" src="content/img/Goodwill/Innocent Step 3/34.jpg" />
            <img class="img-fluid" alt="" src="content/img/Goodwill/Innocent Step 3/35.jpg" />
			<img class="img-fluid" alt="" src="content/img/Goodwill/Innocent Step 3/36.jpg" />
			<img class="img-fluid" alt="" src="content/img/Goodwill/Innocent Step 3/37.jpg" />
			<img class="img-fluid" alt="" src="content/img/Goodwill/Innocent Step 3/38.jpg" />
            <img class="img-fluid" alt="" src="content/img/Goodwill/Innocent Step 3/39.jpg" />
			<img class="img-fluid" alt="" src="content/img/Goodwill/Innocent Step 3/40.jpg" />
			<img class="img-fluid" alt="" src="content/img/Goodwill/Innocent Step 3/41.jpg" />
			<img class="img-fluid" alt="" src="content/img/Goodwill/Innocent Step 3/42.jpg" />
			<img class="img-fluid" alt="" src="content/img/Goodwill/Innocent Step 3/43.jpg" />         
        </p>                                                    
<p style="padding-top: 13pt;padding-left: 5pt;text-indent: 0pt;line-height: 200%;text-align: justify;">
					<span style="color:#000000">
						<span style="font-size:22px">
                    <br/><br/>
          Victory Day! Celebration of a Week of Food Sharing to Poor and Needy Families and the TBC Public Conference
          <br/><br/>
                    <p style="text-align:center">
            <img class="img-fluid" alt="" src="content/img/Goodwill/Innocent Step 3/44.jpg" />
            <img class="img-fluid" alt="" src="content/img/Goodwill/Innocent Step 3/45.jpg" />
			<img class="img-fluid" alt="" src="content/img/Goodwill/Innocent Step 3/46.jpg" />
			<img class="img-fluid" alt="" src="content/img/Goodwill/Innocent Step 3/47.jpg" />
			<img class="img-fluid" alt="" src="content/img/Goodwill/Innocent Step 3/48.jpg" />
            <img class="img-fluid" alt="" src="content/img/Goodwill/Innocent Step 3/49.jpg" />
			<img class="img-fluid" alt="" src="content/img/Goodwill/Innocent Step 3/50.jpg" />
			<img class="img-fluid" alt="" src="content/img/Goodwill/Innocent Step 3/51.jpg" />
			<img class="img-fluid" alt="" src="content/img/Goodwill/Innocent Step 3/52.jpg" />
			<img class="img-fluid" alt="" src="content/img/Goodwill/Innocent Step 3/53.jpg" />
			<img class="img-fluid" alt="" src="content/img/Goodwill/Innocent Step 3/54.jpg" />
        </p>                                                    
<p style="padding-top: 13pt;padding-left: 5pt;text-indent: 0pt;line-height: 200%;text-align: justify;">
					<span style="color:#000000">
						<span style="font-size:22px">
                    <br/><br/>
         Published Articles and Buzz About the Events!
          <br/><br/>
                    <p style="text-align:center">
			<img class="img-fluid" alt="" src="content/img/Goodwill/Innocent Step 3/55.jpg" />
			<img class="img-fluid" alt="" src="content/img/Goodwill/Innocent Step 3/56.jpg" />
</br>
</br>
                   <a href = 'https://www.kluvcoin.io/img/Innocent%20Step%203/NOTRE-VOIE-6813_-see-page-6.pdf' target='_blank'>Read also the published article in NOTRE-VOIE-6813 (See Page 6)</a>


        </p>     		
        <p style="padding-top: 13pt;padding-left: 5pt;text-indent: 0pt;line-height: 200%;text-align: justify;">
					<span style="color:#000000">
						<span style="font-size:22px">
                    <br/><br/>
		The TBC Music!
		</br>
		</br>
		<p style="text-align:center">
		 <iframe width="560" height="315" src="https://www.youtube.com/embed/SAWGaOmJFMU" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
		
		</br>
		   
		   <p style="padding-top: 13pt;padding-left: 5pt;text-indent: 0pt;line-height: 200%;text-align: justify;">
					<span style="color:#000000">
						<span style="font-size:22px">
                    <br/><br/>
         	    Here are the videos from the ceremonies.
         	    <br/><br/>
         	    <p style="text-align:center">
        <iframe width="560" height="315" src="https://www.youtube.com/embed/v1msAybjHNI" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/SIlI6FJZ-OE" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/e3BTChDEX9E" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/fnDejqDv83g" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/DetjTOj_I0I" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/NsPQ_uwVApQ" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/5-Ap7TMMxyk" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/5Kz_dUtHyxg" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/1fbB2jilZ3U" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/CcurlwnocW0" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/gQpHies5mec" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/qKQJvBwzK7Y" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/eH9JUBGz21c" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/g1r8vdOPEtA" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/9D36g0w6QBU" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/P2iKoSTswSs" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/R1CSSYlbjqI" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/ssh7T9vjOVk" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>






        </p></span>
				</p>

				<p></p>
				<hr />
				<p></p>
				<p></p>

			</div>
		</div>

		<div class="row">
			<div class="col">
				<br />
				<br />
				<br />
				<h3>TBC Goodwill Ambassadors (Poster/Article)</h3>
				<br />

			</div>
		</div>

		<div class="row">
			<div class="col">
			
				<img class="img-fluid" alt="" src="/portal/blog/blogimages/userfiles/images/GOODWILL-AMBASSADORS-FOR-TBC.jpg" />
			
			
				<p style="padding-top: 13pt;padding-left: 5pt;text-indent: 0pt;line-height: 200%;text-align: justify;">
					<span style="color:#000000">
						<span style="font-size:22px">I'm proud to announce the first two Goodwill Ambassadors for the TBC Community:  Steven Cuffee and Mbeh Derick.  The loyalty and consistency of these two TBC leaders has lead to their selections to play this special role.  Both have hearts of gold and are very much cause driven when it comes to TBC.</span>
					</span>
				</p>

				<p style="padding-top: 13pt;padding-left: 5pt;text-indent: 0pt;line-height: 200%;text-align: justify;">
					<span style="color:#000000">
						<span style="font-size:22px">This marks the official announcement of the role of a TBC Goodwill Ambassador.  As of January 1st, 2020 I have been setting aside 10% of the revenue that comes in through the Admin fees to be used to feed and bless the lives of the poor.  Obviously, we are NOT big enough yet to feed all of the poor people in the world, even though within our combined hearts we would gladly do that if we had the means.  It is our GOODWILL towards mankind that we do our part to feed the poor, and make a difference for the lives we can touch through this effort.  Picture a line of poor people waiting their turn to receive 2 bags of groceries, which may feed their family for a week or two.  A TBC Goodwill Ambassador will assist in the selection of the poor we shall feed, and they will be present in person as we make this donation to them.  They stand in as a representitive of all of us in TBC, from the Admin/Creator all the way down to our newest member that just joined us.  They are our Goodwill Ambassadors of TBC!</span>
					</span>
				</p>

				<p style="padding-top: 13pt;padding-left: 5pt;text-indent: 0pt;line-height: 200%;text-align: justify;">
					<span style="color:#000000">
						<span style="font-size:22px">My vision of this part of TBC is much bigger than most of you can imagine.  But 10% can one day be a very large and significant number.  It's all relative, the bigger we get the more we can help others.  Also, as we grow and expand this part of TBC, I will be personally calling on other leaders to carry out this role too.  The future will be even brighter for all of us because of this special calling.  Prepare yourself to one day be called to be a TBC Goodwill Ambassador.</span>
					</span>
				</p>

				<p style="padding-top: 13pt;padding-left: 5pt;text-indent: 0pt;line-height: 200%;text-align: justify;">
					<span style="color:#000000">
						<span style="font-size:22px">When playing the role of Ambassador, all travel expenses are prepaid and a stipend provided to compensate for the time.  So, it is NOT a role of self-sacrifice.  The role is meant to be seen as a reward for good leadership.  It is a true honor to be an Ambassador!</span>
					</span>
				</p>

				<p style="padding-top: 13pt;padding-left: 5pt;text-indent: 0pt;line-height: 200%;text-align: justify;">
					<span style="color:#000000">
						<span style="font-size:22px">Nigeria will be our first country on the list of many that will receive this Goodwill.  Remember, that it is Goodwill because the receivers of the bags of groceries are ALL NON-MEMBERS of TBC.  Goodwill is NOT self-serving.  In contrast, our members each enjoy the fruits of the Distribution Phase of TBC and the Bitcoin Bounty Income Ladders out of poverty.  Dr. Solo has been working tirelessly with a team of leaders to hold 6 events in 3 locations within Nigeria in the early part of March, 2020.  Both Mbeh and Steven have been invited.  Regardless, at least one of our Ambassadors will be present for each of the Goodwill Events.  Seats at these Goodwill Events are limited and are open to the public free of charge.  I have earmarked $20,000.00 to be used to buy the groceries to cover all three events.  Cameroon is the next country on the list, and Mbeh has already identified some poor that even have extraordinary circumstances--truly sad stories of people in great need.  $10,000.00 of aid has been earmarked for these people in Cameroon.  A great deal of effort has been made to get Steven into both countries, and we are waiting on the embassies to process the VISA for each, hopefully in time!  Early March is fast approching!  I have already prepaid for Steven to go to both Nigeria and Cameroon, and can assure you all his trip will be safe.  I will be working with Mbeh this week to prepay for his travel to Nigeria which will include his wife, this time.  </span>
					</span>
				</p>

				<p style="padding-top: 13pt;padding-left: 5pt;text-indent: 0pt;line-height: 200%;text-align: justify;">
					<span style="color:#000000">
						<span style="font-size:22px">I hope this Goodwill Ambassadorship is well received by both member and non-member alike.  TBC stands for so many things, and let this act show the world that we mean what we say.  It is just a matter of time before we fulfill all that we have set out to do in TBC.  May the blessings from heaven rain down upon us as we do this great work.</span>
					</span>
				</p>
				<p></p>
				<hr />
				<p></p>
				<p></p>

			</div>
		</div>

	<div class="row">
		<div class="col">
			<br />
			<br />
			<br />
			<h3>MBEH DERRICK - TBC GOODWILL AMBASSADOR REPORT</h3>
			<br />
		</div>
	</div>
	<div class="row">
		<div class="col">
			<p style="padding-top: 13pt;padding-left: 5pt;text-indent: 0pt;line-height: 200%;text-align: justify;">
				<span style="color:#000000">
					<span style="font-size:22px">First of all before I put down my first ever official report as the TBC Goodwill Ambassador,  I want to thank the TBC Admin for giving me this opportunity of becoming one of the TBC Goodwill Ambassadors in the TBC community.  My wife and I are so grateful and it shall always be our pleasure to serve the community.</span>
				</span>
			</p>

			<p style="padding-top: 13pt;padding-left: 5pt;text-indent: 0pt;line-height: 200%;text-align: justify;">
				<span style="color:#000000">
					<span style="font-size:22px">My wife and I arrived Nigeria on the 1st of march 2020 and we were given a warm reception by the general coordinator of this event Dr. Solo and his team.  It should be Noted that Admin sent food worth $21 000 and it was divided to feed the poor in three locations , the east, the north and the south part of the country.</span>
				</span>
			</p>

			<p style="padding-top: 13pt;padding-left: 5pt;text-indent: 0pt;line-height: 200%;text-align: justify;">
				<span style="color:#000000">
					<span style="font-size:22px">We arrived the East, that’s Enugu on the 2nd of march and after a Press Conference we traveled to Abakaliki and fed over 200 persons gathered at Central School Ngbo in Ebonyi State.</span>
				</span>
			</p>
			<br />
			<p style="text-align:center">
				<img alt="" src="/goodwill/gwmbeh001.jpg" class="img-fluid" />
			</p>
			<br />
			<p style="text-align:center">
				<img alt="" src="/goodwill/gwmbeh002.jpg" class="img-fluid" />
			</p>
			<br />
			<p style="text-align:center">
				<img alt="" src="/goodwill/gwmbeh003.jpg" class="img-fluid" />
			</p>
			<br />
			<p style="padding-top: 13pt;padding-left: 5pt;text-indent: 0pt;line-height: 200%;text-align: justify;">
				<span style="color:#000000">
					<span style="font-size:22px">The above pictures are some of the people we fed at our first location.  I MUST confess that when my Team and I saw these people wept.  Their situations are beyond our imaginations.  As you can see from these images, some suffers from chronic health conditions, like persons with paraplegia, also people with cognitive disabilities, and people with intellectual disabilities such as people with down syndrome.  We also have wheelchair users just to mentioned a few.  We wept again while sharing these food items because we strongly believe that some particular group of humans should not lack the minimum which is food, not to mention that of medical attention.  Some of the mothers after receiving this food we witnessed tears of joy coming from them, and some even prayed like they speak a language we do not really understand.  I would say they prayed in tongues to thank us.  Once more, thank you TBC admin for this great initiative.</span>
				</span>
			</p>

			<p style="padding-top: 13pt;padding-left: 5pt;text-indent: 0pt;line-height: 200%;text-align: justify;">
				<span style="color:#000000">
					<span style="font-size:22px">The next location still in the East was the Federal Teaching Hospital in Abakaliki  where we shared food to over 300 sick persons and their care givers.  You can see from the Pictures below:</span>
				</span>
			</p>
			<br />
			<p style="text-align:center">
				<img alt="" src="/goodwill/gwmbeh004.jpg" class="img-fluid" />
			</p>
			<br />
			<p style="text-align:center">
				<img alt="" src="/goodwill/gwmbeh005.jpg" class="img-fluid" />
			</p>
			<br />
			<p style="text-align:center">
				<img alt="" src="/goodwill/gwmbeh006.jpg" class="img-fluid" />
			</p>
			<br />
			<p style="text-align:center">
				<img alt="" src="/goodwill/gwmbeh007.jpg" class="img-fluid" />
			</p>
			<br />

			<p style="padding-top: 13pt;padding-left: 5pt;text-indent: 0pt;line-height: 200%;text-align: justify;">
				<span style="color:#000000">
					<span style="font-size:22px">The last location was visited with the team leaders in Ebonyi state was here and see some of the Pictures from the Holy Ghost Foundation school in Abakaliki.</span>
				</span>
			</p>
			<br />
			<p style="text-align:center">
				<img alt="" src="/goodwill/gwmbeh008.jpg" class="img-fluid" />
			</p>
			<br />
			<br />
			<p style="text-align:center">
				<img alt="" src="/goodwill/gwmbeh009.jpg" class="img-fluid" />
			</p>
			<br />
			<p style="text-align:center">
				<img alt="" src="/goodwill/gwmbeh010.jpg" class="img-fluid" />
			</p>
			<br />
			<p style="padding-top: 13pt;padding-left: 5pt;text-indent: 0pt;line-height: 200%;text-align: justify;">
				<span style="color:#000000">
					<span style="font-size:22px">It should be noted that my Co-Goodwill Ambassador from the United States (Steven Cuffee) will be joining me in Lagos to perform Goodwill in some local communities there.  And from there we shall be moving to Cameroon.</span>
				</span>
			</p>

			<p style="padding-top: 13pt;padding-left: 5pt;text-indent: 0pt;line-height: 200%;text-align: justify;">
				<span style="color:#000000">
					<span style="font-size:22px">I want to use this opportunity to thank God for giving us our TBC Admin and the inspirations to help the poor.  I want to thank Dr. Solo who made  this possible by managing all of our movement and safety all over Nigeria, I want to also thank Mr. Amaechi and his wife; Mr. Preston Isaac; Ikegwu; Jasper Ndubisi Joshua; Bright; and Marry.  Finally I want to thank all those who help this possible in one way or the other, I have not forgotten the GMC team with Dr. Michael.  I will end here by thanking my wife Dorothy Mbeh who has also been very active during all these events. </span>
				</span>
			</p>
			<br />
			<p style="padding-top: 13pt;padding-left: 5pt;text-indent: 0pt;line-height: 200%;text-align: justify;">
				<span style="color:#000000">
					<span style="font-size:22px">LONG LIVE NIGERIA</span>
				</span>
			</p>
			<p style="padding-top: 13pt;padding-left: 5pt;text-indent: 0pt;line-height: 200%;text-align: justify;">
				<span style="color:#000000">
					<span style="font-size:22px">LONG LIVE TBC</span>
				</span>
			</p>
			<p style="padding-top: 13pt;padding-left: 5pt;text-indent: 0pt;line-height: 200%;text-align: justify;">
				<span style="color:#000000">
					<span style="font-size:22px">LONG LIVE TBC ADMIN</span>
				</span>
			</p>
			<br />
			<p style="padding-top: 13pt;padding-left: 5pt;text-indent: 0pt;line-height: 200%;text-align: justify;">
				<span style="color:#000000">
					<span style="font-size:22px">Mbeh Derrick </span>
				</span>
			</p>

			<br />
			<p style="padding-top: 13pt;padding-left: 5pt;text-indent: 0pt;line-height: 200%;text-align: justify;">
				<span style="color:#000000">
					<span style="font-size:22px">Video of Mbeh's Event</span>
				</span>
			</p>
			<br />
			<div class='embed-container'>
				<iframe src='https://www.youtube.com/embed/Gsp6oKnnT9c' frameborder='0' allowfullscreen></iframe>
			</div>
			
			<br />
			<p style="padding-top: 13pt;padding-left: 5pt;text-indent: 0pt;line-height: 200%;text-align: justify;">
				<span style="color:#000000">
					<span style="font-size:22px">1st Video</span>
				</span>
			</p>
			<br />
			<hr />
			<div class='embed-container'>
				<iframe src='https://www.youtube.com/embed/YHqNJltCtnc' frameborder='0' allowfullscreen></iframe>
			</div>
			
			<br />
			<p style="padding-top: 13pt;padding-left: 5pt;text-indent: 0pt;line-height: 200%;text-align: justify;">
				<span style="color:#000000">
					<span style="font-size:22px">2nd Video</span>
				</span>
			</p>
			<br />
			<hr />
			<div class='embed-container'>
				<iframe src='https://www.youtube.com/embed/2J6CLxjVXO4' frameborder='0' allowfullscreen></iframe>
			</div>
			
			<br />
			<p style="padding-top: 13pt;padding-left: 5pt;text-indent: 0pt;line-height: 200%;text-align: justify;">
				<span style="color:#000000">
					<span style="font-size:22px">3rd Video</span>
				</span>
			</p>
			<br />
			<hr />
			<div class='embed-container'>
				<iframe src='https://www.youtube.com/embed/GC7nl-s4css' frameborder='0' allowfullscreen></iframe>
			</div>
			
			<br />
			<p style="padding-top: 13pt;padding-left: 5pt;text-indent: 0pt;line-height: 200%;text-align: justify;">
				<span style="color:#000000">
					<span style="font-size:22px">4th Video</span>
				</span>
			</p>
			<br />
			<hr />
			<div class='embed-container'>
				<iframe src='https://www.youtube.com/embed/Re7De8SX3po' frameborder='0' allowfullscreen></iframe>
			</div>
			
			<br />
			<p style="padding-top: 13pt;padding-left: 5pt;text-indent: 0pt;line-height: 200%;text-align: justify;">
				<span style="color:#000000">
					<span style="font-size:22px">5th Video</span>
				</span>
			</p>
			<br />
			<hr />
			<div class='embed-container'>
				<iframe src='https://www.youtube.com/embed/P_n8isyIkAg' frameborder='0' allowfullscreen></iframe>
			</div>
			
			<br />
			<p style="padding-top: 13pt;padding-left: 5pt;text-indent: 0pt;line-height: 200%;text-align: justify;">
				<span style="color:#000000">
					<span style="font-size:22px">6th Video</span>
				</span>
			</p>
			<br />
			<hr />
		</div>
	</div>


	<div class="row">
		<div class="col">
			<br />
			<br />
			<br />
			<h3>MBEH DERRICK - TBC GOODWILL AMBASSADOR REPORT #2 FROM ABUJA-NIGERIA</h3>
			<br />
		</div>
	</div>
	<div class="row">
		<div class="col">
			<p style="padding-top: 13pt;padding-left: 5pt;text-indent: 0pt;line-height: 200%;text-align: justify;">
				<span style="color:#000000">
					<span style="font-size:22px">
						After a Press Conference on Friday the 6th of March  2020, we immediately move to Garki, a small town about 5km away from the main city Abuja. From the information, we gathered, its a refugee camp with people that have run from the war (Boko Haram War) in the Northern part of the country.  I must confess here that their living condition is horrible, they lack the basic needs like water and food.  Good shelter is also a very big problem. This lifestyle, along with the uncertainty of how long they will be confined to these camps has a grave effect on their mental health conditions.
                        The coordinators and the victims in the camp were so happy and grateful to the TBC Admin for this gesture.  Many of them confess that they have not received this kind of gesture for so long.  Thanks you so much Admin, for putting a smile on the faces of these victims.  The camp leaders suddenly became interested in TBC, and the Abuja coordinators promise to sign them up.
					</span>
				</span>
			</p>
			<br />
			<p style="text-align:center">
				<img alt="" src="/goodwill/mbehreport2-1.jpg" class="img-fluid" />
			</p>
			<br />
			<p style="text-align:center">
				<img alt="" src="/goodwill/mbehreport2-3.jpg" class="img-fluid" />
			</p>
			<br />
			<p style="padding-top: 13pt;padding-left: 5pt;text-indent: 0pt;line-height: 200%;text-align: justify;">
				<span style="color:#000000">
					<span style="font-size:22px">Thank you TBC Admin for all that you are doing in the community.  May you remain blessed.</span>
				</span>
			</p>
			<br />
			<p style="padding-top: 13pt;padding-left: 5pt;text-indent: 0pt;line-height: 200%;text-align: justify;">
				<span style="color:#000000">
					<span style="font-size:22px">Mbeh Derrick </span>
				</span>
			</p>

			<br />
			<p style="padding-top: 13pt;padding-left: 5pt;text-indent: 0pt;line-height: 200%;text-align: justify;">
				<span style="color:#000000">
					<span style="font-size:22px">Video of Mbeh's 2nd Event</span>
				</span>
			</p>
			<br />
			<div class='embed-container'>
				<iframe src='https://www.youtube.com/embed/IxANbhHdZag' frameborder='0' allowfullscreen></iframe>
			</div>
			
			<br />
			<p style="padding-top: 13pt;padding-left: 5pt;text-indent: 0pt;line-height: 200%;text-align: justify;">
				<span style="color:#000000">
					<span style="font-size:22px">1st Video</span>
				</span>
			</p>
			<br />
			<hr />
			<div class='embed-container'>
				<iframe src='https://www.youtube.com/embed/fp4xlWYlqpQ' frameborder='0' allowfullscreen></iframe>
			</div>
			
			<br />
			<p style="padding-top: 13pt;padding-left: 5pt;text-indent: 0pt;line-height: 200%;text-align: justify;">
				<span style="color:#000000">
					<span style="font-size:22px">2nd Video</span>
				</span>
			</p>
			<br />
			<hr />
			<div class='embed-container'>
				<iframe src='https://www.youtube.com/embed/OrKJivIwqXc' frameborder='0' allowfullscreen></iframe>
			</div>
			
			<br />
			<p style="padding-top: 13pt;padding-left: 5pt;text-indent: 0pt;line-height: 200%;text-align: justify;">
				<span style="color:#000000">
					<span style="font-size:22px">3rd Video</span>
				</span>
			</p>
			<br />
			<hr />
			<div class='embed-container'>
				<iframe src='https://www.youtube.com/embed/BU01w-K9i5g' frameborder='0' allowfullscreen></iframe>
			</div>
			
			<br />
			<p style="padding-top: 13pt;padding-left: 5pt;text-indent: 0pt;line-height: 200%;text-align: justify;">
				<span style="color:#000000">
					<span style="font-size:22px">4th Video</span>
				</span>
			</p>
			<br />
			<hr />
			<div class='embed-container'>
				<iframe src='https://www.youtube.com/embed/VsUN9cOzK3M' frameborder='0' allowfullscreen></iframe>
			</div>
			
			<br />
			<p style="padding-top: 13pt;padding-left: 5pt;text-indent: 0pt;line-height: 200%;text-align: justify;">
				<span style="color:#000000">
					<span style="font-size:22px">5th Video</span>
				</span>
			</p>
			<br />
			<hr />
			<div class='embed-container'>
				<iframe src='https://www.youtube.com/embed/UrPu-0FlrB8' frameborder='0' allowfullscreen></iframe>
			</div>
			
			<br />
			<p style="padding-top: 13pt;padding-left: 5pt;text-indent: 0pt;line-height: 200%;text-align: justify;">
				<span style="color:#000000">
					<span style="font-size:22px">6th Video</span>
				</span>
			</p>
			<br />
			<hr />
		</div>

	</div>

	<div class="row">
		<div class="col">
			<br />
			<br />
			<br />
			<h3>Steven T. Cuffee----TBC Ambassador</h3>
			<br />

		</div>
	</div>
	<div class="row">
		<div class="col">
			<p style="padding-top: 13pt;padding-left: 5pt;text-indent: 0pt;line-height: 200%;text-align: justify;">
				<span style="color:#000000">
					<span style="font-size:22px">First of I would like to thank our wonderful TBC admin for selecting me as TBC Ambassador.  It has been truly a blessing and an honor.  Even though, the challenges that I went through to receive the proper Visas to go to Africa, it was all worth it to be a visitor of Nigeria and Cameroon. </span>
				</span>
			</p>
			<br />
			<p style="padding-top: 13pt;padding-left: 5pt;text-indent: 0pt;line-height: 200%;text-align: justify;">
				<span style="color:#000000">
					<span style="font-size:22px">I arrived on March 9, 2020 in Nigeria and was surprised to finally be on African soil, a lifelong dream of mine.  I was received by a warm reception by the general coordinator Dr. Solo for the Nigerian Mass Adoption Conference and many of our TBC family that I knew through TBC Broadcasts.  Then as I arrived at my hotel, I was surprised again by more of our TBC family.  Mbeh Derick’s wife, Dorothy escorted me up to their room and that is where I saw and met with TBC Ambassador and Global Trainer Mbeh Derick, who had just finished an online training.</span>
				</span>
			</p>
			<br />
			<p style="padding-top: 13pt;padding-left: 5pt;text-indent: 0pt;line-height: 200%;text-align: justify;">
				<span style="color:#000000">
					<span style="font-size:22px">Below you will see photos of two areas in Lagos, Nigeria where we fed many people in poverty.  It really touched my heart to see the expression of gratitude from the people of the village to receive this food.  Many of the people had not eaten in days.  Some of the people had tears in their eyes. </span>
				</span>
			</p>
			<br />
			<p style="text-align:center">
				<img alt="" src="/goodwill/steve01.jpg" class="img-fluid" />
			</p>
			
			<br />
			<p style="text-align:center">
				<img alt="" src="/goodwill/steve02.jpg" class="img-fluid" />
			</p>
			<br />
			<p style="text-align:center">
				<img alt="" src="/goodwill/steve03.jpg" class="img-fluid" />
			</p>
			<br />
			<p style="text-align:center">
				<img alt="" src="/goodwill/steve04.jpg" class="img-fluid" />
			</p>
			<br />
			<p style="text-align:center">
				<img alt="" src="/goodwill/steve05.jpg" class="img-fluid" />
			</p>
			<br />
			<p style="text-align:center">
				<img alt="" src="/goodwill/steve06.jpg" class="img-fluid" />
			</p>
			<br />
			<p style="padding-top: 13pt;padding-left: 5pt;text-indent: 0pt;line-height: 200%;text-align: justify;">
				<span style="color:#000000">
					<span style="font-size:22px">It should be noted that it was a pleasure to be with our other Ambassador of Goodwill Mbeh Derick , his wife Dorothy , TBC Coordinator (Nigeria Mass Adoption Conference) Solo Amahaotu  and the team to participate in feeding many people in poverty in Lagos, Nigeria.  On March 13, 2020, Mbeh, Dorothy, and I left Nigeria to go to their country of Cameroon.  When we arrived at the airport in Cameroon, I was surprised again with the amazing warm welcoming of many TBCians, dancers, cultural music, and a physical sign with my name on the fence, and then an adorable little girl gave me a bouquet of flowers and when she was welcoming me she said: “We welcome you to Cameroon Steven Cuffee, TBC  Ambassador of Goodwill.” During the beginning of the week we drove to the southern part of Cameroon and then traveled by boat down a river to a forest with a village of Pygmies.  They are small people that live in the forest separate from the civilization of the world.  They build their own homes from materials from the forest, they drink water from the river—which is odd to me, hunt animals and harvest vegetables from the forest.  We as a group showing the Goodwill of TBC fed the Pygmies that were there.  A translator for us told us that most of the Pygmies were are out hunting for food at the time we were there.  </span>
				</span>
			</p>
			<br />
			<p style="text-align:center">
				<img alt="" src="/goodwill/steve-07.jpg" class="img-fluid" />
			</p>
			<br />
			<p style="text-align:center">
				<img alt="" src="/goodwill/steve-08.jpg" class="img-fluid" />
			</p>
			<br />
			<p style="text-align:center">
				<img alt="" src="/goodwill/steve-09.jpg" class="img-fluid" />
			</p>
			<br />
			<p style="text-align:center">
				<img alt="" src="/goodwill/steve-10.jpg" class="img-fluid" />
			</p>
			<br />
			<p style="text-align:center">
				<img alt="" src="/goodwill/steve-11.jpg" class="img-fluid" />
			</p>
			<br />
			<p style="text-align:center">
				<img alt="" src="/goodwill/steve-12.jpg" class="img-fluid" />
			</p>
			<br />
			<p style="text-align:center">
				<img alt="" src="/goodwill/steve-13.jpg" class="img-fluid" />
			</p>
			<br />
			<p style="padding-top: 13pt;padding-left: 5pt;text-indent: 0pt;line-height: 200%;text-align: justify;">
				<span style="color:#000000">
					<span style="font-size:22px">It is important that we had to postpone the Goodwill for more people that are in poverty in Cameroon and that of other TBC activities due to the government of Cameroon restrictions due to the Coronavirus that is a worldwide crisis currently.</span>
				</span>
			</p>
			<br />
			<p style="padding-top: 13pt;padding-left: 5pt;text-indent: 0pt;line-height: 200%;text-align: justify;">
				<span style="color:#000000">
					<span style="font-size:22px">I would like to take this time to thank God for TBC Admin to give Goodwill to people in poverty in Nigeria and Cameroon.  Also, thank you so very much TBC Admin for this amazing opportunity to see and be with these people in extreme need for food.  I will never ever forget these awesome experiences. </span>
				</span>
			</p>
			<br />
			<p style="padding-top: 13pt;padding-left: 5pt;text-indent: 0pt;line-height: 200%;text-align: justify;">
				<span style="color:#000000">
					<span style="font-size:22px">With Love and Respect to all of humanity,</span>
				</span>
			</p>
			<br />
			<p style="padding-top: 13pt;padding-left: 5pt;text-indent: 0pt;line-height: 200%;text-align: justify;">
				<span style="color:#000000">
					<span style="font-size:22px">Steven T. Cuffee</span>
				</span>
			</p>
			<br />

			<p style="padding-top: 13pt;padding-left: 5pt;text-indent: 0pt;line-height: 200%;text-align: justify;">
				<span style="color:#000000">
					<span style="font-size:22px">Video of Steve's 1st Event</span>
				</span>
			</p>
			<br />
			<div class='embed-container'>
				<iframe src='https://www.youtube.com/embed/HziNLb5HhO4' frameborder='0' allowfullscreen></iframe>
			</div>
			
			<br />
			<p style="padding-top: 13pt;padding-left: 5pt;text-indent: 0pt;line-height: 200%;text-align: justify;">
				<span style="color:#000000">
					<span style="font-size:22px">1st Video</span>
				</span>
			</p>
			<br />
			<hr />
			<div class='embed-container'>
				<iframe src='https://www.youtube.com/embed/Zk1NaV3KeHI' frameborder='0' allowfullscreen></iframe>
			</div>
			
			<br />
			<p style="padding-top: 13pt;padding-left: 5pt;text-indent: 0pt;line-height: 200%;text-align: justify;">
				<span style="color:#000000">
					<span style="font-size:22px">2nd Video</span>
				</span>
			</p>
			<br />
			<hr />
			<div class='embed-container'>
				<iframe src='https://www.youtube.com/embed/8IXSNUYUukk' frameborder='0' allowfullscreen></iframe>
			</div>
			
			<br />
			<p style="padding-top: 13pt;padding-left: 5pt;text-indent: 0pt;line-height: 200%;text-align: justify;">
				<span style="color:#000000">
					<span style="font-size:22px">3rd Video</span>
				</span>
			</p>
			<br />
			<hr />
			<div class='embed-container'>
				<iframe src='https://www.youtube.com/embed/XCpsdlUuZEE' frameborder='0' allowfullscreen></iframe>
			</div>
			
			<br />
			<p style="padding-top: 13pt;padding-left: 5pt;text-indent: 0pt;line-height: 200%;text-align: justify;">
				<span style="color:#000000">
					<span style="font-size:22px">4th Video</span>
				</span>
			</p>
			<br />
			<hr />
			<div class='embed-container'>
				<iframe src='https://www.youtube.com/embed/0SmZ_nGgGz0' frameborder='0' allowfullscreen></iframe>
			</div>
			
			<p style="padding-top: 13pt;padding-left: 5pt;text-indent: 0pt;line-height: 200%;text-align: justify;">
				<span style="color:#000000">
					<span style="font-size:22px">5th Video</span>
				</span>
			</p>
			<br />
			<hr />
			<div class='embed-container'>
				<iframe src='https://www.youtube.com/embed/ys_kkKfgUxs' frameborder='0' allowfullscreen></iframe>
			</div>
			
			<p style="padding-top: 13pt;padding-left: 5pt;text-indent: 0pt;line-height: 200%;text-align: justify;">
				<span style="color:#000000">
					<span style="font-size:22px">6th Video</span>
				</span>
			</p>
			<br />
			<hr />
			<div class='embed-container'>
				<iframe src='https://www.youtube.com/embed/yjkZodcxxgU' frameborder='0' allowfullscreen></iframe>
			</div>
			
			<p style="padding-top: 13pt;padding-left: 5pt;text-indent: 0pt;line-height: 200%;text-align: justify;">
				<span style="color:#000000">
					<span style="font-size:22px">7th Video</span>
				</span>
			</p>
			<br />
			<hr />
			<div class='embed-container'>
				<iframe src='https://www.youtube.com/embed/dXsXZV4PySU' frameborder='0' allowfullscreen></iframe>
			</div>
			
			<p style="padding-top: 13pt;padding-left: 5pt;text-indent: 0pt;line-height: 200%;text-align: justify;">
				<span style="color:#000000">
					<span style="font-size:22px">8th Video</span>
				</span>
			</p>
			<br />
			<hr />
			</div>
		</div>
			<div class="row">
				<div class="col">
			<!-- TBC Goodwill report for Cameroon  by Mbeh Derick  -->
			<h3>TBC Goodwill report for Cameroon by Mbeh Derick</h3>
			
			<p style="padding-top: 13pt;padding-left: 5pt;text-indent: 0pt;text-align: justify; font-size:22px; color:#000000">
				
			As we all know, TBC Admin cares for humanity and this can be seen from the detailed report below. Our Goodwill program was first scheduled in
			the month of March immediately after we left Nigeria with my other Goodwill Ambassador Steven Cuffee. But because of the planned scamdemic.
			We were deprived of all gathering and my other Ambassador had to return to his Country.
				
			</p>
			
			<p style="padding-top: 13pt;padding-left: 5pt;text-indent: 0pt;text-align: justify; font-size:22px; color:#000000">
			After several months, The government finally approved our distribution of food to the needy. It should be noted that the Admin of TBC sent
			food worth $10,000 to Cameroon to feed the poor and needy.
			</p>
			
			<p style="padding-top: 13pt;padding-left: 5pt;text-indent: 0pt;text-align: justify; font-size:22px; color:#000000">
			Today is the 3rd of October and we are so pleased to share this food. Means of transportation were provided to over 500 persons to the distribution ground.
			The 500 persons included orphans, the blind, the dumb, the handicap, the cripple, the sick, and street children. Each of them went home with at least 5kg
			of rice, Savon/detergent, breakfast beverages, cooking oil, and some spaghetti.
			</p>
			
			<p style="padding-top: 13pt;padding-left: 5pt;text-indent: 0pt;text-align: justify; font-size:22px; color:#000000">
			For the kids going to school, we added school books to each and every one of them as well as napkins for very little once. Below are some of pictures during
			this distribution
			</p>
					<br />
			<p  style="text-align:center"><img class="img-fluid" alt="image" src="/goodwill/Cameroon_Mbeh_Derick/image001.jpg" /></p><br />
			<p  style="text-align:center"><img class="img-fluid" alt="image" src="/goodwill/Cameroon_Mbeh_Derick/image002.jpg" /></p><br />
			<p  style="text-align:center"><img class="img-fluid" alt="image" src="/goodwill/Cameroon_Mbeh_Derick/image003.jpg" /></p><br />
			<p  style="text-align:center"><img class="img-fluid" alt="image" src="/goodwill/Cameroon_Mbeh_Derick/image004.jpg" /></p><br />
			<p  style="text-align:center"><img class="img-fluid" alt="image" src="/goodwill/Cameroon_Mbeh_Derick/image005.jpg" /></p><br />
			<p  style="text-align:center"><img class="img-fluid" alt="image" src="/goodwill/Cameroon_Mbeh_Derick/image006.jpg" /></p><br />
			<p  style="text-align:center"><img class="img-fluid" alt="image" src="/goodwill/Cameroon_Mbeh_Derick/image007.jpg" /></p><br />
			<p  style="text-align:center"><img class="img-fluid" alt="image" src="/goodwill/Cameroon_Mbeh_Derick/image008.jpg" /></p><br />
			<p  style="text-align:center"><img class="img-fluid" alt="image" src="/goodwill/Cameroon_Mbeh_Derick/image009.jpg" /></p><br />
			<p  style="text-align:center"><img class="img-fluid" alt="image" src="/goodwill/Cameroon_Mbeh_Derick/image010.jpg" /></p><br />
			<p  style="text-align:center"><img class="img-fluid" alt="image" src="/goodwill/Cameroon_Mbeh_Derick/image011.jpg" /></p><br />
			<p  style="text-align:center"><img class="img-fluid" alt="image" src="/goodwill/Cameroon_Mbeh_Derick/image012.jpg" /></p><br />
			<p  style="text-align:center"><img class="img-fluid" alt="image" src="/goodwill/Cameroon_Mbeh_Derick/image013.jpg" /></p><br />
			<p  style="text-align:center"><img class="img-fluid" alt="image" src="/goodwill/Cameroon_Mbeh_Derick/image014.jpg" /></p><br />
			<p  style="text-align:center"><img class="img-fluid" alt="image" src="/goodwill/Cameroon_Mbeh_Derick/image015.jpg" /></p><br />
			<p  style="text-align:center"><img class="img-fluid" alt="image" src="/goodwill/Cameroon_Mbeh_Derick/image016.jpg" /></p><br />
			<p  style="text-align:center"><img class="img-fluid" alt="image" src="/goodwill/Cameroon_Mbeh_Derick/image017.jpg" /></p><br />
			<p  style="text-align:center"><img class="img-fluid" alt="image" src="/goodwill/Cameroon_Mbeh_Derick/image018.jpg" /></p><br />
			<p  style="text-align:center"><img class="img-fluid" alt="image" src="/goodwill/Cameroon_Mbeh_Derick/image019.jpg" /></p><br />
			<p  style="text-align:center"><img class="img-fluid" alt="image" src="/goodwill/Cameroon_Mbeh_Derick/image020.jpg" /></p><br />
			<p  style="text-align:center"><img class="img-fluid" alt="image" src="/goodwill/Cameroon_Mbeh_Derick/image021.jpg" /></p><br />
			<p  style="text-align:center"><img class="img-fluid" alt="image" src="/goodwill/Cameroon_Mbeh_Derick/image022.jpg" /></p><br />
			<p  style="text-align:center"><img class="img-fluid" alt="image" src="/goodwill/Cameroon_Mbeh_Derick/image023.jpg" /></p><br />
			<p  style="text-align:center"><img class="img-fluid" alt="image" src="/goodwill/Cameroon_Mbeh_Derick/image024.jpg" /></p><br />
			<p  style="text-align:center"><img class="img-fluid" alt="image" src="/goodwill/Cameroon_Mbeh_Derick/image025.jpg" /></p><br />
			<p  style="text-align:center"><img class="img-fluid" alt="image" src="/goodwill/Cameroon_Mbeh_Derick/image026.jpg" /></p><br />
			<p  style="text-align:center"><img class="img-fluid" alt="image" src="/goodwill/Cameroon_Mbeh_Derick/image027.jpg" /></p><br />
			<p  style="text-align:center"><img class="img-fluid" alt="image" src="/goodwill/Cameroon_Mbeh_Derick/image028.jpg" /></p><br />
			<p  style="text-align:center"><img class="img-fluid" alt="image" src="/goodwill/Cameroon_Mbeh_Derick/image029.jpg" /></p><br />
			<p  style="text-align:center"><img class="img-fluid" alt="image" src="/goodwill/Cameroon_Mbeh_Derick/image030.jpg" /></p><br />
			<p  style="text-align:center"><img class="img-fluid" alt="image" src="/goodwill/Cameroon_Mbeh_Derick/image031.jpg" /></p><br />
			<p  style="text-align:center"><img class="img-fluid" alt="image" src="/goodwill/Cameroon_Mbeh_Derick/image032.jpg" /></p><br />
			<p  style="text-align:center"><img class="img-fluid" alt="image" src="/goodwill/Cameroon_Mbeh_Derick/image033.jpg" /></p><br />
			<p  style="text-align:center"><img class="img-fluid" alt="image" src="/goodwill/Cameroon_Mbeh_Derick/image034.jpg" /></p><br />
			<p  style="text-align:center"><img class="img-fluid" alt="image" src="/goodwill/Cameroon_Mbeh_Derick/image035.jpg" /></p><br />
			<p  style="text-align:center"><img class="img-fluid" alt="image" src="/goodwill/Cameroon_Mbeh_Derick/image036.jpg" /></p><br />

			<br />
			<p style="padding-top: 13pt;padding-left: 5pt;text-indent: 0pt;text-align: justify; font-size:22px; color:#000000">It should be noted that we have more than 200 TBC members who were present just to support the team with the distribution. Also this event took place in the present of the</p>
			<p style="padding-top: 13pt;padding-left: 5pt;text-indent: 0pt;text-align: justify; font-size:22px; color:#000000">divisional delegate for social affairs who was there with her staff to cordinate everything. Here are some of the pictures of TBCians and that of the government delegate and staffs</p>
					<br />
					<p  style="text-align:center"><img class="img-fluid" alt="image" src="/goodwill/Cameroon_Mbeh_Derick/image037.jpg" /></p><br />
			<p  style="text-align:center"><img class="img-fluid" alt="image" src="/goodwill/Cameroon_Mbeh_Derick/image038.jpg" /></p><br />
			<p  style="text-align:center"><img class="img-fluid" alt="image" src="/goodwill/Cameroon_Mbeh_Derick/image039.jpg" /></p><br />
			<p  style="text-align:center"><img class="img-fluid" alt="image" src="/goodwill/Cameroon_Mbeh_Derick/image040.jpg" /></p><br />
			<p  style="text-align:center"><img class="img-fluid" alt="image" src="/goodwill/Cameroon_Mbeh_Derick/image041.jpg" /></p><br />
			<p  style="text-align:center"><img class="img-fluid" alt="image" src="/goodwill/Cameroon_Mbeh_Derick/image042.jpg" /></p><br />
			<p  style="text-align:center"><img class="img-fluid" alt="image" src="/goodwill/Cameroon_Mbeh_Derick/image043.jpg" /></p><br />
			<p  style="text-align:center"><img class="img-fluid" alt="image" src="/goodwill/Cameroon_Mbeh_Derick/image044.jpg" /></p><br />
			<br />
			
			<br />
			<div class='embed-container'>
				<iframe src='https://www.youtube.com/embed/jPobfrtDGtM' frameborder='0' allowfullscreen></iframe>
			</div>
			<br />
			<p style="padding-top: 13pt;padding-left: 5pt;text-indent: 0pt;line-height: 200%;text-align: justify;">
				<span style="color:#000000">
					<span style="font-size:22px">My Goodwill message of hope to the needy in Cameroon.</span>
				</span>
			</p>
			<br />
			<hr />
			<div class='embed-container'>
				<iframe src='https://www.youtube.com/embed/yAJIgY8OQ0M' frameborder='0' allowfullscreen></iframe>
			</div>
			<br />
			<p style="padding-top: 13pt;padding-left: 5pt;text-indent: 0pt;line-height: 200%;text-align: justify;">
				<span style="color:#000000">
					<span style="font-size:22px">A welcome speech was given by Mr Samuel Edindele. The French Weekly Meeting Host</span>
				</span>
			</p>
			<br />
			<hr />


			<div class='embed-container'>
				<iframe src='https://www.youtube.com/embed/S4xlW9EWVWY' frameborder='0' allowfullscreen></iframe>
			</div>
			<br />
			<p style="padding-top: 13pt;padding-left: 5pt;text-indent: 0pt;line-height: 200%;text-align: justify;">
				<span style="color:#000000">
					<span style="font-size:22px">The Delegate for social affairs also encourages us to keep up with the humanitarian activities. This was infront of the press.</span>
				</span>
			</p>
			<br />
			<hr />

			<div class='embed-container'>
				<iframe src='https://www.youtube.com/embed/gLS0dOvZGXE' frameborder='0' allowfullscreen></iframe>
			</div>
			<br />
			<p style="padding-top: 13pt;padding-left: 5pt;text-indent: 0pt;line-height: 200%;text-align: justify;">
				<span style="color:#000000">
					<span style="font-size:22px">In few words , I had to explain our objectives infront of the press.</span>
				</span>
			</p>
			<br />
			<hr />

			<div class='embed-container'>
				<iframe src='https://www.youtube.com/embed/shC_cRBw1zM' frameborder='0' allowfullscreen></iframe>
			</div>
			<br />
			<p style="padding-top: 13pt;padding-left: 5pt;text-indent: 0pt;line-height: 200%;text-align: justify;">
				<span style="color:#000000">
					<span style="font-size:22px">We also had some testimonies coming from the some of the beneficiaries.</span>
				</span>
			</p>
			<br />
			<hr />


			<div class='embed-container'>
				<iframe src='https://www.youtube.com/embed/99aNpFff23k' frameborder='0' allowfullscreen></iframe>
			</div>
			<br />
			<p style="padding-top: 13pt;padding-left: 5pt;text-indent: 0pt;line-height: 200%;text-align: justify;">
				<span style="color:#000000">
					<span style="font-size:22px">This particular person said they have never receive something like what the kringle society just offered them, watch </span>
				</span>
			</p>
			<br />
			<hr />


			<div class='embed-container'>
				<iframe src='https://www.youtube.com/embed/JTP8qaweVcI' frameborder='0' allowfullscreen></iframe>
			</div>
			<br />
			<p style="padding-top: 13pt;padding-left: 5pt;text-indent: 0pt;line-height: 200%;text-align: justify;">
				<span style="color:#000000">
					<span style="font-size:22px">The Goodwill event on TV news</span>
				</span>
			</p>
			<br />
			<hr />
			<br />
			
			<p style="padding-top: 13pt;padding-left: 5pt;text-indent: 0pt;text-align: justify; font-size:22px; color:#000000">I must say here that, it’s a special feeling when you give. I felt different and shared tears of joy when it was time to share to the blind people. They do not see but we could feel the joy in their faces. Wow! What a crazy world. I honestly want to thank the TBC Admin for making us see the world in another way. The TBC Admin has a heart of gold for humanity and lets all join him to accomplish this great mission.</p>
			<p style="padding-top: 13pt;padding-left: 5pt;text-indent: 0pt;text-align: justify; font-size:22px; color:#000000">I also want to thank the Divisional Delegate for social affairs who approved this gathering and carefully coordinate with her team from beginning till the end.</p>
			<p style="padding-top: 13pt;padding-left: 5pt;text-indent: 0pt;text-align: justify; font-size:22px; color:#000000">I will also want to thank my team for helping in the realisation of this distribution.</p>
			<p style="padding-top: 13pt;padding-left: 5pt;text-indent: 0pt;text-align: justify; font-size:22px; color:#000000">Special thanks to all the TBCians present,guidance , and well wishers.</p>
			<p style="padding-top: 13pt;padding-left: 5pt;text-indent: 0pt;text-align: justify; font-size:22px; color:#000000">SEE YOU AT THE TOP. <br />MBEH DERICK
			<br />TBC GOODWILL AMBASSADOR.</p>
					<br /><br /><br />

			<!-- End TBC Goodwill report for Cameroon  by Mbeh Derick  -->

		</div>
	</div>
</div>

</body>
</html>
