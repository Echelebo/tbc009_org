<html>
<title>Kringle.Cash</title>
<head>
    <meta http-equiv="Content-Type" content="application/xhtml+xml; charset=UTF-8" />
    <link rel="shortcut icon" href="favicon.ico" />
    <!-- mobile settings -->
    <meta name="viewport" content="width=device-width, maximum-scale=1, initial-scale=1, user-scalable=0" />	
    <meta property="og:image" content="https://kringle.cash/images/linkimage2c.jpg" />
	<meta property="og:description" content="Become a Millionaire automatically FREE of CHARGE.   This Cash Giveaway expires soon!  Click NOW and collect your GIFT!" />
	<meta property="og:url" content="https://kringle.cash/" />
    <meta property="og:title" content="Kringle.Cash" />
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css"/>
      
      <script type="text/javascript" src="js/jquery.js"></script> 
	  <script type="text/javascript" src="js/bootstrap.js"></script>
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
	<style>

	</style>
    <link href="css/style.css" media="screen" rel="stylesheet" type="text/css">
    <link href="css/ownstyle.css" media="screen" rel="stylesheet" type="text/css">
    <link href="css/mystyle.css" media="screen" rel="stylesheet" type="text/css">
    <link href="css/info1.css" media="screen" rel="stylesheet" type="text/css">
    <script type="text/javascript">
        function googleTranslateElementInit() {
            new google.translate.TranslateElement({pageLanguage: 'en', layout: google.translate.TranslateElement.InlineLayout.SIMPLE}, 'google_translate_element');
        }
    </script>
    <script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
    <!--<div id="google_translate_element"></div>-->
    <style>
        .goog-te-menu-value img {
           display: none;
        }
        .goog-te-gadget-simple img {
        background-image: url('images/KringleCoin.gif')!important;
        }
    </style>
</head>
<body>
<header>
    <div class="header-top" id="menuUser">
        <div class="container">
            <div class="row">
                <div class="col">
                <!--<div class="col-sm-2 col-xs-12" style="width: 13.666667%;    margin-top: -3px;" id="google_translate_element">
                </div>-->
                <div class="float-right" style="display: inline-block;margin-right: 16px;height: 36px;float: right;">
                    <div id="google_translate_element"></div>
                </div>
                    </div>
            </div>
        </div>
    </div>
</header>



<style type="text/css">
    * {
        margin: 0;
        padding: 0;
        text-indent: 0;
    }

    h1 {
        color: #00F;
        font-family: "Monotype Corsiva";
        font-style: italic;
        font-weight: bold;
        text-decoration: none;
        font-size: 26pt;
    }

    h2 {
        color: #F00;
        font-family: "Monotype Corsiva";
        font-style: italic;
        font-weight: bold;
        text-decoration: none;
        font-size: 16pt;
    }

    .s1 {
        color: #000090;
        font-family: "Adobe Caslon Pro Bold", serif;
        font-style: normal;
        font-weight: bold;
        text-decoration: none;
        font-size: 16pt;
    }

    .p, p {
        color: #000090;
        font-family: Cambria, serif;
        font-style: normal;
        font-weight: normal;
        text-decoration: none;
        font-size: 12pt;
        margin: 0pt;
    }

    .s2 {
        color: #000090;
        font-family: Cambria, serif;
        font-style: normal;
        font-weight: normal;
        text-decoration: none;
        font-size: 12pt;
    }

    .s3 {
        color: #000090;
        font-family: Cambria, serif;
        font-style: normal;
        font-weight: normal;
        text-decoration: none;
        font-size: 8pt;
        vertical-align: 3pt;
    }

    .s4 {
        color: #000090;
        font-family: Cambria, serif;
        font-style: normal;
        font-weight: normal;
        text-decoration: none;
        font-size: 8pt;
    }

    a {
        color: #00F;
        font-family: Calibri, sans-serif;
        font-style: normal;
        font-weight: normal;
        text-decoration: underline;
        font-size: 10pt;
    }

    .s6 {
        color: #00F;
        font-family: Cambria, serif;
        font-style: normal;
        font-weight: normal;
        text-decoration: underline;
        font-size: 12pt;
    }

    li {
        display: block;
    }

    #l1 {
        padding-left: 0pt;
    }

        #l1 > li:before {
            content: " ";
            color: #000090;
            font-family: Wingdings;
            font-style: normal;
            font-weight: normal;
            text-decoration: none;
            font-size: 12pt;
        }
</style>

<body style="background-image: url(images/notice_back.jpg); background-repeat:repeat">
    <div class="click-b myinfo3mobi" style="width:100%; text-align: center;">
        <div id="theDiv"></div>
        <div class="container text-center">
            
            <div class="row">
                <div class="col-sm-6 text-left" style="color:#000;">
                    <br />
                    <h3>Public Notice</h3>
                    <a href="#textversion" style="font-size:14px;">Click Here</a> For Public Notice Translatable Version
                    <br />
                    <a href="PublicNotice.pdf" style="font-size:14px;" target="_blank">Click Here</a> To Access Public Notice PDF Version
                </div>

                <div class="col-sm-6  text-left" style="color:#000;">
                    <br />
                    <h3>Mission Statement</h3>
                    <a href="#ksms" style="font-size:14px;">Click Here</a> For Kringle Society Mission Statement
                    <br />
                    <a href="#ksmstextversion" style="font-size:14px;">Click Here</a> For Kringle Society Mission Statement Translatable Version
                    <br />
                    <a href="KringleSocietyMissionStatement.pdf" style="font-size:14px;" target="_blank">Click Here</a> To Access Kringle Society Mission Statement PDF Version
                </div>
            </div>
            <div class="row">
            <div class="col-sm-6 text-left">
                <br />
                <h3>Articles of Association</h3>
                <a href="#aaa" style="font-size:14px;">Click Here</a> For Articles of Association
                <br />
                <a href="#aaatextversion" style="font-size:14px;">Click Here</a> To Access Articles of Association Translatable Version
                <br />
                <a href="ArticlesofAssociation.pdf" style="font-size:14px;" target="_blank">Click Here</a> To Access Articles of Association PDF Version
                <br />
                <br />
                <br />
            </div>
        </div>
        <div class="row">

            <div class="col-sm-6 text-left">
                <br />
                <h3>SEC Writs</h3>
                <a href="SEC-WritofExecutionandRecord1.14.2019-final.pdf" style="font-size:14px;" target="_blank">Click Here</a> To Access SEC - Writ of Execution and Record 1.14.2019 PDF Version
                <a href="SEC-WritofResolution1.14.2019-final.pdf" style="font-size:14px;" target="_blank">Click Here</a> To Access SEC - Writ of Resolution 1.14.2019 PDF Version
            </div>

            <div class="col-sm-6 text-left">
                <br />
                <h3>Other</h3>
                <a href="terms_of_use.php" style="font-size:14px;" target="_blank">Click Here</a> To Access Terms Of Use
                <br />
                <a href="privacy_policy.php" style="font-size:14px;" target="_blank">Click Here</a> To Privacy Policy
            </div>

        </div>
            <div class="row">
                <div class="col">
                    <br /><br /><br />
                </div>
            </div>
        <div class="row">
            <div class="col-sm-12 text-center">
                <img src="images/PublicNotice.png" style="border:double 5px black;" />
                <br />
                <br />
            </div>
        </div>
        <a name="textversion"></a>
        <div class="row">
            <div class="col-sm-12 text-center" style="background-color:#fff;border:double 5px black;margin-bottom: 50px;">

                <h1 style="text-align: center;">
                    Kringle Private Society
                    <br />“The Billion Coin”
                </h1>
                <h2 style="text-align: center;">A Global Sharing &amp; Eleemosynary Society</h2>
                <br />
                <p class="s1" style="text-align: center;">
                    PUBLIC ANNOUNCEMENT
                    <br />
                    <br />OCTOBER 1, 2018
                </p>
                <p style="text-indent: 0pt; text-align: left;">
                    <br />
                </p>
                <p style="padding-left: 5pt; text-indent: 0pt; line-height: 114%; text-align: justify;">This Public Announcement is directed to the current members of the worldwide private society that has been known since March 2016 as The Billion Coin or TBC, as well as to All Parties, both Public and Private, who may have an interest in this information. The intent of this announcement is to inform our members of important changes and refinements to our structure that are being implemented at this time to better serve our members and more accurately portray the nature and character of our society, our private membership association and our global mission. This is being undertaken to better define exactly what our society and membership community is and has always been since our inception. These changes and refinements are a result of further research and investigation into the necessary compliance requirements of the global system. This relates to laws pertaining to monetary systems, public versus private currencies, and other matters.</p>
                <p style="padding-top: 12pt; padding-left: 5pt; text-indent: 0pt; line-height: 114%; text-align: justify;">We have always, since the beginning, directed our efforts in creating The Billion Coin to be in full compliance with all laws and jurisdictions while at the same time providing the solutions we have developed to relieve global poverty for all people in this world. With our new research and investigation we have determined that certain use of language was misleading or potentially able to be misconstrued, therefore the time for clarity and precision is now upon us as a community. Certain foundational components of our Private Society and Membership Association were inferred but not necessarily precisely conveyed with our choice of language and presentations. Thus, we now see that we must correct previous errors and mistakes, whether done by commission or omission, and more properly present to our membership and the world at large what exactly we are and what we are not.</p>
                <p style="padding-top: 12pt; padding-left: 6pt; text-indent: 0pt; line-height: 114%; text-align: justify;">In this regard, pursuant to this announcement, we wish to define these fundamental points and principles to achieve clarity for all concerned. These points are as follows:</p>
                <p style="text-indent: 0pt; text-align: left;"></p>
                <p style="text-indent: 0pt; text-align: left;">
                    <br />
                </p>
                <ul id="l1">
                    <li style="padding-top: 5pt; padding-left: 42pt; text-indent: -18pt; line-height: 114%; text-align: justify; padding-bottom: 8px;">
                        <p style="display: inline;">The TBC community was founded as a Private Society and a Private Contract Association and continues as such to this day. It will always be defined exactly by these two phrases.</p>
                    </li>
                    <li style="padding-left: 42pt; text-indent: -18pt; line-height: 114%; text-align: justify; padding-bottom: 8px;">
                        <p style="display: inline;">A Private Society is not incorporated in any jurisdiction and is established upon the right of all people to have and express the paramount right of Self-Determination and Private Association. As an unincorporated Body Politic we do not derive our existence from any external authorization, but by the Will and Intent of the members of the Society.</p>
                    </li>
                    <li style="padding-left: 42pt; text-indent: -18pt; line-height: 114%; text-align: justify; padding-bottom: 8px;">
                        <p style="display: inline;">At the same time, we honor and respect the laws of all nations and do not encourage any member to do otherwise. It is of the highest importance in our Principles of Association that we remain in honor and peace with all people and all nations.</p>
                    </li>
                    <li style="padding-left: 42pt; text-indent: -18pt; line-height: 114%; text-align: justify; padding-bottom: 8px;">
                        <p style="display: inline;">Our Society is founded upon a Mission Purpose with stated Principles. This Mission Purpose will soon be formally defined in a published Mission Statement, while at the same time, since our inception, we have put forward the Principles that in fact define our Mission and Purpose in various written presentations both public and private.</p>
                    </li>
                    <li style="padding-left: 42pt; text-indent: -18pt; line-height: 114%; text-align: justify; padding-bottom: 8px;">
                        <p style="display: inline;">The Mission and Principles are simple and pure. We are here to provide the people of the world a tool to alleviate all poverty and suffering for all people. This tool puts into the hands of the people the Right of Self-Empowerment.</p>
                    </li>
                    <li style="padding-left: 42pt; text-indent: -18pt; line-height: 114%; text-align: justify; padding-bottom: 8px;">
                        <p style="display: inline;">A Private Contract Association is a group of people who come together to form a mutual basis of association, a Mutual Benefit Society, in which all benefit from the structure, tools and principles of the Society accrue to and are shared by all the members. A Private Society and Private Contract Association, styled as a Mutual Benefit Society, is not owned by any individual. They exist by the Will of the Members and are established on the basis of privately contracting to an agreed upon set of rules and activities. These rules have already been made clear since our beginning as to what is required to be a member of our society and association in good standing.</p>
                    </li>
                    <li style="padding-left: 42pt; text-indent: -18pt; line-height: 114%; text-align: justify; padding-bottom: 8px;">
                        <p style="display: inline;">As a member in good standing one has the benefit of using The Billion Coin and the Kringle currency as a private medium of exchange. One of our mistakes was naming this currency as a form of “money”, which we now realize is not accurate, and this will soon be corrected. The term “money” carries certain legal definitions and implications. Thus, by this Announcement, we are making it clear that any and all use of terms such as money, dollar, euro, or other similar words and references, was done in error and mistake. We therefore hereby issue our formal apology and declaration of intent to correct such mistakes forthwith and with the utmost expediency possible.</p>
                    </li>
                    <li style="padding-left: 42pt; text-indent: -18pt; line-height: 114%; text-align: justify; padding-bottom: 8px;">
                        <p style="display: inline;">TBC and Kringle are not commercial instruments or negotiable paper as those terms are defined in domestic and international legal systems. Any implications, inference or aspersions to the contrary were done in error and, again, we apologize for any misunderstanding or confusion caused by our inaccurate use of language, all of which will soon be corrected on our web sites and any other materials available either public or private.</p>
                    </li>
                    <li style="padding-left: 42pt; text-indent: -18pt; line-height: 114%; text-align: justify; padding-bottom: 8px;">
                        <p style="display: inline;">TBC and Kringle are not in any way a security instrument. They do not secure any interest in any intrinsic value, commodity, asset or account. They are a privately issued medium of exchange available only to members of a private Mission Society and Private Contract Association, pursuant to and according to its private rules of membership and participation. The inherent value that they represent is only the Life Force and Spiritual Value of our private society members.</p>
                    </li>
                    <li style="padding-left: 42pt; text-indent: -18pt; line-height: 114%; text-align: justify; padding-bottom: 8px;">
                        <p style="display: inline;">We are a Global Sharing and Eleemosynary Society. The “Sharing” is derived by the private contract agreement to share our value and life force with each other, for mutual support and benefit. TBC and Kringle are a private currency, which means it is designed to flow through a channel much like as river has a current and flows through its course, or electricity has a current that flows through wires that provide the value of kinetic work to light our homes and run our factories. We share the common purpose and value of using our life force as a current that flows through the course of our system, which is made up of living men, women and children. Eleemosynary means charitable and we define our society as such because we believe in the true charity of kindness, giving, sharing and supporting lives of integrity and respect. As we all work together to build this global community, we are providing true giving and sharing for all who participate.</p>
                    </li>
                    <li style="padding-left: 42pt; text-indent: -18pt; line-height: 114%; text-align: justify; padding-bottom: 8px;">
                        <p style="display: inline;">Any use or reference to commercial terms or comparative value ratios against national currencies or precious metals is only for comparative purposes, and does not impute any direct or secured relationship to such instruments or assets. Any misconstruction of this in the past was done by mistake and error for which we apologize and shall rapidly correct as stated herein.</p>
                    </li>
                    <li style="padding-left: 42pt; text-indent: -18pt; line-height: 114%; text-align: justify; padding-bottom: 8px;">
                        <p style="display: inline;">Any inference that TBC or Kringle is a medium of investment is entirely inaccurate, and once again, any language in previous materials, websites or presentations that may have engendered such mistaken inferences shall be corrected. Any statements that our private medium of exchange carried fungible potential with public currencies was never inferred or intended.</p>
                    </li>
                    <li style="padding-left: 42pt; text-indent: -18pt; line-height: 114%; text-align: justify; padding-bottom: 8px;">
                        <p style="display: inline;">Henceforth we shall use the formal names of our organization as the Kringle Private Society and the TBC Private Contract Association. Our Mission Statement and related materials to this effect will be forthcoming and made available to the public via our two official websites. We do not accept any misconstruction of our Society, Purpose, Principles or Association that might be found on any other public medium, i.e., YouTube, Social Media platforms, individual websites. Only formally authorized materials shall henceforth be considered acceptable to represent these entities, and such materials will always be issued under the formal Seal of the Society, which is currently being developed and will soon be announced on our websites. Upon such announcement, all materials, brochures, publicly accessible web pages and any other medium of communication will display the Seal and only the TBC Administrative Team shall be authorized to use said Seal.</p>
                    </li>
                    <li style="padding-left: 42pt; text-indent: -18pt; line-height: 114%; text-align: justify; padding-bottom: 8px;">
                        <p style="display: inline;">In the near future, Articles of Association will be published for the Private Contract Association. All current and future members will be required to electronically sign and accept the articles in order to continue with their membership. These Articles will comprise the contractual basis of our Association, thus fulfilling the requirements of a Private Contract Association (henceforth also referred to as “PCA”). These articles will contain already existing rules of membership, with the addition of a few required stipulations to properly reflect the information presented in this Announcement.</p>
                    </li>
                    <li style="padding-left: 42pt; text-indent: -18pt; line-height: 114%; text-align: justify; padding-bottom: 8px;">
                        <p style="display: inline;">As a Private Society, the Kringle Private Society has full authority to create its own form of governance, law form, court and private treasury. These will be established to better serve and protect the interests of our members, and will be available to every member for the settlement of disputes and other such basic principles of a balanced society of men, women and children. It will take time to properly fulfill these requirements and all members will be kept informed as to the progress thereof. We request the understanding and patience of our members in this process.</p>
                    </li>
                    <li style="padding-left: 42pt; text-indent: -18pt; line-height: 114%; text-align: justify; padding-bottom: 8px;">
                        <p style="display: inline;">Our purpose and mission includes the education of our members so that they grow into properly informed and intelligent members of the private society and the larger world society of our respective countries and the world as a whole. In months to come, we shall be implementing tools for such education so that our members can be successful with TBC and Kringle and understand how to use it for their benefit and the mutual benefit of all of our members. Within such education, some of the terms and points contained in this Announcement (and in future materials) will be clarified so that we proceed forward together as a well-educated body politic of competent and educated people that are here in association to benefit ourselves, the communities and nations in which we live and work, and the world as a whole.</p>
                    </li>
                    <li style="padding-left: 42pt; text-indent: -18pt; line-height: 114%; text-align: justify; padding-bottom: 8px;">
                        <p style="display: inline;">The only value that TBC and Kringle carry is that of the mutual benefit confidence of our private members. We hold the value of every human being on this planet to be of the highest order pursuant to our privately held beliefs and conscience. All of our members comprise the collective value of our Society, as an Ekklesia (defined as the body of the congregation) that is the living body of our congregation together.</p>
                    </li>
                    <li style="padding-left: 42pt; text-indent: -18pt; line-height: 114%; text-align: justify; padding-bottom: 8px;">
                        <p style="display: inline;">We are a non-denominational and non-hierarchical body of living beings. This is the definition of a Body Politic, thus we consider our Society to be an Ecclesiastical Body Politic immune from the public, commercial and corporate jurisdictional authorities of constituted National Bodies Politic. We do not ascribe to any given religion, path, or other denomination of belief or creed, while at the same time, we support all of our members in the pursuit of their own Right of Self-Determination to uphold individual beliefs and modes of living through private and personal conscience. The only exclusion to this principle is against those who would use our society to promote violence or harm to others. This includes an absolute forbiddance of any illicit use of our private medium of exchange in any manner to take advantage of another or to transgress the domestic laws of the nations in which one lives. We are here to promote peace and prosperity for all human beings and all living things in this world.</p>
                    </li>
                    <li style="padding-left: 42pt; text-indent: -18pt; line-height: 114%; text-align: justify; padding-bottom: 8px;">
                        <p class="s4" style="display: inline;">
                            <a href="#bookmark0" class="s2">The Kringle Society has been established in conformity and in alignment with the PanTerra D’Oro Private Society</a>
                            <span style="color: #000090; font-family: Cambria, serif; font-style: normal; font-weight: normal; text-decoration: none; font-size: 8pt; vertical-align: 3pt;">1</span>
                            <a href="#bookmark0" class="s2">. All records of the Kringle Private Society are secured and held in the priv</a>
                            <a href="#bookmark1" class="s2">ate permanent archival system of records of the PanTerra D’Oro Society Court of the Ekklesia. We are in full alignment with the globally published Declaration of Intention</a>
                            <span style="color: #000090; font-family: Cambria, serif; font-style: normal; font-weight: normal; text-decoration: none; font-size: 8pt; vertical-align: 3pt;">2</span>
                            <a href="#bookmark2" class="s2">of the PanTerra D’Oro Private Society and formally adopt the principles contained therein. As a member of the PanTerra D’Oro Private Society we are aligned with and included therein to the formal announcement to all World Administrative Bodies</a>
                            <a href="#bookmark3" class="s3">3 </a>
                            <a href="#bookmark3" class="s2">and the Offer of Treaty of Peace and Cessation of Hostilities presented to the Holy See</a>
                            <span style="color: #000090; font-family: Cambria, serif; font-style: normal; font-weight: normal; text-decoration: none; font-size: 8pt; vertical-align: 3pt;">4 </span>
                            <span class="p">via the Nuncio of Washington District of Colombia.</span>
                        </p>
                    </li>
                    <li style="padding-left: 42pt; text-indent: -18pt; line-height: 114%; text-align: justify; padding-bottom: 8px;">
                        <p style="display: inline;">We are at peace with all public entities and institutions worldwide, neutral in the public and proceeding in peaceful harmony and comity with all agencies, departments and authorities of any and all public entities of national character. Henceforth all public communications shall be under the Seal of the Kringle Private Society and the International Flag of Peace.</p>
                    </li>
                    <li style="padding-left: 42pt; text-indent: -18pt; line-height: 114%; text-align: justify; padding-bottom: 8px;">
                        <p style="display: inline;">To all of our current members, please be patient as we undertake the necessary changes as described in this Announcement. We will have abundant details ready to provide within our private member enclosures in weeks and months to come. The changes being undertaken will assure a stronger and more resilient membership for all of us for the fulfillment of our mission and the prosperity of all. Thank you for your patience and consideration and continuing support.</p>
                    </li>
                </ul>
                <p style="padding-top: 11pt; padding-left: 6pt; text-indent: 0pt; line-height: 114%; text-align: justify; padding-bottom: 8px;">Finally, we wish to address something that is currently in progress with respect to an inquiry being conducted by the Securities Exchange Commission (“SEC”) of the United States. Some of our members are aware of this but most are not. Thus, we want to be clear and above board on this point so that all are aware of the situation and understand it properly. This inquiry is a legal process by an authorized government agency. We understand that this is being done with most or all crypto and digital currencies to determine if any given currency is in fact structured or promoted as a security as such</p>
                <p style="text-indent: 0pt; text-align: left;">
                    <br />
                </p>
                <p style="padding-top: 3pt; padding-left: 6pt; text-indent: 0pt; line-height: 12pt; text-align: left;">
                    <a href="https://www.panterrapca.org/" style="color: black; font-family: Calibri, sans-serif; font-style: normal; font-weight: normal; text-decoration: none; font-size: 6.5pt; vertical-align: 3pt;" target="_blank" name="bookmark0">1 </a>
                    <a href="https://www.panterrapca.org/" target="_blank">https://www.panterrapca.org/</a>
                </p>
                <p style="padding-left: 6pt; text-indent: 0pt; line-height: 12pt; text-align: left;">
                    <a href="https://www.panterrapca.org/foundational-documents/declaration-of-intention" style="color: black; font-family: Calibri, sans-serif; font-style: normal; font-weight: normal; text-decoration: none; font-size: 6.5pt; vertical-align: 3pt;" target="_blank" name="bookmark1">2 </a>
                    <a href="https://www.panterrapca.org/foundational-documents/declaration-of-intention" target="_blank">https://www.panterrapca.org/foundational-documents/declaration-of-intention</a>
                </p>
                <p style="padding-left: 6pt; text-indent: 0pt; line-height: 12pt; text-align: left;">
                    <a href="https://www.panterrapca.org/public-notices/world-administrative-bodies" style="color: black; font-family: Calibri, sans-serif; font-style: normal; font-weight: normal; text-decoration: none; font-size: 6.5pt; vertical-align: 3pt;" target="_blank" name="bookmark2">3 </a>
                    <a href="https://www.panterrapca.org/public-notices/world-administrative-bodies" target="_blank">https://www.panterrapca.org/public-notices/world-administrative-bodies</a>
                </p>
                <p style="padding-left: 6pt; text-indent: 0pt; line-height: 12pt; text-align: left;">
                    <a href="https://www.panterrapca.org/public-notices/world-administrative-bodies/notice-to-the-holy-see" style="color: black; font-family: Calibri, sans-serif; font-style: normal; font-weight: normal; text-decoration: none; font-size: 6.5pt; vertical-align: 3pt;" target="_blank" name="bookmark3">4 </a>
                    <a href="https://www.panterrapca.org/public-notices/world-administrative-bodies/notice-to-the-holy-see" target="_blank">https://www.panterrapca.org/public-notices/world-administrative-bodies/notice-to-the-holy-see</a>
                </p>
                <p style="text-indent: 0pt; text-align: left;">
                    <br />
                </p>
                <p style="padding-top: 5pt; padding-left: 6pt; text-indent: 0pt; line-height: 114%; text-align: justify;">would be defined by United States laws. As we all know, many new currencies, coins and tokens are being created now and have been for several years through a type of offering known as an Initial Coin Offering (“ICO”). This is, of course, similar to what occurs when a private company decides to take a corporation public by contracting with a market maker to underwrite an Initial Public Offering (“IPO”). So, obviously, there are similarities in language and function.</p>
                <p style="padding-top: 12pt; padding-left: 5pt; text-indent: 0pt; line-height: 114%; text-align: justify;">An IPO sells stock in a company that is backed by the assets of the corporation and is promoted on the basis of future earnings. This secures the shares of stock by the assets and thus is a security within the scope of U.S. law and the SEC has jurisdiction over such securities to regulate and control them within the public markets. That agency is called the Securities Exchange Commission because it regulates and oversees the ongoing “exchange” of securities through normal market functions. When ICOs first came out, they offered “coin” or “tokens” for cash, usually denominated in United States Dollars, over which the United States and its agencies have jurisdiction. The coins issued were secured against the cash raised by the offering or oftentimes by an asset base such as real estate that were explicitly stated to back the coin. This then became a form of security and thus the SEC has been investigating many of these coins to determine whether they are a security or not, and if so, to bring them into the regulatory environment of their jurisdiction.</p>
                <p style="padding-top: 12pt; padding-left: 5pt; text-indent: 0pt; line-height: 114%; text-align: justify;">In the case of TBC and Kringle, we do not fall into this category. We have never made any claim that TBC and Kringle are a form of secured interest in assets or public funds. We are not in the jurisdiction of the United States because we are not a corporate entity in that jurisdiction and do not derive our authority to exist or operate from said jurisdiction. We have always been clear that we are a private society and private member organization. We now realize that we made a mistake in referencing the value of TBC and Kringle in “dollar terms” and this was corrected earlier this year. We now make reference to grains of gold but to be absolutely clear, we have never declared either publicly or privately that the currency of TBC and Kringle are secured or backed by gold, only using a grain of gold as a reference point. The value of TBC is simply and solely the value of the living beings who participate in our private society by and through our private contract association. When any member joins the TBC Community they contract to abide by the rules that we publish. We will soon be expanding the details of our structure with written and educational materials to reflect this, but since inception, we have only been a private member organization and the value of our currency is nothing more than the value of our membership.</p>
                <p style="padding-top: 12pt; padding-left: 6pt; text-indent: 0pt; line-height: 114%; text-align: justify;">So, for any members who are currently under a subpoena by the SEC to provide data and information, we encourage you to be fully cooperative with their inquiry and at all times tell the truth as best as you know and understand it. We have nothing to hide or avoid, so the truth is always the best policy. We firmly believe that in the end this inquiry will prove the statements we have made here and the SEC will determine that we are not offering securities, have never made any sort of Initial Coin or Public Offering and do not promote any secured interests. TBC and Kringle are private mediums of exchange, to be used to promote equitable exchange between private parties for goods and services. If some members have exchanged TBC for domestic currencies of any country, then they should consult professionals as to any legal requirements that may entail as far as taxation, reporting or other considerations with respect to their home country of residence or domicile. This also includes if the exchange of a private medium of exchange for goods and services in your domestic jurisdiction might carry any tax implications. We will always encourage our members to recognize the truth in the statement that all PERSONS liable to report and pay income taxes must do so in conformity with local law. In the near future we will be formally structuring our Society, PCA and Community with more precise detail as to what is acceptable and proper with respect to exchange and use of the private medium of exchange known as TBC and Kringle.</p>
                <p style="padding-top: 12pt; padding-left: 6pt; text-indent: 0pt; line-height: 114%; text-align: justify;">
                    This concludes our Public Announcement at this time and date. All inquiries pursuant hereto can be sent to
                    <a href="/cdn-cgi/l/email-protection#b5d4d1d8dcdbf5dec7dcdbd2d9d0c5c7dcc3d4c1d0c6dad6dcd0c1cc9bdac7d2" class="s6"><span class="__cf_email__" data-cfemail="046560696d6a446f766d6a63686174766d72657061776b676d61707d2a6b7663">[email&#160;protected]</span></a>.
                </p>

                <p style="text-indent: 0pt; text-align: left;">
                    <br />
                </p>
                <p style="padding-top: 5pt; padding-left: 6pt; text-indent: 0pt; text-align: left;">Sincerely, TBC Admin</p>
                <br />
                <br />
                <br />
                <br />
                <br />
            </div>
        </div>
        <a name="ksms"></a>
        <div class="row">
            <div class="col-sm-12 text-center">
                <img src="images/KringleSocietyMissionStatement.png" style="border:double 5px black;" />
                <br />
                <br />
            </div>
        </div>
        <a name="ksmstextversion"></a>
        <div class="row">
            <div class="col-sm-12 text-center" style="background-color:#fff;border:double 5px black;margin-bottom: 50px;">

                <h1 style="text-align: center;">Kringle Private Society “The  Billion Coin”</h1>
                <h2 style="text-align: center;">A Global Sharing &amp; Eleemosynary Society</h2>
                <p class="s1" style="text-align: center;">Kringle Society Mission Statement</p>
                <p style="padding-top: 13pt;padding-left: 5pt;text-indent: 0pt;line-height: 114%;text-align: justify;">The Kringle Society is a global initiative as a Sharing and Eleemosynary Society founded upon the principle that humanity is capable of lifting itself out of the morass of poverty, disease, lack, limitation, suffering and ignorance into a new dawn of abundance and prosperity for all. We are here to empower each of our members with the means to spread abundance, in all its forms, to the entire community of humanity with a clear plan to eliminate poverty worldwide and to assist each and every being that we touch to find their unique purpose that their Creator intended for them. The Kringle Sharing and Eleemosynary Society is here to support all of its members, and all of humanity, by providing the means and methods to have the support and practical tools so that every member of our society and every human being shall have what they need to make manifest their essential needs to create lives of abundance and integrity.</p>
                <p style="padding-top: 10pt;padding-left: 5pt;text-indent: 0pt;line-height: 114%;text-align: justify;">Kringle is a Sharing Society that has established and will continue to build a Private Contract Association in which men, women and children, of their own free will and volitional act, choose to enter into a private contract relationship with our free association membership. This association is based on the principle of mutual benefit and the interactive sharing of knowledge, ideas and creativity through the use of a private medium of exchange known as The Billion Coin (henceforth “TBC”) and its smaller increment coin known as Kringle. Ongoing support through education and the creation of a private social media platform will support this system.</p>
                <p style="padding-top: 9pt;padding-left: 5pt;text-indent: 0pt;line-height: 114%;text-align: justify;">Our mission is to serve one another with love and respect and to use TBC and Kringle to lift humanity out of hunger, poverty, and misery. It is our intention that the veils of ignorance fall from each that we touch. We intend that all of our members will embrace and have a life full of abundance and prosperity as they accept our offer of membership within the Kringle Society and Private Contract Association.</p>
                <p style="padding-top: 4pt;padding-left: 5pt;text-indent: 0pt;line-height: 114%;text-align: justify;">Within the private environs of our Society, our members can enjoy all the benefits of using a completely private medium of exchange that respects the  privacy  of  all  who  use  it.   It  is  within  our  power  to  bring  in  purveyors  of goods and services of all kinds, from every location of the Earth, that accept TBC and  Kringle  for  equal  value  exchange  for  their  goods  and  services.   We  intend that TBC and Kringle shall one day reach their full potential when our community grows  to  One  Billion  Verified  Members.    When  this  occurs  it  will  unlock  the Ultimate Value of TBC.   This Ultimate Value will reflect the value of One Billion Members of our Private Contract Association and in so doing we shall realize our vision  and  goal  that  the  measure  of  real  value  in  this  world  shall  be  the  true worth  of  every  living  being  -­‐  men,  women  and  children  -­‐  who  are  the  true creative potential of humanity in individual embodiments.  We hold this as a true mandate and a self-­‐evident truth.  It is an Endowment from our Creator however any  individual  chooses  to  define  or  describe  such  a  creative  Source.     That endowed  mandate  is  that  we  shall  all  live  freely  in  creative  collaboration  with each other and with this beautiful planet we dwell upon.   This shall also include living  in  harmony  with  the  larger  Universal  community  of  Life  throughout  the Cosmos.</p>
                <p style="padding-top: 10pt;padding-left: 5pt;text-indent: 0pt;line-height: 114%;text-align: justify;">Our Mission is Good! Our Mission is Great! It is up to each and every one of us to fulfill it with the realization of this Gift of Life. The Kringle Society has brought forward a unique contribution as a Gift to Humanity in the fulfillment and realization of that vision. Our Vision sees a world free of limitation and our Mission is to be part of the solution that makes it so. This shall be a world in which every child grows up in a community of support, love, respect and integrity, and has the opportunity that every child in this world should have, which is to have all the tools and resources needed to realize their fullest capacities and build a life that each of us would desire for ourselves and our own children.</p>
                <p style="padding-top: 10pt;padding-left: 5pt;text-indent: 0pt;line-height: 114%;text-align: justify;">As a Sharing Society, Kringle is established as a community intended to share the wealth of our lives with each other. This means the personal human value of a Living Being, not the monetized debt enslavement metric that we have been programmed to believe is real wealth. That is an illusion. It is a trap. The Kringle Society has been established with a Vision, Mission and Purpose to break through that illusion and show the world and humanity how we can free ourselves from the trap. Thus, we have created a currency to flow like the free waters of a mighty river, a river of power and force, a river of Living Beings that come together to see poverty, disease and deprivation forever washed away by such waters and carried to the sea of forgiveness and dissolution so that all men, women and children in this world shall have lives of value, lives of purpose and lives of meaning. We will share with each other the wealth of our life force, the value of our unique capacities to create and build and purify, and we will do it by valuing our currency with the metric of the only real value there is in this world, which is Life.  Life means Living In Full Expression by supporting each member of our private society and contract association to achieve their dreams and aspirations. It is our Mission to take the realization of this intention into the greater world society and show others the way of freedom and prosperity without debt, bondage, lack or limitation.</p>
                <p style="padding-top: 10pt;padding-left: 5pt;text-indent: 0pt;line-height: 114%;text-align: justify;">As  an  Eleemosynary  Society  we  see  our  Mission  as  one  that  brings  charitable support  to  those  who  need  a  helping  hand  in  building  lives  of  integrity  and respect.   This means co-­‐creative sharing and support, not charity that degrades the  individual  and  diminishes  self-­‐worth.     This  is  our  Mission  and  this  is  the Ideal  that  we  shall  strive  for  until  it  is  fulfilled.     We  envision  a  world  free  of constraints  where  the  very  stars  are  our  partners  and  represent  unlimited capacities   as   to   what   we   can   accomplish   in   this   lifetime,   and   for   many generations and lifetimes to come.   We are a multi-­‐generational legacy trust the true beneficiaries of which are the children of the future, those that are just now coming into life and those yet to be born.   Eleemosynary is a word defined by its roots as “Alms Giving”, which in the past meant to give a few coins to the poor and destitute.  But we see that “Alm” is the root of Alma, which is Latin for Soul or Spirit, so our charitable giving is of the Soul and Spirit of this Mission Society and its true purpose, which is to bequeath the spirit of unlimited possibilities to the future generations that shall inherit this Spirit and become the Soul this World. We invite all who share this vision to join us in building the true value basis of The Billion Coin (TBC), to add your Life Force to the valuation of one billion coins supported by one billion living souls as a Gift for Humanity, to break free from the chains of debt enslavement and the illusions of lack and limitation, to make TBC what it truly is meant to be, The Brilliant Community of the Kringle Society and  of  Planet  Earth,  to  enliven  the  brilliance  of  One  Billion  Stars  and  forever banish the darkness from our world.</p>
                <br />
                <br />
                <br />
            </div>
        </div>
        <a name="aaa"></a>
        <div class="row">
            <div class="col-sm-12 text-center">
                <img src="images/ArticlesofAssociation1.png" style="border:double 5px black;" />
                <br />
                <br />
            </div>
        </div>
        <a name="aaatextversion"></a>
        <div class="row">
            <div class="col-sm-12 text-center" style="background-color:#fff;border:double 5px black;margin-bottom: 50px;">
                <h1 style="padding-top: 4pt;line-height: 114%;text-align: center;">
                    Kringle Private Society
                    <br /> “The  Billion Coin”
                </h1>
                <h2 style="text-align: center;">A  Global Sharing &amp;  Eleemosynary Society</h2>
                <p class="s1" style="padding-top: 12pt;line-height: 119%;text-align: center;">
                    Kringle Society
                    <br /> Private Contract Association
                    <br />Articles of Association
                </p>
                <p class="s1" style="padding-left: 5pt;text-indent: 0pt;text-align: left;">General Overview</p>
                <p style="padding-top: 4pt;padding-left: 5pt;text-indent: 0pt;line-height: 114%;text-align: justify;">The Kringle Society (henceforth “Society”) has been founded upon a Mission to become a force for change and transformation in our world. This Mission will be fulfilled when all human beings in this world have the means to have lives of stability, integrity and respect. In the fulfillment of this mission, the Society has established a Private Contract Association (henceforth “PCA”) that any man, woman or child can join by the simple act of accepting the Articles of Association (henceforth “Articles”) of the PCA as herein set forth. These Articles are put forward into the world community as an offer of private contract.</p>
                <p style="padding-top: 9pt;padding-left: 5pt;text-indent: 0pt;line-height: 114%;text-align: justify;">The  PCA  and  these  Articles  are  established  on  the  universal  principles  of  the Right of Self-­‐Determination, Private Contract and Free Association.  We accept all who wish to join us in our sacred endeavor to fulfill our mission and to co-­‐create together by their acceptance of these Articles and Contract.</p>
                <p class="s1" style="padding-top: 10pt;padding-left: 5pt;text-indent: 0pt;text-align: left;">Article the First -­‐ Principles</p>
                <p style="padding-top: 12pt;padding-left: 5pt;text-indent: 0pt;text-align: left;">The Society and PCA are founded upon the following principles:</p>
                <ol>
                    <li style="padding-top: 12pt;padding-left: 25pt;line-height: 114%;text-align: left;">
                        <p style="display: inline;">1. Do no harm to another being or to the environment and living systems of our world.</p>
                    </li>
                    <li style="padding-top: 5pt; padding-left: 25pt;text-align: left;">
                        <p style="display: inline;">2. Give so that one may receive in equal measure.</p>
                    </li>
                    <li style="padding-top: 5pt; padding-left: 25pt;text-align: left;">
                        <p style="display: inline;">3. Do unto others as you would have done unto yourself.</p>
                    </li>
                    <li style="padding-top: 5pt; padding-left: 25pt;text-align: left;">
                        <p style="display: inline;">4. Be a peacemaker and seek resolution over conflict.</p>
                    </li>
                    <li style="padding-top: 5pt; padding-left: 25pt;text-align: left;">
                        <p style="display: inline;">5. Always  seek  to  fulfill  the  intention  to  co-­‐create  together  so  that  all  may benefit.</p>
                    </li>
                    <li style="padding-top: 5pt; padding-left: 25pt;text-align: left;">
                        <p style="display: inline;">6. Use the tools provided by and through the Society to assist others to achieve better lives whenever possible.</p>
                    </li>
                    <li style="padding-top: 5pt; padding-left: 25pt;text-align: left;">
                        <p style="display: inline;">7. Create opportunities for oneself and others in harmony with these principles and with the use and benefit of the tools of the Society and PCA.</p>
                    </li>
                    <li style="padding-top: 5pt; padding-left: 25pt;text-align: justify;">
                        <p style="display: inline;">8. Use the private Medium of Exchange that is exclusively available to members of the PCA to spread abundance for one’s community and nation, sowing seeds of prosperity that all may share in the abundance and prosperity we create together.</p>
                    </li>
                </ol>
                <p class="s1" style="padding-top: 9pt;padding-left: 5pt;text-indent: 0pt;text-align: left;">Article the Second -­‐ Venue and Jurisdiction</p>
                <ol>
                    <li style="padding-top: 12pt;padding-left: 25pt;line-height: 114%;text-align: left;">
                        <p style="display: inline;">1. The jurisdiction of the PCA and these Articles is the Kringle Private Society, a private ecclesiastical body politic, under the authority of the Office of Overseer for Kringle, a corporation sole, and His Successors, and within the Protections and Immunities of the PanTerra D’Oro Private Society.</p>
                    </li>
                    <li style="padding-top: 5pt; padding-left: 25pt;text-align: left;">
                        <p style="display: inline;">2. The Society is an unincorporated free association Mission Society.</p>
                    </li>
                    <li style="padding-top: 5pt; padding-left: 25pt;text-align: left;">
                        <p style="display: inline;">3. The venue for settlement of any disputes involving members of the society and the exclusive private use of the Medium of Exchange tools thereof shall be   the   private   ecclesiastical   court   within   the   Society   pursuant   to   its established protocols of self-­‐governance and private law.</p>
                    </li>
                    <li style="padding-top: 5pt; padding-left: 25pt;text-align: left;">
                        <p style="display: inline;">4. The venue from which the jury shall be drawn for any cases before the Court shall be the local or regional membership wherein any dispute or case arises, to be administered by the oversight of the Justices of the Court.</p>
                    </li>
                    <li style="padding-top: 5pt; padding-left: 25pt;text-align: left;">
                        <p style="display: inline;">5. A Privy Council shall be appointed by the Office of Overseer of the Society and the Holder and His Successors thereof, to administer the governing of the Society.</p>
                    </li>
                    <li style="padding-top: 5pt; padding-left: 25pt;text-align: left;">
                        <p style="display: inline;">6. A Board of Trustees shall be appointed by the Overseer to hold and act as custodian and with fiduciary duties within the scope and purposes of the Master Trust described herein below.</p>
                    </li>
                </ol>
                <p class="s1" style="padding-top: 10pt;padding-left: 5pt;text-indent: 0pt;text-align: left;">Article the Third -­‐ Policies and Protocols</p>
                <ol id="l3">
                    <li style="padding-top: 12pt;padding-left: 25pt;line-height: 114%;text-align: left;">
                        <p style="display: inline;">1. All  members  of  the  PCA  shall  adhere  to  the  policies  and  protocols  of  the PCA in order to maintain active good standing in the Society and PCA, and with  respect  to  the  use  and  beneficial  interests  of  the  sub-­‐trust  account established for each member as described herein below.</p>
                    </li>
                    <li style="padding-top: 5pt; padding-left: 25pt;text-align: left;">
                        <p style="display: inline;">2. This includes continued adherence and honoring of the Membership Agreement each member has entered into previous to the publication of these Articles, which said Agreement is now inclusive of these Articles of Association by default.</p>
                    </li>
                    <li style="padding-top: 5pt; padding-left: 25pt;text-align: left;">
                        <p style="display: inline;">3. Any member objecting to the inclusion of these Articles can do so by writing to the administration email to cancel their Membership Agreement and terminate ongoing participation in the Society and PCA.</p>
                    </li>
                    <li style="padding-top: 5pt; padding-left: 25pt;text-align: left;">
                        <p style="display: inline;">4. New members henceforward shall enter the Membership Agreement that will include these Articles and membership in the PCA.</p>
                    </li>
                    <li style="padding-top: 5pt; padding-left: 25pt;text-align: left;">
                        <p style="display: inline;">5. All members of The Billion Coin community agree that the TBC and Kringle coins will never go down in value. They can only go up in value.  The entire structure of the Society, PCA and Medium of Exchange system relies on a software program that drives the price of TBC up by 1% to 5% daily until it reaches its Ultimate Valuation.</p>
                    </li>
                    <li style="padding-top: 5pt; padding-left: 25pt;text-align: left;">
                        <p style="display: inline;">6. All members, by their acceptance of the Trust and Sub-­‐Trust arrangement and the general Terms of Use and Membership Agreement, agree to follow the  requirement  that  the  coin  and  currency  of  the  Society  shall  never  be ascribed a value other than the daily value as stated in the official website of the Society.</p>
                    </li>
                    <li style="padding-top: 5pt; padding-left: 25pt;text-align: left;">
                        <p style="display: inline;">7. All members agree that all Rules, Policies and Protocols can be updated, modified or changed from time to time at the sole discretion of the Overseer or his delegated councils, administrative teams, authorized agents or representatives.</p>
                    </li>
                    <li style="padding-top: 5pt; padding-left: 25pt;text-align: left;">
                        <p style="display: inline;">8. All members agree that they are personally and individually responsible for adherence to any local jurisdiction laws, codes and statutes that may apply, including but not limited to adherence to domestic taxation policies for the jurisdiction in which they live or to which they are legally bound.</p>
                    </li>
                    <li style="padding-top: 5pt; padding-left: 25pt;text-align: left;">
                        <p style="display: inline;">9. It is an explicit policy of the Society and PCA that we do not encourage any sort of evasion of responsibility that may adhere to any member in their local or domestic legal jurisdiction, and it is solely the responsibility of the member to determine what such responsibilities are that they must fulfill.</p>
                    </li>
                    <li style="padding-top: 5pt; padding-left: 25pt;text-align: left;">
                        <p style="display: inline;">10. The Kringle Society and Private Contract Association welcome members from all ethnicities, creeds, racial identities or other uniquely distinguishing characteristics of people worldwide. We do not exclude membership on any basis of prejudice against any people based on such personal identities. The only exception to this rule is that the Society and PCA do not support in any way the use of the Society, PCA or Medium of Exchange for any illegal purposes whatsoever, and will not accept for membership or tolerate any existing member who promotes or engages in any form of violence, terrorism or other similar acts. Any transgression to this rule is grounds for immediate expulsion.</p>
                    </li>
                </ol>

                <p class="s1" style="padding-top: 10pt;padding-left: 5pt;text-indent: 0pt;text-align: left;">Article the Fourth -­‐ Disputes and Settlements</p>
                <ol>
                    <li style="padding-top: 12pt;padding-left: 25pt;line-height: 114%;text-align: left;">
                        <p style="display: inline;">1. All disputes between members, or between the members and the administrative teams of the Society and PCA, shall be heard, adjudicated and settled according to the private protocols made available to all members of the PCA.</p>
                    </li>
                    <li style="padding-top: 5pt; padding-left: 25pt;text-align: left;">
                        <p style="display: inline;">2. The Maxims of Equity shall be part of the law of the case in all matters.</p>
                    </li>
                </ol>
                <p class="s1" style="padding-top: 12pt;padding-left: 5pt;text-indent: 0pt;text-align: left;">Article the Fifth -­‐ Mission and Purpose</p>
                <ol>
                    <li style="padding-top: 12pt;padding-left: 25pt;line-height: 114%;text-align: left;">
                        <p style="display: inline;">1. The Mission and Purpose of the PCA shall be in conformity and fulfillment of the Mission Statement published as part of the Declaration and Decree of the Overseer, annexed hereto and made a part hereof by reference and inclusion.</p>
                    </li>
                    <li style="padding-top: 5pt; padding-left: 25pt;text-align: left;">
                        <p style="display: inline;">2. The PCA administration and operations shall always be directed by and in alignment with the Mission Statement as initially declared by the Overseer and shall from time to time be updated and expanded by the combined administrative authority of the Overseer, the Privy Council and the Board of Trustees of the Society.</p>
                    </li>
                    <li style="padding-top: 5pt; padding-left: 25pt;text-align: left;">
                        <p style="display: inline;">3. All books, records and data of the PCA are secured and protected within the Immunities and Protections of the private ecclesiastical authority of the Office of Overseer and pursuant to the Covenant of Silence by the Office Holder and His Successors thereof, as well as binding upon all administrative and office holding members of the Society and PCA who are vested with office and administrative authority by the decree of the Office of Overseer.</p>
                    </li>
                </ol>
                <p class="s1" style="padding-top: 9pt;padding-left: 5pt;text-indent: 0pt;text-align: left;">Article the Sixth -­‐ Universal Sacred Trust</p>
                <ol>
                    <li style="padding-top: 12pt;padding-left: 25pt;line-height: 114%;text-align: left;">
                        <p style="display: inline;">1. The Articles of Creation for the Kringle Society include the capacity for the Overseer, and any appointed delegates representing the Office of the Overseer, to establish whatever auxiliary entities, whether public or private, that serve the purposes of the Society and PCA.</p>
                    </li>
                    <li style="padding-top: 5pt; padding-left: 25pt;text-align: left;">
                        <p style="display: inline;">2. Pursuant  thereto  the  Overseer  has  established  a  Complex,  Discretionary, Non-­‐Grantor Trust as a Universally Mandated Sacred Trust (The Brilliant Community Global Trust, henceforth “Master Trust”) for the benefit of all Human Beings on planet Earth now living and for all future generations.</p>
                    </li>
                    <li style="padding-top: 5pt; padding-left: 25pt;text-align: left;">
                        <p style="display: inline;">3. The Trust is a multi-­‐generational legacy trust and its beneficiaries are all current and future generations.</p>
                    </li>
                    <li style="padding-top: 5pt; padding-left: 25pt;text-align: left;">
                        <p style="display: inline;">4. The corpus of the Trust is the One Billion Units of Beneficial Interest brought forth into the living fabric of the Society on the inception date of the Society, PCA and Trust (March 16, 2016) by and through the Will and Intent of the Overseer to seed such beneficial interest from the universal trust of Creator Source as a Gift of Life to all such beneficiaries, now and forever. Said units of interest are known as TBC (“The Billion Coin”) and all derivative and fractional units derived therefrom, i.e., Kringle and any other such units created in the future in fulfillment of the Mission of the Society.</p>
                    </li>
                    <li style="padding-top: 5pt; padding-left: 25pt;text-align: left;">
                        <p style="display: inline;">5. Every contracting member of the PCA shall be appointed as an Executive Trustee  of  an  individual  sub-­‐trust  of  the  Master  Trust,  and  shall  have  all the  rights  of  beneficial  use  vested  therein,  for  as  long  as  the  member abides   by   the   policies   and   protocols   set   forth   herein,   as   well   as   in conformity with the private terms of the Master Trust.</p>
                    </li>
                    <li style="padding-top: 5pt; padding-left: 25pt;text-align: left;">
                        <p style="display: inline;">6. The duties and functions of every Executive Trustee are restricted to and confined within the Articles of Establishment of the Society, these Articles of    Association,    and    the    private    Master    Trust    creation    documents, exclusively  under  the  authority  of  the  Office  of  Overseer  of  Kringle,  a Corporation Sole.  Said Office holds Equitable Title and Beneficial Rights in Trust with binding fiduciary duty as custodian for the true beneficiaries as per the Maxim of Equity: “The Beneficiary is the True Owner”, while legal title  remains  with  the  Board  of  Trustees.    This  arrangement  is  for  the protection of the ultimate beneficiaries as a multi-­‐generational legacy trust for all future generations and is secured in the Office in perpetuity within the absolute authority of the Mission and Purpose of the Society.</p>
                    </li>
                    <li style="padding-top: 5pt; padding-left: 25pt;text-align: left;">
                        <p style="display: inline;">7. All contracting members of the PCA shall be equally bound by the Mission Statement and Purpose of the Society and PCA.</p>
                    </li>
                    <li style="padding-top: 5pt; padding-left: 25pt;text-align: left;">
                        <p style="display: inline;">8. The Office of Overseer, and all holders thereof, are bound by their Oaths of Office and the Articles of Establishment of the Society and these Articles. All actions undertaken by and through the authority of the Office are for the sole benefit of the current members and the future generations of the Legacy Trust in conformity with the Mission Statement of the Society.</p>
                    </li>
                </ol>
                <p class="s1" style="padding-top: 10pt;padding-left: 5pt;text-indent: 0pt;text-align: left;">Article the Seventh -­‐ Acceptance of Trust and Beneficial Interests</p>
                <ol>
                    <li style="padding-top: 12pt;padding-left: 25pt;line-height: 114%;text-align: left;">
                        <p style="display: inline;">1. All TBC and Kringle (currency and coin) constitute the corpus of the Master Trust and are entrusted to the fiduciary and custodial duties of the Board of Trustees and the Office of Overseer holding legal and equitable title respectively.</p>
                    </li>
                    <li style="padding-top: 5pt; padding-left: 25pt;text-align: left;">
                        <p style="display: inline;">2. All verified members in good standing of The Billion Coin holding accounts as of the publication of these Articles are vested on par into the individual sub-­‐trusts established by the Master Trust.</p>
                    </li>
                    <li style="padding-top: 5pt; padding-left: 25pt;text-align: left;">
                        <p style="display: inline;">3. Each  member  is  automatically  appointed  as  Executive  Trustee  of  the individual  sub-­‐trust  created  either  by  the  vesting  of  current  members  or the vesting of each sub-­‐trust ongoing as new members join the Society and PCA.</p>
                    </li>
                    <li style="padding-top: 5pt; padding-left: 25pt;text-align: left;">
                        <p style="display: inline;">4. An  Executive  Trustee  is  authorized  to  act  on  the  orders  of  the  Trustee (Board  of  Trustees),  with  instructions  that  are  further  detailed  privately for each member.  Every member retains limited beneficial use of the sub-­‐ account  trust  as  a  Cestui  Que  Trust  (beneficiary).    Details  of  the  duties, capacities,   responsibilities   and   benefits   of   the   Executive   Trustee   are provided  in  the  ongoing  education  provided  to  the  members  of  the  PCA within  the  Kringle  Cash  Back  Office.    Neither  the  Cestui  Que  Trust  nor Executive Trustee hold legal title to the corpus and the said corpus is not part  of  the  legal  estate  of  the  Executive  Trustee,  nor  does  the  Cestui  Que Trust hold absolute equitable interests or beneficial rights.</p>
                    </li>
                    <li style="padding-top: 5pt; padding-left: 25pt;text-align: left;">
                        <p style="display: inline;">5. All current members who wish to maintain and continue their membership do not have to do anything to indicate acceptance of these Articles. Only those who object to ongoing participation need to take active steps to indicate objection; all others establish acceptance by silence as acquiescence.</p>
                    </li>
                    <li style="padding-top: 5pt; padding-left: 25pt;text-align: left;">
                        <p style="display: inline;">6. Future members will indicate their acceptance of these articles by the activation of their membership.</p>
                    </li>
                    <li style="padding-top: 5pt; padding-left: 25pt;text-align: left;">
                        <p style="display: inline;">7. Each   Cestui   Que   Trust   shall   have   appointed   authority,   as   Executive Trustee, to manage the corpus within the policies and protocols of the PCA Articles and Membership Agreement of the Kringle Society.  The Executive Trustee may, at his or her own discretion, direct the use of the corpus for any  and  all  contractual  exchanges  for  goods,  services  or  other  fungible commercial   or   non-­‐commercial   instruments   of   exchange.     Each   such exchange  shall  be  booked  as  a  partial  distribution  of  the  corpus  to  the limited beneficiary.</p>
                    </li>
                    <li style="padding-top: 5pt; padding-left: 25pt;text-align: left;">
                        <p style="display: inline;">8. All Cestui Que Trust recipients (limited beneficial use holders) are required to abide by any and all legal laws, codes and statutes that may apply within their domestic jurisdiction of residence or other legal standing.</p>
                    </li>
                    <li style="padding-top: 5pt; padding-left: 25pt;text-align: left;">
                        <p style="display: inline;">9. It is possible that such partial distributions of the corpus may carry tax consequences and all members are encouraged to seek professional input on the tax liabilities and/or requirements within their domestic jurisdiction of residence.</p>
                    </li>
                    <li style="padding-top: 5pt; padding-left: 25pt;text-align: left;">
                        <p style="display: inline;">10. The  Kringle  Society  explicitly  does  not  provide  legal,  tax  or  financial advice, nor  does  it in  any  way  promote  the  use  of  the  private Medium  of Exchange  as  a  means  to  avoid  tax  obligations  where  a  person  is  liable  to pay  such  taxes  for  the  receipt  of  beneficial  disbursements  of  the  sub-­‐ account trust.  We encourage each member to seek professional assistance to determine potential tax liabilities if and as they might apply for received benefits.</p>
                    </li>
                    <li style="padding-top: 5pt; padding-left: 25pt;text-align: left;">
                        <p style="display: inline;">11. No  Executive  Trustee  has  the  right  or  authority  to  disburse  the  entire corpus of the sub-­‐account trust that he or she has limited authority over. Every  Executive  Trustee  is  obligated  to  follow  and  perform  the  orders  of the Board of Trustees, Master Trustee holding legal title.</p>
                    </li>
                    <li style="padding-top: 5pt; padding-left: 25pt;text-align: left;">
                        <p style="display: inline;">12. The  Ultimate  Beneficial  Owners  of  the  Master  Trust  are  the  succeeding Seven  Generations  as  the  True  Beneficiaries  of  the  Multi-­‐Generational Legacy Trust known as the Kringle Society.</p>
                    </li>
                    <li style="padding-top: 5pt; padding-left: 25pt;text-align: left;">
                        <p style="display: inline;">13. All members pledge their commitment to not commit any illegal acts when using the private Medium of Exchange for the acquisition of goods or services. Any transgression of this pledge shall become grounds for immediate termination of membership and forfeiture of Cestui Que Trust rights and benefits.</p>
                    </li>
                    <li style="padding-top: 5pt; padding-left: 25pt;text-align: left;">
                        <p style="display: inline;">
                            14. The Kringle Society does not promote or support in any way acts of violence or terrorism and is pledged to maintain constant vigilance to prevent the intrusion of such into our private Society and Private Contract Association. The Kringle Society has been established within the jurisdiction of PanTerra D’Oro Private Society in alignment with its Declaration of Intention
                            <span class="s4">1</span>
                            <span class="s5"></span>and Treaty of Universal Peace
                            <span class="s4">2</span>.
                        </p>
                    </li>
                    <li style="padding-top: 5pt; padding-left: 25pt;text-align: left;">
                        <p style="display: inline;">15. The Kringle Society, PCA and Office of Overseer are at peace with the United States and neutral in the public pursuant to and in alignment with the Treaty of Universal Peace as referenced, and inclusive of all public world administrative bodies, legitimate governments and the people of the world.</p>
                    </li>
                </ol>
                <p style="text-indent: 0pt;text-align: left;">
                    <br />
                </p>
                <p style="text-indent: 0pt;text-align: center;">End of Articles</p>
                <div class="text-center">
                    <img src="images/aaa1.png" />
                </div>
                <ol id="l8">
                    <li style="padding-top: 11pt;padding-left: 11pt;text-indent: -6pt;line-height: 15pt;text-align: left;">
                        <p class="s7" style="display: inline;">
                            <a href="https://www.panterrapca.org/foundational-documents/declaration-of-intention" class="a" target="_blank">1 https://www.panterrapca.org/foundational-documents/declaration-of-intention</a>
                        </p>
                    </li>
                    <li style="padding-left: 11pt;text-indent: -6pt;line-height: 15pt;text-align: left;">
                        <p class="s7" style="display: inline;">
                            <a href="https://www.panterrapca.org/public-notices/world-administrative-bodies/notice-to-the-holy-see" class="a" target="_blank">2 https://www.panterrapca.org/public-notices/world-administrative-bodies/notice-to-the-holy-see</a>
                        </p>
                    </li>
                </ol>
            </div>
        </div>

    </div>
<script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script></body>

