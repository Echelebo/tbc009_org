<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css" integrity="sha384-hWVjflwFxL6sNzntih27bfxkr27PmbbK/iSvJ+a4+0owXq79v+lsFkW54bOGbiDQ" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/smoothness/jquery-ui.css">
    <link href="../content/css/style.css" rel="stylesheet" />

    <title>Kringle.cash</title>
    <script type="text/javascript">
        function googleTranslateElementInit() {
            new google.translate.TranslateElement({ pageLanguage: 'en', layout: google.translate.TranslateElement.InlineLayout.SIMPLE }, 'google_translate_element');
        }
    </script>
    <script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
</head>
<body id="reg_form">

    <nav id="TopNav" class="navbar navbar-dark bg-dark">
        <a class="navbar-brand" href="#">
            <img id="logo" src="../content/img/logo_75.png" />
        </a>
        <!--<ul class="navbar-nav">
            <li class="nav-item active">
                <a class="nav-link navbar-header" href="#"><img id="logo" src="./content/img/dark_logo_50.png" /> </a>
            </li>
        </ul>-->
        <div class="navbar-expand" id="navbarNavAltMarkup">
            <div class="navbar-nav">
                <div id="google_translate_element" style="margin-top: 18px"></div>
            </div>
            <div class="navbar-nav">
                <a class="nav-item nav-link" href="https://kringle.cash/portal/">Login</a>
                <a class="nav-item nav-link" href="https://kringle.cash/goodwill.php">Goodwill</a>
                <a class="nav-item nav-link" href="https://kringle.cash/portal/merchant_locations.php">Merchant Locations</a>
                <a class="nav-item nav-link" href="https://kringle.cash/publicnotice.php" target="_blank">Public Notice</a>
            </div>


        </div>

    </nav>
<link href="content/css/registration_form.css?v7" rel="stylesheet"/>
<link href="css/face.css?v65fad18be2b65" rel="stylesheet"/>
<div class="container">
    <div class="row">
        <div class="col">&nbsp;</div>
    </div>
    <div class="row">
        <div class="col text-center">
            <ul id="breadcrumb">
                <li><a><span></span></a></li>
                <li><a href="#" class="active">Start Registration</a></li>
                <li><a href="#">Complete Registration</a></li>
                <li><a href="#">Access Account</a></li>
            </ul>
        </div>
    </div>

    <div class="row">
        <div class="col text-center">
            <!---<img id="video1" src="content/img/welcome.jpg" class="img-fluid" data-video="https://www.youtube.com/embed/ZvvlZ7FUMI4?autoplay=1" />
            <br />
            <img src="content/img/helpwanted.jpg" class="img-fluid" />--->
            <!--
            take this out while testing
            <img src="content/img/newreg.png" class="img-fluid"/>
            -->
            <br/>
            <b>
                For details on the Mass Adoption Team and the Rotator
                <a href="TBCMassAdoptionandRotator.pdf" target="_blank"> READ MORE</a>
            </b>

        </div>
    </div>

    <div class="row">
        <div class="col">
            <div class="email-section" style="padding-top:2em;text-align:center">
                <p><b>Enter Your Email Address: </b></p>
                <div id="#uiRegistrationEmailDiv">
                    <input id="uiRegistrationEmail" name="uiRegistrationEmail" type="email"
                           placeholder="Registration Email Address" class="form-control" style="max-width: 20rem;"
                           required/>
                    <input id='checkEmailButton' type="button" class='button btn-primary' role="button"
                           value="Click To Proceed" style="margin-top:1em" onclick="checkForExistingReg();"/>
                </div>

                <div id="validation_feedback"></div>
            </div>
        </div>
    </div>
</div>

<div id="after_email" style="display:none">
    <div class="row">
        <div class="col text-center">
            <span class="sponsor-text text-warning">
                YOUR SPONSOR IS <span id='ds_sponsorname'>Admin</span>
            </span>
        </div>
    </div>
    <div class="row">
        <div class="col text-center">
            <b>Our Current Membership Count: 3,885,259</b><br /><br />        </div>
    </div>
    <div class="row">
        <div class="col text-center">
            <b>Kringle Cash Visitors</b>
            <br/>
            <script type="text/javascript"
                    src="//rf.revolvermaps.com/0/0/2.js?i=54h3q22imgc&amp;m=8&amp;s=130&amp;c=ff0000&amp;t=1"
                    async="async"></script>
        </div>
    </div>
    <div class="row">
        <div class="col">
            &nbsp;
            <br/>
            <br/>
        </div>
    </div>
    <div class="row">
        <div class="col text-center">
            <button type="button" name="register" id="step1Reg" class="btn btn-dark submit-button"
                    onclick="proceedToStep2()">Continue To Step 2
            </button>
            <p>
                Do not press the back button on your browser if registering multiple members, always use your
                referral
                link for best results.
            </p>
        </div>
    </div>
</div>


<!-- We're changing this to a form post because people are lingering on this page and sessions are timing out -->
<div id="formdiv" style="display:none">
    <form id='regform' method="post" action="registration_step2.php">
        <input type="hidden" name="key" id="key" value="949648c205c0abc77f9596">
        <input type="hidden" name="suid" id="suid" value="1">
        <input type="hidden" name="suname" id="suname" value="admin">
        <input type="hidden" name="reftype" id="reftype" value="0">
        <input type="hidden" name="sig" id="sig" value="64ca51ef04f32f6a49c93635a9bbae52639f3424059e44af61e21f5a24f87082">
        <input type="hidden" name="f_email" id="f_email" value="">
        <input type="hidden" name="ts" id="ts" value="1710936459">
                <input type="hidden" name="session" id="session" value="%7B%22wscid%22%3Anull%2C%22token%22%3A%222bce32ed409f5ebcee2a7b417ad9beed%22%2C%22ip%22%3A%22197.210.55.71%22%2C%22user_agent%22%3A%22Mozilla%5C%2F4.5+%28compatible%3B+HTTrack+3.0x%3B+Windows+98%29%22%2C%22sponsor_uid%22%3A1%2C%22sponsor_name%22%3A%22Admin%22%2C%22sponsor_email%22%3A%22admin%40thebillioncoin.info%22%2C%22sponsor_uname%22%3A%22admin%22%7D">
    </form>
</div>


<!-- Please Wait Modal -->
<div id="pleaseWaitModal" class="modal fade pleaseWaitModal modal-sm" style="margin:auto;color:black"
     data-backdrop="static"
     data-keyboard="false"
     role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Please Wait</h4>
            </div>
            <div class="modal-body">
                <p>We are processing your request</p>
            </div>
            <div class="modal-footer">
            </div>
        </div>

    </div>
</div>

<div id="footer" class="nav-background-footer">

</div>
</body>
</html>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
<script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.20/js/dataTables.bootstrap4.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>




<script type="text/javascript">
    $("#uiEmail").focus();

    function checkForExistingReg() {
        var email = $("#uiRegistrationEmail").val();
        $("#validation_feedback").val('');
        $('#pleaseWaitModal').modal("show");

        $.ajax({
            type: 'POST',
            url: 'code/ajax/_registration.php',
            data: {email: email, action: "checkforexistingv1"},

            success: function (data) {
                $('#pleaseWaitModal').modal("hide");
                var jdata = JSON.parse(data);
                if (jdata.valid) {
                    $("#f_email").val(email);
                    $("#after_email").show();
                    $("#uiRegistrationEmail").attr("readonly", "readonly");
                    $("#checkEmailButton").hide();
                } else { //jdata is not true
                    if (jdata.message != "") {
                        $("#uiRegistrationEmail").focus();
                        alert(jdata.message)
                    }
                }

            },
            complete(xhr, status) {
                $('#pleaseWaitModal').modal("hide");
            }
        });
    }

    function proceedToStep2() {
        if ($("#uiEmail").val() != '') {
            $("#regform").submit();
        } else {
            alert("Email Required");
        }
    }

    /*
     * **** NOTE :: This is deprecated in favor of using a hidden form (proceedToStep2()) to post
     * to page 2.
     *
     * This will preserve their sponsor so that if in face their session does timeout
     * we can redirect them back to page one and preserve their sponsor. See the rather
     * large redirect at the top of page 2.
     * TODO::signature test - This should really be arrranged in alpha order
     */
        //This is deprecated in favor of the hidden form approach we switched to
    function proceedToStep2_old() {

        if ($("#uiEmail").val() != '') {
            var ts = Math.floor(Date.now() / 1000); //might use this later it should be part of the sig - Unix timestamp
            location.href = 'registration_step2.php?key=949648c205c0abc77f9596&ts=1710936459&suid=1&sig=64ca51ef04f32f6a49c93635a9bbae52639f3424059e44af61e21f5a24f87082';
        } else {
            alert("Email Required");
        }
    }


</script>