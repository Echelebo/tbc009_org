<html>
<title>Kringle.Cash</title>
<head>
    <meta http-equiv="Content-Type" content="application/xhtml+xml; charset=UTF-8" />
    <link rel="shortcut icon" href="favicon.ico" />
    <!-- mobile settings -->
    <meta name="viewport" content="width=device-width, maximum-scale=1, initial-scale=1, user-scalable=0" />	
    <meta property="og:image" content="https://kringle.cash/images/linkimage2c.jpg" />
	<meta property="og:description" content="Become a Millionaire automatically FREE of CHARGE.   This Cash Giveaway expires soon!  Click NOW and collect your GIFT!" />
	<meta property="og:url" content="https://kringle.cash/" />
    <meta property="og:title" content="Kringle.Cash" />
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css"/>
      
      <script type="text/javascript" src="js/jquery.js"></script> 
	  <script type="text/javascript" src="js/bootstrap.js"></script>
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
	<style>

	</style>
    <link href="css/style.css" media="screen" rel="stylesheet" type="text/css">
    <link href="css/ownstyle.css" media="screen" rel="stylesheet" type="text/css">
    <link href="css/mystyle.css" media="screen" rel="stylesheet" type="text/css">
    <link href="css/info1.css" media="screen" rel="stylesheet" type="text/css">
    <script type="text/javascript">
        function googleTranslateElementInit() {
            new google.translate.TranslateElement({pageLanguage: 'en', layout: google.translate.TranslateElement.InlineLayout.SIMPLE}, 'google_translate_element');
        }
    </script>
    <script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
    <!--<div id="google_translate_element"></div>-->
    <style>
        .goog-te-menu-value img {
           display: none;
        }
        .goog-te-gadget-simple img {
        background-image: url('images/KringleCoin.gif')!important;
        }
    </style>
</head>
<body>
<header>
    <div class="header-top" id="menuUser">
        <div class="container">
            <div class="row">
                <div class="col">
                <!--<div class="col-sm-2 col-xs-12" style="width: 13.666667%;    margin-top: -3px;" id="google_translate_element">
                </div>-->
                <div class="float-right" style="display: inline-block;margin-right: 16px;height: 36px;float: right;">
                    <div id="google_translate_element"></div>
                </div>
                    </div>
            </div>
        </div>
    </div>
</header>


<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://fonts.googleapis.com/css2?family=Fugaz+One&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Roboto+Condensed&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/grid-gallery.min.css">
    <link rel="stylesheet" href="css/style.css?20210128">
    <title>Kluv Coin</title>
  </head>

  <body>

    <div class="goodwill-box d-flex align-center justify-space-around">
      <div class="box">
	      <h2>Report of our Goodwill event on October 22nd 2022</h2>
        <img src="https://www.kluvcoin.io/img/R3_mbeh.jpg" />
        <p>
          Cameroon enjoys the Goodwill program for the third time. This time the Goodwill 
          program was carried out in the southwest region of Cameroon. It should be noted 
          that this area is a very risky area due to war crises. Many have ran away 
          leaving behind children who are now in orphanages. The prices of food in this 
          area is extremely high due to inflations and the war crises.
          <br/><br/>
          However 460 bags of rice was shared each about 10kg. 460 bottles of vegetable oils 
          as well as washing soap. Those who benefited were the blind, dump, physically 
          impaired persons and orphanages. We also had widows and widowers who were taken care 
          of. Each person went home with 10kg of rice , a botttle of vegetable oil, garri and 
          4 wishing soap.
          <br/><br/>
          This people are so vulnerable and are leaving in real poverty. Nobody cares about 
          them as some confess that for many years no organizations has taken care of them so 
          far. There were all more than happy and showered lots of blessings to the KLUV/TBC 
          administrators.
          <br/><br/>
          We must keep appreciating the Admin for this program and we pray for more wisdom to 
          keep the community moving forward.
          <br/><br/>
          Thank you.
        </p>
        <p><b>Receipts</b></p>
		    <div class="gg-container" style="padding: 0 30px;">
          <div class="gg-box gallery goodwill-gallery">
            <img src="https://www.kluvcoin.io/img/mbeh_round3/receipt/1.jpg" />
            <img src="https://www.kluvcoin.io/img/mbeh_round3/receipt/2.jpg" />
            <img src="https://www.kluvcoin.io/img/mbeh_round3/receipt/3.jpg" />
            <img src="https://www.kluvcoin.io/img/mbeh_round3/receipt/4.jpg" />
          </div>
        </div>

        <br/><br/>
        <p><b>Event Photos</b></p>
		    <div class="gg-container" style="padding: 0 30px;">
          <div class="gg-box gallery goodwill-gallery">
            <img src="https://www.kluvcoin.io/img/mbeh_round3/event/1.jpg" />
            <img src="https://www.kluvcoin.io/img/mbeh_round3/event/2.jpg" />
            <img src="https://www.kluvcoin.io/img/mbeh_round3/event/3.jpg" />
            <img src="https://www.kluvcoin.io/img/mbeh_round3/event/4.jpg" />
            <img src="https://www.kluvcoin.io/img/mbeh_round3/event/5.jpg" />
            <img src="https://www.kluvcoin.io/img/mbeh_round3/event/6.jpg" />
            <img src="https://www.kluvcoin.io/img/mbeh_round3/event/7.jpg" />
            <img src="https://www.kluvcoin.io/img/mbeh_round3/event/8.jpg" />
            <img src="https://www.kluvcoin.io/img/mbeh_round3/event/9.jpg" />
            <img src="https://www.kluvcoin.io/img/mbeh_round3/event/10.jpg" />
            <img src="https://www.kluvcoin.io/img/mbeh_round3/event/11.jpg" />
            <img src="https://www.kluvcoin.io/img/mbeh_round3/event/12.jpg" />
            <img src="https://www.kluvcoin.io/img/mbeh_round3/event/13.jpg" />
            <img src="https://www.kluvcoin.io/img/mbeh_round3/event/14.jpg" />
            <img src="https://www.kluvcoin.io/img/mbeh_round3/event/15.jpg" />
            <img src="https://www.kluvcoin.io/img/mbeh_round3/event/16.jpg" />
            <img src="https://www.kluvcoin.io/img/mbeh_round3/event/17.jpg" />
            <img src="https://www.kluvcoin.io/img/mbeh_round3/event/18.jpg" />
            <img src="https://www.kluvcoin.io/img/mbeh_round3/event/19.jpg" />
            <img src="https://www.kluvcoin.io/img/mbeh_round3/event/20.jpg" />
            <img src="https://www.kluvcoin.io/img/mbeh_round3/event/21.jpg" />
            <img src="https://www.kluvcoin.io/img/mbeh_round3/event/22.jpg" />
            <img src="https://www.kluvcoin.io/img/mbeh_round3/event/23.jpg" />
            <img src="https://www.kluvcoin.io/img/mbeh_round3/event/24.jpg" />
            <img src="https://www.kluvcoin.io/img/mbeh_round3/event/25.jpg" />
            <img src="https://www.kluvcoin.io/img/mbeh_round3/event/26.jpg" />
            <img src="https://www.kluvcoin.io/img/mbeh_round3/event/27.jpg" />
            <img src="https://www.kluvcoin.io/img/mbeh_round3/event/28.jpg" />
            <img src="https://www.kluvcoin.io/img/mbeh_round3/event/29.jpg" />
            <img src="https://www.kluvcoin.io/img/mbeh_round3/event/30.jpg" />
            <img src="https://www.kluvcoin.io/img/mbeh_round3/event/31.jpg" />
            <img src="https://www.kluvcoin.io/img/mbeh_round3/event/32.jpg" />
            <img src="https://www.kluvcoin.io/img/mbeh_round3/event/33.jpg" />
            <img src="https://www.kluvcoin.io/img/mbeh_round3/event/34.jpg" />
            <img src="https://www.kluvcoin.io/img/mbeh_round3/event/35.jpg" />
            <img src="https://www.kluvcoin.io/img/mbeh_round3/event/36.jpg" />
            <img src="https://www.kluvcoin.io/img/mbeh_round3/event/37.jpg" />
            <img src="https://www.kluvcoin.io/img/mbeh_round3/event/38.jpg" />
            <img src="https://www.kluvcoin.io/img/mbeh_round3/event/39.jpg" />
            <img src="https://www.kluvcoin.io/img/mbeh_round3/event/40.jpg" />
            <img src="https://www.kluvcoin.io/img/mbeh_round3/event/41.jpg" />
          </div>
        </div>

        <br/>
        <br/>
        <hr/>
        <p><b>Event Video:</b></p>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/4xTldvSbNVI" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
      </div>
    </div>

    <script src="../js/grid-gallery.min.js"></script>
    
    <script>
      gridGallery({
        selector: ".gallery",
        darkMode: true,
        layout: "square",
        gapLength: 10,
        rowHeight: 300,
        columnWidth: 300
      });
    </script>
  </body>
</html>