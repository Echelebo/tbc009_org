<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css" integrity="sha384-hWVjflwFxL6sNzntih27bfxkr27PmbbK/iSvJ+a4+0owXq79v+lsFkW54bOGbiDQ" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/smoothness/jquery-ui.css">
    <link href="../content/css/style.css" rel="stylesheet" />

    <title>Kringle.cash</title>
    <script type="text/javascript">
        function googleTranslateElementInit() {
            new google.translate.TranslateElement({ pageLanguage: 'en', layout: google.translate.TranslateElement.InlineLayout.SIMPLE }, 'google_translate_element');
        }
    </script>
    <script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
</head>
<body id="reg_form">

    <nav id="TopNav" class="navbar navbar-dark bg-dark">
        <a class="navbar-brand" href="#">
            <img id="logo" src="../content/img/logo_75.png" />
        </a>
        <!--<ul class="navbar-nav">
            <li class="nav-item active">
                <a class="nav-link navbar-header" href="#"><img id="logo" src="./content/img/dark_logo_50.png" /> </a>
            </li>
        </ul>-->
        <div class="navbar-expand" id="navbarNavAltMarkup">
            <div class="navbar-nav">
                <div id="google_translate_element" style="margin-top: 18px"></div>
            </div>
            <div class="navbar-nav">
                <a class="nav-item nav-link" href="https://kringle.cash/portal/">Login</a>
                <a class="nav-item nav-link" href="https://kringle.cash/goodwill.php">Goodwill</a>
                <a class="nav-item nav-link" href="https://kringle.cash/portal/merchant_locations.php">Merchant Locations</a>
                <a class="nav-item nav-link" href="https://kringle.cash/publicnotice.php" target="_blank">Public Notice</a>
            </div>


        </div>

    </nav>
<link href="content/css/registration_form.css?v7" rel="stylesheet"/>
<link href="css/face.css?v65fad18c3ee2b" rel="stylesheet"/>
<div class="container">
    <div class="row">
        <div class="col">&nbsp;</div>
    </div>
    <div class="row">
        <div class="col text-center">
            <ul id="breadcrumb">
                <li><a><span></span></a></li>
                <li><a href="#" class="active">Start Registration</a></li>
                <li><a href="#">Access Account</a></li>
                <li><a href="#">Face Verification Enrollment</a></li>
            </ul>
        </div>
    </div>

    <div class="row">
        <div class="col text-center">
                                    <!---<img id="video1" src="content/img/welcome.jpg" class="img-fluid" data-video="https://www.youtube.com/embed/ZvvlZ7FUMI4?autoplay=1" />
            <br />
            <img src="content/img/helpwanted.jpg" class="img-fluid" />--->
            <!--
            take this out while testing
            <img src="content/img/newreg.png" class="img-fluid"/>
            -->
            <br/>
            <b>
                <!---For details on the Mass Adoption Team and the Rotator
                <a href="TBCMassAdoptionandRotator.pdf" target="_blank"> READ MORE</a>--->
            </b>
            <br/>
            <br/>
            <br/>
            Select your preferred language for the following video:
            <div class="row" style="margin:20px auto">

                <select name="select" onChange="changelanguage(this.value)"
                        style="color:black;right;width:300px;margin:20px auto" class="form-control">
                    <option value="english" selected>ENGLISH</option>
                    <option value="french">FRENCH</option>

                </select>
            </div>


            <iframe frameborder="0" id="iframevideo" width="100%" style="max-width:800px" height="600"
                    src="https://www.youtube.com/embed/nX5qI_DPWH4"></iframe>

            </b>
            <img src="content/img/photo_2022-06-30_15-21-19.jpg" class="img-fluid"/>


            <script>/** * Comment */function changelanguage(language) {
                    if (language == "english") {
                        document.getElementById('iframevideo').src = "https://www.youtube.com/embed/nX5qI_DPWH4";
                    }
                    if (language == "french") {
                        document.getElementById('iframevideo').src = "https://www.youtube.com/embed/j-vC4nO4zBY";
                    }

                }</script>


        </div>
    </div>
</div>
</div>

<div class="row">
    <div class="col">
        <div class="email-section" style="padding-top:2em;text-align:center">
                <span style="color:yellow;"><p><b>PLEASE CREATE YOUR WALLET AT
                <a href="https://TBC009.net" target="_blank">https://TBC009.net</a><span style="color:yellow;"> with the same Email address you register here with.
                </p><p>DO THIS IMMEDIATELY AFTER KCBO REGISTRATION TO ENSURE YOUR REWARDS AND GIFT MAKE IT TO YOUR NEW WALLET.</b></p>
                    </p>
                    <span style="color:white;"><p><b>Enter Your Email Address: </b></p>
                <div id="#uiRegistrationEmailDiv">
                    <input id="uiRegistrationEmail" name="uiRegistrationEmail" type="email"
                           placeholder="Registration Email Address" class="form-control" style="max-width: 20rem;"
                           required/>
                    <input id='checkEmailButton' type="button" class='button btn-primary' role="button"
                           value="Verify Email" style="margin-top:1em" onclick="checkForExistingReg();"/>
                </div>

                <div id="validation_feedback"></div>
        </div>
    </div>
</div>
<div class="row">
    <div class="offset-md-3 col-md-6 text-md-center" style="padding-bottom:1em;">
        If you do not log into your account and complete facial recognition within 15 minutes of registering,
        your information will be discarded and you will have to re-register.
    </div>
</div>

<!-- Information merged in from page 2 -->
<div id="">
    <div class="row">
        <div class="col">

            <div class="reg-form" style="max-width: 35rem;margin:auto;">
                <form role="form" action="" method="post" id="register">
                    <!--<form class="m-t register" role="form" action="javascript:void(0)" method="post">-->
                    <!-- this is carry over from the original page 2 we should delete this -->
                    <!--
                    <div class="form-group">
                        <input type="text" name="uiRegistrationEmail" class="form-control"
                               readonly id="uiRegistrationEmail" value="">
                </div>
                -->

                    <div id='rkform' style="display:none">
                        Enter your current address
                        <input type="text" id="rkaddress" name="rkaddress">
                    </div>

                    <div class="form-group">
                        <input type="text" name="fullname" pattern="[a-zA-Z\s]+" class="form-control after-email"
                               placeholder="Full Name" required="" id="fullname">
                    </div>
                    <div class="form-group">
                        <input type="text" name="username" class="form-control after-email" placeholder="UserName"
                               required="" id="username">
                        <span style="color:white;">*Usernames can only contain alphanumeric characters including underscore
                        (_)</span>

                    </div>

                    <div class="form-group">
                        <input type="text" name="u_phone" id="u_phone" placeholder="Phone Number"
                               class="form-control after-email" required>
                        <a href="#" id="tplink" style="display:inline-block;margin-left: 15px;">Formatting
                            Guidelines</a></td>
                    </div>

                    <div class="form-group">
                        <select name="country" class="form-control after-email" required id="country">
                            <option value="">--Select Country--</option>
                                                            <option
                                        value="Afghanistan">
                                    Afghanistan                                </option>
                                                                <option
                                        value="Albania">
                                    Albania                                </option>
                                                                <option
                                        value="Algeria">
                                    Algeria                                </option>
                                                                <option
                                        value="Andorra">
                                    Andorra                                </option>
                                                                <option
                                        value="Angola">
                                    Angola                                </option>
                                                                <option
                                        value="Anguilla">
                                    Anguilla                                </option>
                                                                <option
                                        value="Antarctica">
                                    Antarctica                                </option>
                                                                <option
                                        value="Antigua and Barbuda">
                                    Antigua and Barbuda                                </option>
                                                                <option
                                        value="Argentina">
                                    Argentina                                </option>
                                                                <option
                                        value="Armenia">
                                    Armenia                                </option>
                                                                <option
                                        value="Aruba">
                                    Aruba                                </option>
                                                                <option
                                        value="Australia">
                                    Australia                                </option>
                                                                <option
                                        value="Austria">
                                    Austria                                </option>
                                                                <option
                                        value="Azerbaijan">
                                    Azerbaijan                                </option>
                                                                <option
                                        value="Bahamas">
                                    Bahamas                                </option>
                                                                <option
                                        value="Bahrain">
                                    Bahrain                                </option>
                                                                <option
                                        value="Bangladesh">
                                    Bangladesh                                </option>
                                                                <option
                                        value="Barbados">
                                    Barbados                                </option>
                                                                <option
                                        value="Belarus">
                                    Belarus                                </option>
                                                                <option
                                        value="Belgium">
                                    Belgium                                </option>
                                                                <option
                                        value="Belize">
                                    Belize                                </option>
                                                                <option
                                        value="Benin">
                                    Benin                                </option>
                                                                <option
                                        value="Bermuda">
                                    Bermuda                                </option>
                                                                <option
                                        value="Bhutan">
                                    Bhutan                                </option>
                                                                <option
                                        value="Bolivia">
                                    Bolivia                                </option>
                                                                <option
                                        value="Bosnia and Herzegovina">
                                    Bosnia and Herzegovina                                </option>
                                                                <option
                                        value="Botswana">
                                    Botswana                                </option>
                                                                <option
                                        value="Bouvet Island">
                                    Bouvet Island                                </option>
                                                                <option
                                        value="Brazil">
                                    Brazil                                </option>
                                                                <option
                                        value="British Indian Ocean Territory">
                                    British Indian Ocean Territory                                </option>
                                                                <option
                                        value="Brunei Darussalam">
                                    Brunei Darussalam                                </option>
                                                                <option
                                        value="Bulgaria">
                                    Bulgaria                                </option>
                                                                <option
                                        value="Burkina Faso">
                                    Burkina Faso                                </option>
                                                                <option
                                        value="Burundi">
                                    Burundi                                </option>
                                                                <option
                                        value="Cambodia">
                                    Cambodia                                </option>
                                                                <option
                                        value="Cameroon">
                                    Cameroon                                </option>
                                                                <option
                                        value="Canada">
                                    Canada                                </option>
                                                                <option
                                        value="Cape Verde">
                                    Cape Verde                                </option>
                                                                <option
                                        value="Cayman Islands">
                                    Cayman Islands                                </option>
                                                                <option
                                        value="Central African Republic">
                                    Central African Republic                                </option>
                                                                <option
                                        value="Chad">
                                    Chad                                </option>
                                                                <option
                                        value="Chile">
                                    Chile                                </option>
                                                                <option
                                        value="China">
                                    China                                </option>
                                                                <option
                                        value="Christmas Island">
                                    Christmas Island                                </option>
                                                                <option
                                        value="Cocos (Keeling) Islands">
                                    Cocos (Keeling) Islands                                </option>
                                                                <option
                                        value="Colombia">
                                    Colombia                                </option>
                                                                <option
                                        value="Comoros">
                                    Comoros                                </option>
                                                                <option
                                        value="Congo">
                                    Congo                                </option>
                                                                <option
                                        value="Cook Islands">
                                    Cook Islands                                </option>
                                                                <option
                                        value="Costa Rica">
                                    Costa Rica                                </option>
                                                                <option
                                        value="Croatia (Hrvatska)">
                                    Croatia (Hrvatska)                                </option>
                                                                <option
                                        value="Cuba">
                                    Cuba                                </option>
                                                                <option
                                        value="Cyprus">
                                    Cyprus                                </option>
                                                                <option
                                        value="Czech Republic">
                                    Czech Republic                                </option>
                                                                <option
                                        value="Denmark">
                                    Denmark                                </option>
                                                                <option
                                        value="Djibouti">
                                    Djibouti                                </option>
                                                                <option
                                        value="Dominica">
                                    Dominica                                </option>
                                                                <option
                                        value="Dominican Republic">
                                    Dominican Republic                                </option>
                                                                <option
                                        value="East Timor">
                                    East Timor                                </option>
                                                                <option
                                        value="Ecuador">
                                    Ecuador                                </option>
                                                                <option
                                        value="Egypt">
                                    Egypt                                </option>
                                                                <option
                                        value="El Salvador">
                                    El Salvador                                </option>
                                                                <option
                                        value="Equatorial Guinea">
                                    Equatorial Guinea                                </option>
                                                                <option
                                        value="Eritrea">
                                    Eritrea                                </option>
                                                                <option
                                        value="Estonia">
                                    Estonia                                </option>
                                                                <option
                                        value="Ethiopia">
                                    Ethiopia                                </option>
                                                                <option
                                        value="Falkland Islands (Malvinas)">
                                    Falkland Islands (Malvinas)                                </option>
                                                                <option
                                        value="Faroe Islands">
                                    Faroe Islands                                </option>
                                                                <option
                                        value="Fiji">
                                    Fiji                                </option>
                                                                <option
                                        value="Finland">
                                    Finland                                </option>
                                                                <option
                                        value="France">
                                    France                                </option>
                                                                <option
                                        value="France, Metropolitan">
                                    France, Metropolitan                                </option>
                                                                <option
                                        value="French Guiana">
                                    French Guiana                                </option>
                                                                <option
                                        value="French Polynesia">
                                    French Polynesia                                </option>
                                                                <option
                                        value="French Southern Territories">
                                    French Southern Territories                                </option>
                                                                <option
                                        value="Gabon">
                                    Gabon                                </option>
                                                                <option
                                        value="Gambia">
                                    Gambia                                </option>
                                                                <option
                                        value="Georgia">
                                    Georgia                                </option>
                                                                <option
                                        value="Germany">
                                    Germany                                </option>
                                                                <option
                                        value="Ghana">
                                    Ghana                                </option>
                                                                <option
                                        value="Gibraltar">
                                    Gibraltar                                </option>
                                                                <option
                                        value="Greece">
                                    Greece                                </option>
                                                                <option
                                        value="Greenland">
                                    Greenland                                </option>
                                                                <option
                                        value="Grenada">
                                    Grenada                                </option>
                                                                <option
                                        value="Guadeloupe">
                                    Guadeloupe                                </option>
                                                                <option
                                        value="Guam">
                                    Guam                                </option>
                                                                <option
                                        value="Guatemala">
                                    Guatemala                                </option>
                                                                <option
                                        value="Guernsey">
                                    Guernsey                                </option>
                                                                <option
                                        value="Guinea">
                                    Guinea                                </option>
                                                                <option
                                        value="Guinea-Bissau">
                                    Guinea-Bissau                                </option>
                                                                <option
                                        value="Guyana">
                                    Guyana                                </option>
                                                                <option
                                        value="Haiti">
                                    Haiti                                </option>
                                                                <option
                                        value="Heard and Mc Donald Islands">
                                    Heard and Mc Donald Islands                                </option>
                                                                <option
                                        value="Honduras">
                                    Honduras                                </option>
                                                                <option
                                        value="Hong Kong">
                                    Hong Kong                                </option>
                                                                <option
                                        value="Hungary">
                                    Hungary                                </option>
                                                                <option
                                        value="Iceland">
                                    Iceland                                </option>
                                                                <option
                                        value="India">
                                    India                                </option>
                                                                <option
                                        value="Indonesia">
                                    Indonesia                                </option>
                                                                <option
                                        value="Iran (Islamic Republic of)">
                                    Iran (Islamic Republic of)                                </option>
                                                                <option
                                        value="Iraq">
                                    Iraq                                </option>
                                                                <option
                                        value="Ireland">
                                    Ireland                                </option>
                                                                <option
                                        value="Isle of Man">
                                    Isle of Man                                </option>
                                                                <option
                                        value="Israel">
                                    Israel                                </option>
                                                                <option
                                        value="Italy">
                                    Italy                                </option>
                                                                <option
                                        value="Ivory Coast">
                                    Ivory Coast                                </option>
                                                                <option
                                        value="Jamaica">
                                    Jamaica                                </option>
                                                                <option
                                        value="Japan">
                                    Japan                                </option>
                                                                <option
                                        value="Jersey">
                                    Jersey                                </option>
                                                                <option
                                        value="Jordan">
                                    Jordan                                </option>
                                                                <option
                                        value="Kazakhstan">
                                    Kazakhstan                                </option>
                                                                <option
                                        value="Kenya">
                                    Kenya                                </option>
                                                                <option
                                        value="Kiribati">
                                    Kiribati                                </option>
                                                                <option
                                        value="Korea, Democratic Peoples Republic of">
                                    Korea, Democratic Peoples Republic of                                </option>
                                                                <option
                                        value="Korea, Republic of">
                                    Korea, Republic of                                </option>
                                                                <option
                                        value="Kosovo">
                                    Kosovo                                </option>
                                                                <option
                                        value="Kuwait">
                                    Kuwait                                </option>
                                                                <option
                                        value="Kyrgyzstan">
                                    Kyrgyzstan                                </option>
                                                                <option
                                        value="Lao Peoples Democratic Republic">
                                    Lao Peoples Democratic Republic                                </option>
                                                                <option
                                        value="Latvia">
                                    Latvia                                </option>
                                                                <option
                                        value="Lebanon">
                                    Lebanon                                </option>
                                                                <option
                                        value="Lesotho">
                                    Lesotho                                </option>
                                                                <option
                                        value="Liberia">
                                    Liberia                                </option>
                                                                <option
                                        value="Libyan Arab Jamahiriya">
                                    Libyan Arab Jamahiriya                                </option>
                                                                <option
                                        value="Liechtenstein">
                                    Liechtenstein                                </option>
                                                                <option
                                        value="Lithuania">
                                    Lithuania                                </option>
                                                                <option
                                        value="Luxembourg">
                                    Luxembourg                                </option>
                                                                <option
                                        value="Macau">
                                    Macau                                </option>
                                                                <option
                                        value="Macedonia">
                                    Macedonia                                </option>
                                                                <option
                                        value="Madagascar">
                                    Madagascar                                </option>
                                                                <option
                                        value="Malawi">
                                    Malawi                                </option>
                                                                <option
                                        value="Malaysia">
                                    Malaysia                                </option>
                                                                <option
                                        value="Maldives">
                                    Maldives                                </option>
                                                                <option
                                        value="Mali">
                                    Mali                                </option>
                                                                <option
                                        value="Malta">
                                    Malta                                </option>
                                                                <option
                                        value="Marshall Islands">
                                    Marshall Islands                                </option>
                                                                <option
                                        value="Martinique">
                                    Martinique                                </option>
                                                                <option
                                        value="Mauritania">
                                    Mauritania                                </option>
                                                                <option
                                        value="Mauritius">
                                    Mauritius                                </option>
                                                                <option
                                        value="Mayotte">
                                    Mayotte                                </option>
                                                                <option
                                        value="Mexico">
                                    Mexico                                </option>
                                                                <option
                                        value="Micronesia, Federated States of">
                                    Micronesia, Federated States of                                </option>
                                                                <option
                                        value="Moldova, Republic of">
                                    Moldova, Republic of                                </option>
                                                                <option
                                        value="Monaco">
                                    Monaco                                </option>
                                                                <option
                                        value="Mongolia">
                                    Mongolia                                </option>
                                                                <option
                                        value="Montenegro">
                                    Montenegro                                </option>
                                                                <option
                                        value="Montserrat">
                                    Montserrat                                </option>
                                                                <option
                                        value="Morocco">
                                    Morocco                                </option>
                                                                <option
                                        value="Mozambique">
                                    Mozambique                                </option>
                                                                <option
                                        value="Myanmar">
                                    Myanmar                                </option>
                                                                <option
                                        value="Namibia">
                                    Namibia                                </option>
                                                                <option
                                        value="Nauru">
                                    Nauru                                </option>
                                                                <option
                                        value="Nepal">
                                    Nepal                                </option>
                                                                <option
                                        value="Netherlands">
                                    Netherlands                                </option>
                                                                <option
                                        value="Netherlands Antilles">
                                    Netherlands Antilles                                </option>
                                                                <option
                                        value="New Caledonia">
                                    New Caledonia                                </option>
                                                                <option
                                        value="New Zealand">
                                    New Zealand                                </option>
                                                                <option
                                        value="Nicaragua">
                                    Nicaragua                                </option>
                                                                <option
                                        value="Niger">
                                    Niger                                </option>
                                                                <option
                                        value="Nigeria">
                                    Nigeria                                </option>
                                                                <option
                                        value="Niue">
                                    Niue                                </option>
                                                                <option
                                        value="Norfolk Island">
                                    Norfolk Island                                </option>
                                                                <option
                                        value="Northern Mariana Islands">
                                    Northern Mariana Islands                                </option>
                                                                <option
                                        value="Norway">
                                    Norway                                </option>
                                                                <option
                                        value="Oman">
                                    Oman                                </option>
                                                                <option
                                        value="Pakistan">
                                    Pakistan                                </option>
                                                                <option
                                        value="Palau">
                                    Palau                                </option>
                                                                <option
                                        value="Palestine">
                                    Palestine                                </option>
                                                                <option
                                        value="Panama">
                                    Panama                                </option>
                                                                <option
                                        value="Papua New Guinea">
                                    Papua New Guinea                                </option>
                                                                <option
                                        value="Paraguay">
                                    Paraguay                                </option>
                                                                <option
                                        value="Peru">
                                    Peru                                </option>
                                                                <option
                                        value="Philippines">
                                    Philippines                                </option>
                                                                <option
                                        value="Pitcairn">
                                    Pitcairn                                </option>
                                                                <option
                                        value="Poland">
                                    Poland                                </option>
                                                                <option
                                        value="Portugal">
                                    Portugal                                </option>
                                                                <option
                                        value="Puerto Rico">
                                    Puerto Rico                                </option>
                                                                <option
                                        value="Qatar">
                                    Qatar                                </option>
                                                                <option
                                        value="Reunion">
                                    Reunion                                </option>
                                                                <option
                                        value="Romania">
                                    Romania                                </option>
                                                                <option
                                        value="Russian Federation">
                                    Russian Federation                                </option>
                                                                <option
                                        value="Rwanda">
                                    Rwanda                                </option>
                                                                <option
                                        value="Saint Kitts and Nevis">
                                    Saint Kitts and Nevis                                </option>
                                                                <option
                                        value="Saint Lucia">
                                    Saint Lucia                                </option>
                                                                <option
                                        value="Saint Vincent and the Grenadines">
                                    Saint Vincent and the Grenadines                                </option>
                                                                <option
                                        value="Samoa">
                                    Samoa                                </option>
                                                                <option
                                        value="San Marino">
                                    San Marino                                </option>
                                                                <option
                                        value="Sao Tome and Principe">
                                    Sao Tome and Principe                                </option>
                                                                <option
                                        value="Saudi Arabia">
                                    Saudi Arabia                                </option>
                                                                <option
                                        value="Senegal">
                                    Senegal                                </option>
                                                                <option
                                        value="Serbia">
                                    Serbia                                </option>
                                                                <option
                                        value="Seychelles">
                                    Seychelles                                </option>
                                                                <option
                                        value="Sierra Leone">
                                    Sierra Leone                                </option>
                                                                <option
                                        value="Singapore">
                                    Singapore                                </option>
                                                                <option
                                        value="Slovakia">
                                    Slovakia                                </option>
                                                                <option
                                        value="Slovenia">
                                    Slovenia                                </option>
                                                                <option
                                        value="Solomon Islands">
                                    Solomon Islands                                </option>
                                                                <option
                                        value="Somalia">
                                    Somalia                                </option>
                                                                <option
                                        value="South Africa">
                                    South Africa                                </option>
                                                                <option
                                        value="South Georgia South Sandwich Islands">
                                    South Georgia South Sandwich Islands                                </option>
                                                                <option
                                        value="Spain">
                                    Spain                                </option>
                                                                <option
                                        value="Sri Lanka">
                                    Sri Lanka                                </option>
                                                                <option
                                        value="St. Helena">
                                    St. Helena                                </option>
                                                                <option
                                        value="St. Pierre and Miquelon">
                                    St. Pierre and Miquelon                                </option>
                                                                <option
                                        value="Sudan">
                                    Sudan                                </option>
                                                                <option
                                        value="Suriname">
                                    Suriname                                </option>
                                                                <option
                                        value="Svalbard and Jan Mayen Islands">
                                    Svalbard and Jan Mayen Islands                                </option>
                                                                <option
                                        value="Swaziland">
                                    Swaziland                                </option>
                                                                <option
                                        value="Sweden">
                                    Sweden                                </option>
                                                                <option
                                        value="Switzerland">
                                    Switzerland                                </option>
                                                                <option
                                        value="Syrian Arab Republic">
                                    Syrian Arab Republic                                </option>
                                                                <option
                                        value="Taiwan">
                                    Taiwan                                </option>
                                                                <option
                                        value="Tajikistan">
                                    Tajikistan                                </option>
                                                                <option
                                        value="Tanzania, United Republic of">
                                    Tanzania, United Republic of                                </option>
                                                                <option
                                        value="Thailand">
                                    Thailand                                </option>
                                                                <option
                                        value="Togo">
                                    Togo                                </option>
                                                                <option
                                        value="Tokelau">
                                    Tokelau                                </option>
                                                                <option
                                        value="Tonga">
                                    Tonga                                </option>
                                                                <option
                                        value="Trinidad and Tobago">
                                    Trinidad and Tobago                                </option>
                                                                <option
                                        value="Tunisia">
                                    Tunisia                                </option>
                                                                <option
                                        value="Turkey">
                                    Turkey                                </option>
                                                                <option
                                        value="Turkmenistan">
                                    Turkmenistan                                </option>
                                                                <option
                                        value="Turks and Caicos Islands">
                                    Turks and Caicos Islands                                </option>
                                                                <option
                                        value="Tuvalu">
                                    Tuvalu                                </option>
                                                                <option
                                        value="Uganda">
                                    Uganda                                </option>
                                                                <option
                                        value="Ukraine">
                                    Ukraine                                </option>
                                                                <option
                                        value="United Arab Emirates">
                                    United Arab Emirates                                </option>
                                                                <option
                                        value="United Kingdom">
                                    United Kingdom                                </option>
                                                                <option
                                        value="United States">
                                    United States                                </option>
                                                                <option
                                        value="United States minor outlying islands">
                                    United States minor outlying islands                                </option>
                                                                <option
                                        value="Uruguay">
                                    Uruguay                                </option>
                                                                <option
                                        value="Uzbekistan">
                                    Uzbekistan                                </option>
                                                                <option
                                        value="Vanuatu">
                                    Vanuatu                                </option>
                                                                <option
                                        value="Vatican City State">
                                    Vatican City State                                </option>
                                                                <option
                                        value="Venezuela">
                                    Venezuela                                </option>
                                                                <option
                                        value="Vietnam">
                                    Vietnam                                </option>
                                                                <option
                                        value="Virgin Islands (British)">
                                    Virgin Islands (British)                                </option>
                                                                <option
                                        value="Virgin Islands (U.S.)">
                                    Virgin Islands (U.S.)                                </option>
                                                                <option
                                        value="Wallis and Futuna Islands">
                                    Wallis and Futuna Islands                                </option>
                                                                <option
                                        value="Western Sahara">
                                    Western Sahara                                </option>
                                                                <option
                                        value="Yemen">
                                    Yemen                                </option>
                                                                <option
                                        value="Zaire">
                                    Zaire                                </option>
                                                                <option
                                        value="Zambia">
                                    Zambia                                </option>
                                                                <option
                                        value="Zimbabwe">
                                    Zimbabwe                                </option>
                                                        </select>

                    </div>
                    <div class="form-group">
                        <input type="password" name="password" class="form-control after-email" placeholder="Password"
                               required="" id="password" value="">
                    </div>
                    <div class="form-group">
                        <input type="password" name="confirmpassword" class="form-control after-email"
                               placeholder="Confirm Password" required="" id="confirmpassword">
                        <span style="color:red;">Make sure you use a strong password and write it down somewhere
                        safe.</span>
                    </div>


                    <div class="form-group">
                        <input id="uiTerms" type="checkbox" class="after-email" required/> I agree to the <a
                                href="publicnotice.php" target="_blank">Terms of
                            Membership</a><br/>
                        Please review the Terms of Membership above and indicate your agreement by checking the box
                        above.
                    </div>

                    <!--<button type="button" class="btn btn-primary btn-block " onclick="redirect();">submit</button>-->
                    <input type="hidden" id="sponsor" name="sponsor" class="sponsor"
                           value="admin">
                    <input type="hidden" id="email" name="email" value=""/>
                    <button type="submit" name="register" id="regBTN" class="btn btn-primary submit-button after-email"
                            onclick="return myValidation();">SUBMIT
                    </button>

                    <br/><br/>
                    <!--<input type="submit" id="register" name="register" class="btn btn-primary btn-block  register" placeholder="Submit">-->
            </div>
        </div>

    </div>
</div>

<!-- End Page 2 Form -->


<div class="row">
    <div class="col text-center">
            <span class="sponsor-text text-warning">
                YOUR SPONSOR IS <span id='ds_sponsorname'>Admin</span>
            </span>
    </div>
</div>
<div class="row">
    <div class="col text-center">
        <b>Our Current Membership Count: 3,885,259</b><br /><br />    </div>
</div>
<div class="row">
    <div class="col text-center">
        <b>Kringle Cash Visitors</b>
        <br/>
        <script type="text/javascript"
                src="//rf.revolvermaps.com/0/0/2.js?i=54h3q22imgc&amp;m=8&amp;s=130&amp;c=ff0000&amp;t=1"
                async="async">
        </script>
    </div>
</div>
<div class="row">
    <div class="col">
        &nbsp;
        <br/>
        <br/>
    </div>
</div>

<!--
    <div class="row">
        <div class="col text-center">
            <button type="button" name="register" id="step1Reg" class="btn btn-dark submit-button"
                    onclick="proceedToStep2()">Continue To Step 2
            </button>
            <p>
                Do not press the back button on your browser if registering multiple members, always use your
                referral
                link for best results.
            </p>
        </div>
    </div>
    -->
</div>
<style>
    .wsc_support-chat label {
        color: #000;
    }

    .wsc_support-wrap {
        position: fixed !important;
    }
</style>
<link href="/wsc-plugin/plugin/chatpublic/css/main.css" rel="stylesheet" />
<div id="wsc_support_chat" class="wsc_support-wrap">
    
</div>
<script type="module" src="/wsc-plugin/plugin/chatpublic/js/app.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/react/16.13.1/umd/react.production.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/react-dom/16.13.1/umd/react-dom.production.min.js"></script>
</div>


<!-- We're changing this to a form post because people are lingering on this page and sessions are timing out -->
<div id="formdiv" style="display:none">
    <form id='regform' method="post" action="registration_step2.php">
        <input type="hidden" name="key" id="key"
               value="949648c205c0abc77f9596">
        <input type="hidden" name="suid" id="suid"
               value="1">
        <input type="hidden" name="suname" id="suname"
               value="admin">
        <input type="hidden" name="reftype" id="reftype"
               value="0">
        <input type="hidden" name="f_email" id="f_email" value="">
        <input type="hidden" name="ts" id="ts"
               value="1710936460">
                <input type="hidden" name="session" id="session"
               value="%7B%22wscid%22%3Anull%2C%22token%22%3A%222bce32ed409f5ebcee2a7b417ad9beed%22%2C%22ip%22%3A%22197.210.54.73%22%2C%22user_agent%22%3A%22Mozilla%5C%2F4.5+%28compatible%3B+HTTrack+3.0x%3B+Windows+98%29%22%2C%22sponsor_uid%22%3A1%2C%22sponsor_name%22%3A%22Admin%22%2C%22sponsor_email%22%3A%22admin%40thebillioncoin.info%22%2C%22sponsor_uname%22%3A%22admin%22%7D">
    </form>
</div>


<!-- Please Wait Modal -->
<div id="pleaseWaitModal" class="modal fade pleaseWaitModal modal-sm" style="margin:auto;color:black"
     data-backdrop="static" data-keyboard="false" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Please Wait</h4>
            </div>
            <div class="modal-body">
                <p>We are processing your request</p>
            </div>
            <div class="modal-footer">
            </div>
        </div>

    </div>
</div>

<!-- Phone Number Help Modal -->

<div class="modal fade" tabindex="-1" role="dialog" id="TPModal" style="color:#000;">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header-primary">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <h4 class="modal-title">Phone Formatting Requirements</h4>
            </div>
            <div class="modal-body">
                <p>
                    The Phone field should only contain your <b>Personal Mobile Phone</b> number. No
                    other phone number should be entered in this field.<br/><br/>
                    <b>The only valid characters for this field are:</b> <br/>
                    Numeric Characters (0-9)<br/>
                    Plus Symbol (+)<br/>
                    Hyphen (-)<br/>
                    Open and Closing Parentheses (())<br/><br/>

                    <b>Some valid format examples are:</b><br/>
                    +22 607 123 4567<br/>
                    (0607) 123 4567<br/>
                    1-555-555-5555<br/>
                    (555) 999-0000<br/>
                </p>
                <p>
                    If the Phone field does not match these requirements, it will not be saved.
                </p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>

            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<div id="footer" class="nav-background-footer">

</div>
</body>
</html>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
<script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.20/js/dataTables.bootstrap4.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>



<script src="https://www.google.com/recaptcha/api.js?render=6Lc-WwYkAAAAAPQ09GeF97hcv4c1zM706MrEUwyi"></script>

<script>

    $("#register").submit(function (e) {
        e.preventDefault();
        grecaptcha.ready(function () {
            grecaptcha.execute('6Lc-WwYkAAAAAPQ09GeF97hcv4c1zM706MrEUwyi', {action: 'register'}).then(function (token) {
                console.log(token);
                $('#register').prepend('<input type="hidden" name="rktoken" id="rktoken" value="' + token + '">');
                $('#register').prepend('<input type="hidden" name="rkaction" id="rkaction" value="register">');
                submitForm();
            });
        });
    });

    function submitForm() {
        var regBtn = document.getElementById('regBTN');

        regBtn.disabled = true;
        regBtn.innerHTML = 'Processing...';

        var username = $("#username").val();
        var email = $("#uiRegistrationEmail").val();
        var ip = '197.210.54.73';

        if ($("#fullname").val() == '' ||
            $("#password").val() == '' ||
            $("#confirmpassword").val() == '' ||
            email == ''
        ) {
            alert('Please fill in email fullname and password information.');
            return (false);
        }

        var FBurl = /^[0-9-()+\s]+$/i;
        var fb = $("#u_phone").val();
        if (!fb.match(FBurl)) {
            $('#TPModal').modal('show')
            regBtn.disabled = false;
            regBtn.innerHTML = 'SUBMIT';
            return false;
        }

        $('#pleaseWaitModal').modal("show");

        $.ajax({
            type: 'POST',
            url: 'code/ajax/_registration.php',
            //This was added by jtm on 10/11/2020 to try and catch timeouts. error will fire when time out
            //occurs
            timeout: 15000, // sets timeout to 15 seconds
            error: function () {
                processFail('System Error : System has timed out', true);
            },
            //End of JTM 10/11/2020 mod

            /*dataType: 'json',*/
            data: {
                action: "completeregistration",
                username: username,
                email: email,
                formversion: 'registration_form',
                phone: $('#u_phone').val(),

                sponsoruid: '1',
                sponsoremail: 'admin@thebillioncoin.info',
                sponsorname: 'Admin',

                name: $("#fullname").val(),
                country: $("#country").val(),
                password: $("#password").val(),
                confirmpassword: $("#confirmpassword").val(),
                walletid: $("#walletid").val(),
                sponsor: $("#sponsor").val(),

                rkaction: $("#rkaction").val(),
                rktoken: $("#rktoken").val(),
                rkaddress: $("#rkaddress").val()
            },

            /*data: $(this).serialize(),*/
            success: function (data) {
                try {
                    var jdata = JSON.parse(data);
                } catch (e) {
                    processFail('System Error : Response has invalid format', true);
                    if (e instanceof SyntaxError) {
                        extrapolateError(e, true);
                    } else {
                        extrapolateError(e, false);
                    }
                    return;
                }
                if (jdata.resultCode) {
                    regBtn.innerHTML = 'Submitted..';
                    if (jdata.payment_type == "free") {
                        if (jdata.referral_type == 1) {
                            window.location.href =
                                'https://kringle.cash/portal/merchant_registration.php';
                        } else {
                            window.location.href = 'https://kringle.cash/portal/';
                        }
                    } else {
                        window.location.href = 'registration_complete.php';
                    }

                    return false;
                } else {
                    if (jdata.message && jdata.message != '') {
                        if (jdata.reloadpage == 'Y') {
                            alert(jdata.message);
                            window.location.href =
                                "https://kringle.cash/registration_form.php";
                        }
                        processFail(jdata.message);
                    } else {
                        processFail(
                            'A System Error has occurred. Please try again later. If the problem persists, contact support.' +
                            data, true);
                    }

                    regBtn.innerHTML = 'Submit';
                    regBtn.disabled = false;
                    return false;
                }
            },
            complete: function (xhr, status) {
                $('#pleaseWaitModal').modal("hide");
            }
        });
    }

</script>

<script type="text/javascript">
    $("#uiEmail").focus();
    $(".after-email:input").prop('disabled', true);
    $(".after-email:input").prop('readonly', true);

    //$("#fullname").attr('readonly', true);

    $("#tplink").click(function () {
        $('#TPModal').modal('show')
    });

    function checkForExistingReg() {
        var email = $("#uiRegistrationEmail").val();
        $("#validation_feedback").val('');
        $('#pleaseWaitModal').modal("show");

        $.ajax({
            type: 'POST',
            url: 'code/ajax/_registration.php',
            data: {
                email: email,
                action: "checkforexistingv1"
            },

            success: function (data) {
                $('#pleaseWaitModal').modal("hide");
                try {
                    var jdata = JSON.parse(data);
                } catch (e) {
                    processFail('System Error : Response has invalid format:' + data, true);
                    if (e instanceof SyntaxError) {
                        extrapolateError(e, true);
                    } else {
                        extrapolateError(e, false);
                    }
                    return;
                }
                if (jdata.valid) {
                    $("#email").val(email);
                    $(".after-email:input").prop('disabled', false);
                    $(".after-email:input").prop('readonly', false);
                    $("#uiRegistrationEmail").attr("readonly", "readonly");
                    $("#checkEmailButton").hide();
                } else { //jdata is not true
                    if (jdata.message && jdata.message != '') {
                        $("#uiRegistrationEmail").focus();
                        processFail(jdata.message);
                    } else {
                        processFail(
                            'A System Error has occurred. Please try again later. If the problem persists, contact support.' +
                            data, true);
                    }
                }

            },
            error: function (xhr, ajaxOptions, thrownError) {
                processFail("A System Issue has occurred\"\r\n" + thrownError + "\r\n" + xhr.statusText +
                    "\r\n" + xhr.responseText, true);
            },
            complete(xhr, status) {
                $('#pleaseWaitModal').modal("hide");
            }
        });
    }

    function proceedToStep2() {
        if ($("#uiEmail").val() != '') {
            $("#regform").submit();
        } else {
            alert("Email Required");
        }
    }
</script>

<!-- These are new scripts merged in from page 2 -->
<script type="text/javascript">
    function myValidation() {
        if (checkUsername()) {
            return Validate();
        } else {
            return false;
        }
    }

    $("#u_phone").blur(function () {
        //validate
        var FBurl = /^[0-9-()+\s]+$/i;
        var fb = $(this).val();
        if (!fb.match(FBurl)) {
            $('#TPModal').modal('show')
        }
    });

    function Validate() {
        var password = document.getElementById("password").value;
        var confirmPassword = document.getElementById("confirmpassword").value;
        if (password == '' || confirmPassword == '') {
            alert("Password or Confirm Password can not be empty");
            return false;
        } else if (password != confirmPassword) {
            alert("Passwords do not match.");
            return false;
        } else {
            return true;
        }
    }

    function checkUsername() {
        var username = document.getElementById('username');
        var filter = /^[a-z0-9_]+$/i;

        if (!filter.test(username.value)) {
            alert('Usernames can only contain alphanumeric characters including underscore (_)');
            username.focus;
            return false;
        }
        return true;
    }
</script>
<script>

</script>

<script>
    //Use this to get what the error is with JSON Parse fail
    function extrapolateError(error, explicit) {
        console.log(`[${explicit ? 'EXPLICIT' : 'INEXPLICIT'}] ${error.name}: ${error.message}`);
    }

    function processFail(message, logError) {
        $('#pleaseWaitModal').modal("hide");

        alert(message);

        var email = $("#uiRegistrationEmail").val();

        $("#feedback").html("<div class='alert alert-danger' role='alert' >" + message + "</div>");
        message = email + ' : registration :' + message;

        logError = typeof logError !== 'undefined' ? logError : false;
        if (logError) {
            var xhr = new XMLHttpRequest();
            xhr.open('POST', '/portal/logweberror.php', true);
            xhr.send('/home/baneofexistence/public_html/registration_form.php: javascript error: ' + message);
        }
    }
</script>

<script>
    function idleLogout() {
        var t;
        window.onload = resetTimer;
        window.onmousemove = resetTimer;
        window.onmousedown = resetTimer; // catches touchscreen presses as well
        window.ontouchstart = resetTimer; // catches touchscreen swipes as well
        window.onclick = resetTimer; // catches touchpad clicks as well
        window.onkeydown = resetTimer;
        window.addEventListener('scroll', resetTimer, true); // improved; see comments

        function resetTimer() {
            clearTimeout(t);
            t = setTimeout(pageTimedOutAction, 10 * 60 * 1000); // time is in milliseconds (10 minutes)
        }
    }

    idleLogout();

    function pageTimedOutAction() {
        alert('Your Session Has Expired');
        window.location.href =
            "https://kringle.cash/registration_form.php";
    }
</script>
