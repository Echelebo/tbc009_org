<html>
<title>Kringle.Cash</title>
<head>
    <meta http-equiv="Content-Type" content="application/xhtml+xml; charset=UTF-8" />
    <link rel="shortcut icon" href="favicon.ico" />
    <!-- mobile settings -->
    <meta name="viewport" content="width=device-width, maximum-scale=1, initial-scale=1, user-scalable=0" />	
    <meta property="og:image" content="https://kringle.cash/images/linkimage2c.jpg" />
	<meta property="og:description" content="Become a Millionaire automatically FREE of CHARGE.   This Cash Giveaway expires soon!  Click NOW and collect your GIFT!" />
	<meta property="og:url" content="https://kringle.cash/" />
    <meta property="og:title" content="Kringle.Cash" />
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css"/>
      
      <script type="text/javascript" src="js/jquery.js"></script> 
	  <script type="text/javascript" src="js/bootstrap.js"></script>
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
	<style>

	</style>
    <link href="css/style.css" media="screen" rel="stylesheet" type="text/css">
    <link href="css/ownstyle.css" media="screen" rel="stylesheet" type="text/css">
    <link href="css/mystyle.css" media="screen" rel="stylesheet" type="text/css">
    <link href="css/info1.css" media="screen" rel="stylesheet" type="text/css">
    <script type="text/javascript">
        function googleTranslateElementInit() {
            new google.translate.TranslateElement({pageLanguage: 'en', layout: google.translate.TranslateElement.InlineLayout.SIMPLE}, 'google_translate_element');
        }
    </script>
    <script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
    <!--<div id="google_translate_element"></div>-->
    <style>
        .goog-te-menu-value img {
           display: none;
        }
        .goog-te-gadget-simple img {
        background-image: url('images/KringleCoin.gif')!important;
        }
    </style>
</head>
<body>
<header>
    <div class="header-top" id="menuUser">
        <div class="container">
            <div class="row">
                <div class="col">
                <!--<div class="col-sm-2 col-xs-12" style="width: 13.666667%;    margin-top: -3px;" id="google_translate_element">
                </div>-->
                <div class="float-right" style="display: inline-block;margin-right: 16px;height: 36px;float: right;">
                    <div id="google_translate_element"></div>
                </div>
                    </div>
            </div>
        </div>
    </div>
</header>


<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://fonts.googleapis.com/css2?family=Fugaz+One&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Roboto+Condensed&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/grid-gallery.min.css">
    <link rel="stylesheet" href="css/style.css?20210128">
    <title>Kluv Coin</title>
  </head>

  <body>
    <div class="goodwill-box d-flex align-center justify-space-around">
      <div class="box">
	     <h2>REPORT ON THE TBC/KLUV GOODWILL PROJECT IN UGANDA</h2>
        <img src="https://www.kluvcoin.io/img/henry.jpg" />
        <p>
          Henry Ssembajjwe Kabwama, a repeat contest winner, has accepted the calling 
          to become the Goodwill Ambassador for Uganda. We are so proud of him and his 
          achievements within the TBC Community. He is one of two Ambassadors called 
          within the 15th week of the existence of KLUV and with less than 1,500 
          Holders of the coin. That means $70,000.00 has already been raised through 
          KLUV. $10,000.00 of that will be spent on food to feed the poor in Uganda on 
          June 11th, 2022.
          <br/><br/>
          $10,000 of BNB was sent to Ambassador Henry Ssembajjwe Kabwama of Uganda on 
          June 6th, 2022 to purchase food: 
          <a href="https://bscscan.com/tx/0xb9ec048446f2c21a86a0dd5026bb7ebad25a368cc5b3d7b505590e1cd35e2df0" target="_blank">
            https://bscscan.com/tx/0xb9ec048446f2c21a86a0dd5026bb7ebad25a368cc5b3d7b505590e1cd35e2df0
          </a>
        </p>
        <br/><br/>
	      <h2>THE TBC /KLUV GOODWILL REPORT FOR UGANDA THAT TOOK PLACE ON 11th JUNE 2022 BY MR HENRY SSEMBAJJWE KABWAMA.</h2>
        <p>
          Our Goodwill event in Uganda took place on the 11th of June 2022, was the first ever in the country. It was a 
          fantastic experience for the for the people in Makindye division Kampala city Uganda. We had the blind, dumb, 
          deaf crippled, people with special disabilities, struggling parents, orphans, needy mothers, elderly to mention 
          but a few. <br/><br/>

          We had a total of 800 persons to receive food from BNB token worth 10000 dollars. We gave each individual a box 
          containing 2kg of rice, a 1 bar of soap,1 packet of salt,1kg of beans ,1kg of sugar valued 12 dollars to take 
          them for some few weeks. This meeting was preceded by getting government permission, police permission, and 
          facility permission. <br/><br/>

          The receivers were so happy and expressed words of gratitude and blessings to  Kringle society and kismet love(Kluv). 
          My team and I also want to thank the TBC Admin who made all these possible and we pray that may God continue to 
          bless him with wisdom and strength to continue this great mission  of TBC,that is ending poverty in the world. <br/><br/>

          KRINGLE SOCIETY CARES FOR THE NEEDY.<br/>
          KISMET LOVE (KLUV) LOVES HUMANITY<br/>
          Thanks
          <br/><br/>
        </p>
        <p><b>Receipts:</b></p>
		    <div class="gg-container" style="padding: 0 30px;">
          <div class="gg-box gallery goodwill-gallery">
            <img src="https://www.kluvcoin.io/img/uganda/receipt/1.jpg" />
            <img src="https://www.kluvcoin.io/img/uganda/receipt/2.jpg" />
            <img src="https://www.kluvcoin.io/img/uganda/receipt/3.jpg" />
            <img src="https://www.kluvcoin.io/img/uganda/receipt/4.jpg" />
            <img src="https://www.kluvcoin.io/img/uganda/receipt/5.jpg" />
            <img src="https://www.kluvcoin.io/img/uganda/receipt/6.jpg" />
            <img src="https://www.kluvcoin.io/img/uganda/receipt/7.jpg" />
          </div>
        </div>

        <p><b>Event Photos in UGANDA</b></p>
        <div class="gg-container" style="padding: 0 30px;">
          <div class="gg-box gallery2 goodwill-gallery">
            <img src="https://www.kluvcoin.io/img/uganda/event/1.jpg" />
            <img src="https://www.kluvcoin.io/img/uganda/event/2.jpg" />
            <img src="https://www.kluvcoin.io/img/uganda/event/3.jpg" />
            <img src="https://www.kluvcoin.io/img/uganda/event/4.jpg" />
            <img src="https://www.kluvcoin.io/img/uganda/event/5.jpg" />
            <img src="https://www.kluvcoin.io/img/uganda/event/6.jpg" />
            <img src="https://www.kluvcoin.io/img/uganda/event/7.jpg" />
            <img src="https://www.kluvcoin.io/img/uganda/event/8.jpg" />
            <img src="https://www.kluvcoin.io/img/uganda/event/9.jpg" />
            <img src="https://www.kluvcoin.io/img/uganda/event/10.jpg" />
            <img src="https://www.kluvcoin.io/img/uganda/event/11.jpg" />
            <img src="https://www.kluvcoin.io/img/uganda/event/12.jpg" />
            <img src="https://www.kluvcoin.io/img/uganda/event/13.jpg" />
            <img src="https://www.kluvcoin.io/img/uganda/event/14.jpg" />
            <img src="https://www.kluvcoin.io/img/uganda/event/15.jpg" />
            <img src="https://www.kluvcoin.io/img/uganda/event/16.jpg" />
            <img src="https://www.kluvcoin.io/img/uganda/event/17.jpg" />
            <img src="https://www.kluvcoin.io/img/uganda/event/18.jpg" />
            <img src="https://www.kluvcoin.io/img/uganda/event/19.jpg" />
            <img src="https://www.kluvcoin.io/img/uganda/event/20.jpg" />
            <img src="https://www.kluvcoin.io/img/uganda/event/21.jpg" />
            <img src="https://www.kluvcoin.io/img/uganda/event/22.jpg" />
            <img src="https://www.kluvcoin.io/img/uganda/event/23.jpg" />
            <img src="https://www.kluvcoin.io/img/uganda/event/24.jpg" />
            <img src="https://www.kluvcoin.io/img/uganda/event/25.jpg" />
            <img src="https://www.kluvcoin.io/img/uganda/event/26.jpg" />
            <img src="https://www.kluvcoin.io/img/uganda/event/27.jpg" />
            <img src="https://www.kluvcoin.io/img/uganda/event/28.jpg" />
            <img src="https://www.kluvcoin.io/img/uganda/event/29.jpg" />
            <img src="https://www.kluvcoin.io/img/uganda/event/30.jpg" />
            <img src="https://www.kluvcoin.io/img/uganda/event/31.jpg" />
            <img src="https://www.kluvcoin.io/img/uganda/event/32.jpg" />
            <img src="https://www.kluvcoin.io/img/uganda/event/33.jpg" />
            <img src="https://www.kluvcoin.io/img/uganda/event/34.jpg" />
            <img src="https://www.kluvcoin.io/img/uganda/event/35.jpg" />
          </div>
          <br/>
          <hr/>
          <p>Press and Coverage</p>
          <img src="https://www.kluvcoin.io/img/uganda/press/1.jpg" />
          <img src="https://www.kluvcoin.io/img/uganda/press/2.jpg" />
          <br/><br/>
          <iframe width="560" height="315" src="https://www.youtube.com/embed/awG-25gLTKo" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
          <iframe width="560" height="315" src="https://www.youtube.com/embed/bTXWpLObP3M" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
          <iframe width="560" height="315" src="https://www.youtube.com/embed/p9eFoRfiNs0" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        </div>
      </div>
    </div>

    <script src="js/grid-gallery.min.js"></script>
    <script>
      gridGallery({
        selector: ".gallery",
        darkMode: true,
        layout: "square",
        gapLength: 10,
        rowHeight: 300,
        columnWidth: 300
      });
      gridGallery({
        selector: ".gallery2",
        darkMode: true,
        layout: "square",
        gapLength: 10,
        rowHeight: 300,
        columnWidth: 300
      });

      var openMenu = false
      var menu = document.querySelector('.menu');
      var mobileNenu = document.querySelector('.mobile-menu');
      menu.onclick = function (e) {
        openMenu = !openMenu
        if (openMenu) {
          mobileNenu.classList.add("show");
        } else {
          mobileNenu.classList.remove("show");
        }
      }

      var submenu = document.querySelector('.sub-menu');
      var submenyDelay = ''
      submenu.addEventListener("mouseenter", function () {
        if (submenyDelay) clearTimeout(submenyDelay)
        submenu.classList.add("hover");
      })
      submenu.addEventListener("mouseleave", function () {
        if (submenyDelay) clearTimeout(submenyDelay)

        submenyDelay = setTimeout(function () {
          submenu.classList.remove("hover");
        }, 1000)
      })
      var submenuDiv = document.querySelector('.sub-menu div');
      submenu.addEventListener("mouseenter", function () {
        if (submenyDelay) clearTimeout(submenyDelay)
        submenu.classList.add("hover");
      })
      submenu.addEventListener("mouseleave", function () {
        if (submenyDelay) clearTimeout(submenyDelay)
        submenyDelay = setTimeout(function () {
          submenu.classList.remove("hover");
        }, 1000)
      })
    </script>
  </body>
</html>