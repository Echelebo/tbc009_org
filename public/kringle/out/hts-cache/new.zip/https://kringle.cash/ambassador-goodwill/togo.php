<html>
<title>Kringle.Cash</title>
<head>
    <meta http-equiv="Content-Type" content="application/xhtml+xml; charset=UTF-8" />
    <link rel="shortcut icon" href="favicon.ico" />
    <!-- mobile settings -->
    <meta name="viewport" content="width=device-width, maximum-scale=1, initial-scale=1, user-scalable=0" />	
    <meta property="og:image" content="https://kringle.cash/images/linkimage2c.jpg" />
	<meta property="og:description" content="Become a Millionaire automatically FREE of CHARGE.   This Cash Giveaway expires soon!  Click NOW and collect your GIFT!" />
	<meta property="og:url" content="https://kringle.cash/" />
    <meta property="og:title" content="Kringle.Cash" />
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css"/>
      
      <script type="text/javascript" src="js/jquery.js"></script> 
	  <script type="text/javascript" src="js/bootstrap.js"></script>
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
	<style>

	</style>
    <link href="css/style.css" media="screen" rel="stylesheet" type="text/css">
    <link href="css/ownstyle.css" media="screen" rel="stylesheet" type="text/css">
    <link href="css/mystyle.css" media="screen" rel="stylesheet" type="text/css">
    <link href="css/info1.css" media="screen" rel="stylesheet" type="text/css">
    <script type="text/javascript">
        function googleTranslateElementInit() {
            new google.translate.TranslateElement({pageLanguage: 'en', layout: google.translate.TranslateElement.InlineLayout.SIMPLE}, 'google_translate_element');
        }
    </script>
    <script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
    <!--<div id="google_translate_element"></div>-->
    <style>
        .goog-te-menu-value img {
           display: none;
        }
        .goog-te-gadget-simple img {
        background-image: url('images/KringleCoin.gif')!important;
        }
    </style>
</head>
<body>
<header>
    <div class="header-top" id="menuUser">
        <div class="container">
            <div class="row">
                <div class="col">
                <!--<div class="col-sm-2 col-xs-12" style="width: 13.666667%;    margin-top: -3px;" id="google_translate_element">
                </div>-->
                <div class="float-right" style="display: inline-block;margin-right: 16px;height: 36px;float: right;">
                    <div id="google_translate_element"></div>
                </div>
                    </div>
            </div>
        </div>
    </div>
</header>


<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://fonts.googleapis.com/css2?family=Fugaz+One&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Roboto+Condensed&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/grid-gallery.min.css">
    <link rel="stylesheet" href="css/style.css?20210128">
  </head>

  <body>
    <div class="goodwill-box d-flex align-center justify-space-around">
      <div class="box">
        <h2>
          Sodzedo Koffi, a proven Leader and TBC Contest Winner has accepted the call to become 
          the Goodwill Ambassador for Togo.
        </h2>
        <br/>
        <img src="https://www.kluvcoin.io/img/sodzedo.jpg" />
        <p>
          We are so proud of him and his achievements within the TBC Community. He is the 8th 
          new Ambassador called and we only have 2,000 Holders of the KLUV coin. That means 
          $80,000.00 has already been raised through KLUV.  $10,000.00 of that will be 
          spent on food to feed the poor in Togo on July 23rd, 2022.
        </p>
        <br/><br/>
        <hr/>
        <p><b>Receipts:</b></p>
		    <div class="gg-container" style="padding: 0 30px;">
          <div class="gg-box gallery goodwill-gallery">
            <img src="https://www.kluvcoin.io/img/togo/receipt/1.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/receipt/2.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/receipt/3.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/receipt/4.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/receipt/5.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/receipt/6.jpg" />
          </div>
        </div>

        <br/><br/>
        <p><b>Press Summary for the Goodwill event:</b></p>
        <a style="word-break: break-all;text-align: left!important;"
          href="https://l.facebook.com/l.php?u=https%3A%2F%2Ftogo24.net%2F2022%2F07%2F27%2Fkloto-lassociation-osafo-fait-don-de-vivres-aux-personnes-vulnerables-de-la-prefecture%2F%3Ffbclid%3DIwAR3qL5IzGxL7zFAdmi0DKW0Tl7ygh2KRyoyY_W6sfadQF0SomSydxcV4NFw&h=AT3hKlMpeN6l2TFOVkOdJLw5RncD3wyt_Y8Db1qnH94xrgEQEWo6w2IsqNm42DGJeiCDqFrT7KVbkZ89lcezEEiYy7_L1L0GY6iQ9ZGLUCUV2YtXx43a_LfGRJSOdLEz6k4krA" target="_blank">
          https://l.facebook.com/l.php?u=https%3A%2F%2Ftogo24.net%2F2022%2F07%2F27%2Fkloto-lassociation-osafo-fait-don-de-vivres-aux-personnes-vulnerables-de-la-prefecture%2F%3Ffbclid%3DIwAR3qL5IzGxL7zFAdmi0DKW0Tl7ygh2KRyoyY_W6sfadQF0SomSydxcV4NFw&h=AT3hKlMpeN6l2TFOVkOdJLw5RncD3wyt_Y8Db1qnH94xrgEQEWo6w2IsqNm42DGJeiCDqFrT7KVbkZ89lcezEEiYy7_L1L0GY6iQ9ZGLUCUV2YtXx43a_LfGRJSOdLEz6k4krA
        </a>

        <br/><br/>
        <hr/>
        <p><b>Authorization letters:</b></p>
		    <div class="gg-container" style="padding: 0 30px;">
          <div class="gg-box gallery1 goodwill-gallery">
            <img src="https://www.kluvcoin.io/img/togo/authorization/1.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/authorization/2.png" />
          </div>
        </div>

        <br/><br/>
        <hr/>
        <p><b>KLUV / TBC Team:</b></p>
		    <div class="gg-container" style="padding: 0 30px;">
          <div class="gg-box gallery goodwill-gallery">
            <img src="https://www.kluvcoin.io/img/togo/tbc-team/1.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/tbc-team/2.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/tbc-team/3.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/tbc-team/4.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/tbc-team/5.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/tbc-team/6.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/tbc-team/7.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/tbc-team/8.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/tbc-team/9.jpg" />
          </div>
        </div>
        
        <br/><br/>
        <hr/>
        <p><b>Event Preparation:</b></p>
        <div class="gg-container" style="padding: 0 30px;">
          <div class="gg-box gallery2 goodwill-gallery">
            <img src="https://www.kluvcoin.io/img/togo/event/1.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/2.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/3.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/4.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/5.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/6.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/7.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/8.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/9.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/10.jpg" />
          </div>
        </div>

        <br /><br/>
        <p>July 20,2022 Event Photos. Blessed more than 50 families with food and care package.</p>
        <div class="gg-container" style="padding: 0 30px;">
          <div class="gg-box gallery2 goodwill-gallery">
            <img src="https://www.kluvcoin.io/img/togo/event/11.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/12.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/13.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/14.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/15.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/16.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/17.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/18.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/19.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/20.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/21.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/22.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/23.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/24.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/25.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/26.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/27.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/28.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/29.jpg" />
          </div>
        </div>

        <br /><br/>
        <p>July 21,2022 Event Photos. Blessed over 30 families with food and care package.</p>
        <div class="gg-container" style="padding: 0 30px;">
          <div class="gg-box gallery2 goodwill-gallery">
            <img src="https://www.kluvcoin.io/img/togo/event/30.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/31.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/32.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/33.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/34.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/35.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/36.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/37.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/38.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/39.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/40.jpg" />
            <!-- <img src="https://www.kluvcoin.io/img/togo/event/41.jpg" /> -->
            <img src="https://www.kluvcoin.io/img/togo/event/42.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/43.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/44.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/45.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/46.jpg" />
          </div>
        </div>

        <br /><br/>
        <p>July 22,2022 Event Photos. Blessed over 180 families with food and care package.</p>
        <div class="gg-container" style="padding: 0 30px;">
          <div class="gg-box gallery2 goodwill-gallery">
            <img src="https://www.kluvcoin.io/img/togo/event/47.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/48.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/49.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/50.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/51.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/52.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/53.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/54.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/55.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/56.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/57.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/58.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/59.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/60.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/61.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/62.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/63.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/64.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/65.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/66.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/67.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/68.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/69.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/70.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/71.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/72.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/73.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/74.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/75.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/76.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/77.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/78.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/79.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/80.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/81.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/82.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/83.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/84.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/85.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/86.jpg" />
          </div>
        </div>

        <br /><br/>
        <p>
          BIG DAY!  Goodwill event photos last July 23, 2022. Over 670 Families and 
          Individual received the food and care package from this Good Will event.
        </p>
        <div class="gg-container" style="padding: 0 30px;">
          <div class="gg-box gallery2 goodwill-gallery">
            <img src="https://www.kluvcoin.io/img/togo/event/87.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/88.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/89.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/90.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/91.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/92.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/93.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/94.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/95.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/96.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/97.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/98.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/99.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/100.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/101.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/102.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/103.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/104.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/105.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/106.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/107.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/108.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/109.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/110.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/110.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/112.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/113.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/114.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/115.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/116.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/117.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/118.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/119.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/120.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/121.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/122.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/123.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/124.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/125.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/126.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/127.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/event/128.jpg" />
          </div>
        </div>

        <br /><br/>
        <p>House And Hospital Visitation:</p>
        <div class="gg-container" style="padding: 0 30px;">
          <div class="gg-box gallery2 goodwill-gallery">
            <img src="https://www.kluvcoin.io/img/togo/hospital/1.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/hospital/2.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/hospital/3.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/hospital/4.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/hospital/5.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/hospital/6.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/hospital/7.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/hospital/8.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/hospital/9.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/hospital/10.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/hospital/11.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/hospital/12.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/hospital/13.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/hospital/14.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/hospital/15.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/hospital/16.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/hospital/17.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/hospital/18.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/hospital/19.jpg" />
            <img src="https://www.kluvcoin.io/img/togo/hospital/20.jpg" />
          </div>
        </div>

        <br/>
        <br/>
        <hr/>
        <p><b>Event Videos:</b></p>
        <br/><br/>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/Hg68FJkoQZA" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/6KgQUBMALRE" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/SmllgrugSZU" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/oixrtsq8yD0" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/q_k-E2ni-og" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/NpSSPMkd9Qw" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/A546SuhRXoA" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/DEdP90_3i5A" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/5ByWzVfWe44" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/rjwPBJhbKKY" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
      </div>
    </div>

    <div class="footer">
      <img src="https://www.kluvcoin.io/img/logo.png" />
      <span>&copy; 2022 KLUV COIN. All Rights Reserved.</span>
    </div>

    <script src="js/grid-gallery.min.js"></script>
    <script>
      // gridGallery({
      //   selector: ".gallery2",
      //   darkMode: true,
      //   layout: "square",
      //   gapLength: 10,
      //   rowHeight: 300,
      //   columnWidth: 300
      // });

      var openMenu = false
      var menu = document.querySelector('.menu');
      var mobileNenu = document.querySelector('.mobile-menu');
      menu.onclick = function (e) {
        openMenu = !openMenu
        if (openMenu) {
          mobileNenu.classList.add("show");
        } else {
          mobileNenu.classList.remove("show");
        }
      }

      var submenu = document.querySelector('.sub-menu');
      var submenyDelay = ''
      submenu.addEventListener("mouseenter", function () {
        if (submenyDelay) clearTimeout(submenyDelay)
        submenu.classList.add("hover");
      })
      submenu.addEventListener("mouseleave", function () {
        if (submenyDelay) clearTimeout(submenyDelay)

        submenyDelay = setTimeout(function () {
          submenu.classList.remove("hover");
        }, 1000)
      })
      var submenuDiv = document.querySelector('.sub-menu div');
      submenu.addEventListener("mouseenter", function () {
        if (submenyDelay) clearTimeout(submenyDelay)
        submenu.classList.add("hover");
      })
      submenu.addEventListener("mouseleave", function () {
        if (submenyDelay) clearTimeout(submenyDelay)
        submenyDelay = setTimeout(function () {
          submenu.classList.remove("hover");
        }, 1000)
      })
    </script>
  </body>
</html>