<html>
<title>Kringle.Cash</title>
<head>
    <meta http-equiv="Content-Type" content="application/xhtml+xml; charset=UTF-8" />
    <link rel="shortcut icon" href="favicon.ico" />
    <!-- mobile settings -->
    <meta name="viewport" content="width=device-width, maximum-scale=1, initial-scale=1, user-scalable=0" />	
    <meta property="og:image" content="https://kringle.cash/images/linkimage2c.jpg" />
	<meta property="og:description" content="Become a Millionaire automatically FREE of CHARGE.   This Cash Giveaway expires soon!  Click NOW and collect your GIFT!" />
	<meta property="og:url" content="https://kringle.cash/" />
    <meta property="og:title" content="Kringle.Cash" />
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css"/>
      
      <script type="text/javascript" src="js/jquery.js"></script> 
	  <script type="text/javascript" src="js/bootstrap.js"></script>
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
	<style>

	</style>
    <link href="css/style.css" media="screen" rel="stylesheet" type="text/css">
    <link href="css/ownstyle.css" media="screen" rel="stylesheet" type="text/css">
    <link href="css/mystyle.css" media="screen" rel="stylesheet" type="text/css">
    <link href="css/info1.css" media="screen" rel="stylesheet" type="text/css">
    <script type="text/javascript">
        function googleTranslateElementInit() {
            new google.translate.TranslateElement({pageLanguage: 'en', layout: google.translate.TranslateElement.InlineLayout.SIMPLE}, 'google_translate_element');
        }
    </script>
    <script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
    <!--<div id="google_translate_element"></div>-->
    <style>
        .goog-te-menu-value img {
           display: none;
        }
        .goog-te-gadget-simple img {
        background-image: url('images/KringleCoin.gif')!important;
        }
    </style>
</head>
<body>
<header>
    <div class="header-top" id="menuUser">
        <div class="container">
            <div class="row">
                <div class="col">
                <!--<div class="col-sm-2 col-xs-12" style="width: 13.666667%;    margin-top: -3px;" id="google_translate_element">
                </div>-->
                <div class="float-right" style="display: inline-block;margin-right: 16px;height: 36px;float: right;">
                    <div id="google_translate_element"></div>
                </div>
                    </div>
            </div>
        </div>
    </div>
</header>


<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://fonts.googleapis.com/css2?family=Fugaz+One&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Roboto+Condensed&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/grid-gallery.min.css">
    <link rel="stylesheet" href="css/style.css?20210128">
  </head>

  <body>

    <div class="goodwill-box d-flex align-center justify-space-around">
      <div class="box">
        <h2>SALEH AHMED MIAH aka TBC Champion has accepted the calling to become the newest Goodwill Ambassador for Bangladesh.</h2>
	      <img src="https://www.kluvcoin.io/img/Saleh.jpg" />
        <p>
          It only took about 6 weeks since the launch of the KLUV Coin and that with less than 1,000 people that have bought it, we raised $30,000. ($10,000 was used in Ivory Coast in February and another $10,000 will be used in March for India). That's amazing; KLUV has already raised $30,000 to buy food for the needy under the Kringle Society Goodwill program. $10,000 of food will be distributed to the poor and needy of an area of Bangladesh on April 16th, 2022.
        </p>
		    <p>
          $10,000 of BNB was sent to Ambassador SALEH AHMED MIAH aka TBC Champion of Bangladesh on April 10th, 2022 to purchase food: 
          <a href="https://bscscan.com/tx/0x5c5f6ea435138688c7acb9ec7da2717440e88b97cc17f3c4ef5d5b55858311c7" target="new">
            https://bscscan.com/tx/0x5c5f6ea435138688c7acb9ec7da2717440e88b97cc17f3c4ef5d5b55858311c7
          </a>
        </p>
		    <br/><br/>
		    <p>Receipts:</p>
		    <div class="gg-container" style="padding: 0 30px;">
          <div class="gg-box gallery goodwill-gallery">
            <img src="https://www.kluvcoin.io/img/SalehReceipt/1.jpg" />
            <img src="https://www.kluvcoin.io/img/SalehReceipt/2.jpg" />
          </div>
        </div>		

		    <br/><br/>
		    <p>
		      <b>TBC Goodwill report for Bangladesh Syed mujammel Hossain Shahin, Associate Ambassador panel & Core team member</b><br/><br/>
			    Distribution of food and iftar of Kringle Society among more than five hundred poor people<br/>

          Ling Alhaj Saleh Ahmad Mia, PhD Researcher, DU's Ph.D. The National Sports Development (DADS Club) distributes daily food items among the poor in the auditorium.
          $10,000 has been donated from the Kringle Society,food items worth about 1 million taka is given to more than 500 poor people.
          Each was given a bag containing 5 liters of teer soybean oil, 10 kg of improved rice, 5 kg of potatoes, 2 kg of onion, 2 kg of sugar, plain and lachcha semai and puffed rice.<br/><br/>

          The program was inaugurated by Md. Lutfur Rahman, Secretary for Labor Development and Welfare of Jatiya Sramik League and General Secretary of Sonali Bank Employees Union B-202. Prominent industrialists, social workers, Asheke Rasool, CEO of Ratan Metal Industries Salahuddin Ratan were the chief guests. The special guest was the eminent female organizer, Sonali Life Insurance Company Ltd. Its branch manager, Rubina Yasmin Ruby.<br/><br/>

          The Qur'an is recited at the beginning. Md. Conducted the program. Mizanur Rahman. Lion Alhaj Saleh Ahmad Miah, Bangladesh Goodwill Ambassador of the Society presided over the function.<br/><br/>

          Among others Adviser Professor Advocate, Shafiqul Islam has given his valuable speech to all , political leader Jebunnesa Mina and Awami League leader, Rupganj member Humayun Kabir Jewel. Syed Mozammel Hossain Shaheen, Cabinet Member, Kringle Society they also given their valuable speech . 
          Sheikh Rizaul Karim Reza, Joynal Abedin Joy, Md. Abul Basar, Md. Nasir Uddin, Md. Selim Khan, Md. Hossainuzzaman, Md. Mahbub, Kazi Mamun, Masud Hossain, Shahin Hossain, Maulana Sabbir Hossain Osmani and Abul Kashem were among the volunteers.
          Inaugural Md. Lutfur Rahman in his speech said that those who cry for the poor are great. We pray for the help that has come from far away America today.<br/><br/>

          The chief guest said in his speech, "We are very happy to be able to give you this help during the month of Ramadan." You will pray for the donors and the Bangladesh team, who have brought this food product for you from abroad with their labor. I have heard that in this way food and economic services will come for Bangladesh for life.<br/><br/>

          Special guest Rubina Yasmin Ruby said in her speech, "I am glad to hear that the $ 10,000 food product that Kringle Club is going to serve you today for free will always come in bigger and bigger sizes!" I believe that the Bangladesh Goodwill Ambassador along with his team will continue to receive these services, donations and grants for the countrymen from the Kringle Society through hard work, talent and competition.<br/><br/>

          Lion Alhaj Saleh Ahmed Miah, Bangladesh Goodwill Ambassador of Kringle Society, who is also the President of the event, said that this is a club. An international donor organization. Its architects have dedicated their resources, talents and labor to humanity. Just as I stood by the people with the Lions Club, I joined the Kringle Society two years ago today and began working for humanity. Today, the first sign of the success of our work is the $ 10,000 food product. Donations will continue to come from this organization.As long as this society exists, we will snatch millions / billion dollars for Bangladesh through our efforts.<br/><br/>
        </p>
		
        <p>Highlights of the events in Bangladesh</p>
        <div class="gg-container" style="padding: 0 30px;">
          <div class="gg-box gallery goodwill-gallery">
            <img src="https://www.kluvcoin.io/img/SaleStep2/1.jpg" />
            <img src="https://www.kluvcoin.io/img/SaleStep2/2.jpg" />
            <img src="https://www.kluvcoin.io/img/SaleStep2/3.jpg" />
            <img src="https://www.kluvcoin.io/img/SaleStep2/4.jpg" />
            <img src="https://www.kluvcoin.io/img/SaleStep2/5.jpg" />
            <img src="https://www.kluvcoin.io/img/SaleStep2/6.jpg" />
            <img src="https://www.kluvcoin.io/img/SaleStep2/7.jpg" />
            <img src="https://www.kluvcoin.io/img/SaleStep2/8.jpg" />
            <img src="https://www.kluvcoin.io/img/SaleStep2/9.jpg" />
            <img src="https://www.kluvcoin.io/img/SaleStep2/10.jpg" />
            <img src="https://www.kluvcoin.io/img/SaleStep2/11.jpg" />
            <img src="https://www.kluvcoin.io/img/SaleStep2/12.jpg" />
            <img src="https://www.kluvcoin.io/img/SaleStep2/13.jpg" />
            <img src="https://www.kluvcoin.io/img/SaleStep2/14.jpg" />
            <img src="https://www.kluvcoin.io/img/SaleStep2/15.jpg" />
            <img src="https://www.kluvcoin.io/img/SaleStep2/16.jpg" />
            <img src="https://www.kluvcoin.io/img/SaleStep2/17.jpg" />
            <img src="https://www.kluvcoin.io/img/SaleStep2/18.jpg" />
            <img src="https://www.kluvcoin.io/img/SaleStep2/19.jpg" />
            <img src="https://www.kluvcoin.io/img/SaleStep2/20.jpg" />
            <img src="https://www.kluvcoin.io/img/SaleStep2/21.jpg" />
            <img src="https://www.kluvcoin.io/img/SaleStep2/22.jpg" />
            <img src="https://www.kluvcoin.io/img/SaleStep2/23.jpg" />
            <img src="https://www.kluvcoin.io/img/SaleStep2/24.jpg" />
            <img src="https://www.kluvcoin.io/img/SaleStep2/25.jpg" />
            <img src="https://www.kluvcoin.io/img/SaleStep2/26.jpg" />
            <img src="https://www.kluvcoin.io/img/SaleStep2/27.jpg" />
            <img src="https://www.kluvcoin.io/img/SaleStep2/28.jpg" />
            <img src="https://www.kluvcoin.io/img/SaleStep2/29.jpg" />
          </div>
        </div>
		    <br/>
        <p>Event's Official Photos - Witness the joy and happiness on the eyes of everyone who attended the event.</p>
        <div class="gg-container" style="padding: 0 30px;">
          <div class="gg-box gallery goodwill-gallery">
            <img src="https://www.kluvcoin.io/img/SaleStep3/1.jpg" />
            <img src="https://www.kluvcoin.io/img/SaleStep3/2.jpg" />
            <img src="https://www.kluvcoin.io/img/SaleStep3/3.jpg" />
            <img src="https://www.kluvcoin.io/img/SaleStep3/4.jpg" />
            <img src="https://www.kluvcoin.io/img/SaleStep3/5.jpg" />
            <img src="https://www.kluvcoin.io/img/SaleStep3/6.jpg" />
            <img src="https://www.kluvcoin.io/img/SaleStep3/7.jpg" />
            <img src="https://www.kluvcoin.io/img/SaleStep3/8.jpg" />
            <img src="https://www.kluvcoin.io/img/SaleStep3/9.jpg" />
            <img src="https://www.kluvcoin.io/img/SaleStep3/10.jpg" />
            <img src="https://www.kluvcoin.io/img/SaleStep3/11.jpg" />
            <img src="https://www.kluvcoin.io/img/SaleStep3/12.jpg" />
            <img src="https://www.kluvcoin.io/img/SaleStep3/13.jpg" />
            <img src="https://www.kluvcoin.io/img/SaleStep3/14.jpg" />
            <img src="https://www.kluvcoin.io/img/SaleStep3/15.jpg" />
            <img src="https://www.kluvcoin.io/img/SaleStep3/16.jpg" />
            <img src="https://www.kluvcoin.io/img/SaleStep3/17.jpg" />
            <img src="https://www.kluvcoin.io/img/SaleStep3/18.jpg" />
            <img src="https://www.kluvcoin.io/img/SaleStep3/19.jpg" />
            <img src="https://www.kluvcoin.io/img/SaleStep3/20.jpg" />
            <img src="https://www.kluvcoin.io/img/SaleStep3/21.jpg" />
            <img src="https://www.kluvcoin.io/img/SaleStep3/22.jpg" />
            <img src="https://www.kluvcoin.io/img/SaleStep3/23.jpg" />
            <img src="https://www.kluvcoin.io/img/SaleStep3/24.jpg" />
            <img src="https://www.kluvcoin.io/img/SaleStep3/25.jpg" />
            <img src="https://www.kluvcoin.io/img/SaleStep3/26.jpg" />
            <img src="https://www.kluvcoin.io/img/SaleStep3/27.jpg" />
            <img src="https://www.kluvcoin.io/img/SaleStep3/28.jpg" />
            <img src="https://www.kluvcoin.io/img/SaleStep3/29.jpg" />
            <img src="https://www.kluvcoin.io/img/SaleStep3/30.jpg" />
            <img src="https://www.kluvcoin.io/img/SaleStep3/31.jpg" />
            <img src="https://www.kluvcoin.io/img/SaleStep3/32.jpg" />
            <img src="https://www.kluvcoin.io/img/SaleStep3/33.jpg" />
            <img src="https://www.kluvcoin.io/img/SaleStep3/34.jpg" />
            <img src="https://www.kluvcoin.io/img/SaleStep3/35.jpg" />
            <img src="https://www.kluvcoin.io/img/SaleStep3/36.jpg" />
            <img src="https://www.kluvcoin.io/img/SaleStep3/37.jpg" />
            <img src="https://www.kluvcoin.io/img/SaleStep3/38.jpg" />
            <img src="https://www.kluvcoin.io/img/SaleStep3/39.jpg" />
            <img src="https://www.kluvcoin.io/img/SaleStep3/40.jpg" />
          </div>
        </div>
        <br/>
        <p>2nd Day of the KLUV Cares Event in Bangladesh</p>
        <div class="gg-container" style="padding: 0 30px;">
          <div class="gg-box gallery goodwill-gallery">
            <img src="https://www.kluvcoin.io/img/SaleStep4/1.jpg" />
            <img src="https://www.kluvcoin.io/img/SaleStep4/2.jpg" />
            <img src="https://www.kluvcoin.io/img/SaleStep4/3.jpg" />
            <img src="https://www.kluvcoin.io/img/SaleStep4/4.jpg" />
            <img src="https://www.kluvcoin.io/img/SaleStep4/5.jpg" />
            <img src="https://www.kluvcoin.io/img/SaleStep4/6.jpg" />
            <img src="https://www.kluvcoin.io/img/SaleStep4/7.jpg" />
            <img src="https://www.kluvcoin.io/img/SaleStep4/8.jpg" />
            <img src="https://www.kluvcoin.io/img/SaleStep4/9.jpg" />
            <img src="https://www.kluvcoin.io/img/SaleStep4/10.jpg" />
            <img src="https://www.kluvcoin.io/img/SaleStep4/11.jpg" />
          </div>
        </div>
        <p>News Article:</p>
        <div class="gg-container" style="padding: 0 30px;">
          <div class="gg-box gallery goodwill-gallery">
            <img src="https://www.kluvcoin.io/img/SalehReceipt/3.jpg" />
            <img src="https://www.kluvcoin.io/img/SalehReceipt/4.jpg" />
            <img src="https://www.kluvcoin.io/img/SalehReceipt/5.jpg" />
            <img src="https://www.kluvcoin.io/img/SalehReceipt/6.jpg" />
          </div>
        </div>
        <br/>
        <p>
          Event's Online Articles/Cover  <br/>  <br/>
          <a href="http://jugobarta.com/%E0%A6%AA%E0%A6%BE%E0%A6%81%E0%A6%9A-%E0%A6%B6%E0%A6%A4%E0%A6%BE%E0%A6%A7%E0%A6%BF%E0%A6%95-%E0%A6%A6%E0%A6%B0%E0%A6%BF%E0%A6%A6%E0%A7%8D%E0%A6%B0%E0%A7%87%E0%A6%B0-%E0%A6%AE%E0%A6%BE%E0%A6%9D/" target="new">
          1. Jugobarta  <br/>
          </a>
          <a href="https://thedailymorningglory.com/distribution-of-food-iftar-by-kringle-society/" target="new">
            2. The Daily Morning Glory  <br/>
          </a>		  
          <a href="https://mkprotidin.com/archives/31824" target="new">
            3. Mkprotidin  <br/>
          </a>
          <a href="https://dailycitizentimes.com/epaper?filter=second&&current_date=2022-04-18" target="new">
            4. Daily Citizen Times  <br/>
          </a>
          <a href="https://banglapratidin.net/2022/04/18/%E0%A6%A6%E0%A6%B0%E0%A6%BF%E0%A6%A6%E0%A7%8D%E0%A6%B0%E0%A7%87%E0%A6%B0-%E0%A6%AE%E0%A6%A7%E0%A7%8D%E0%A6%AF%E0%A7%87-%E0%A6%95%E0%A7%8D%E0%A6%B0%E0%A6%BF%E0%A6%82%E0%A6%97%E0%A7%87%E0%A6%B2/" target="new">
            5. Bangla Pratidin  <br/>
          </a>
          <a href="https://businessbangladesh.com.bd/article/256394?fbclid=IwAR0IBzLtIi1e8po3fvdz6NvgH5n04dtxDIM3pRsJOcqCa-TcP0ldZRcjLcM" target="new">
            6. Business Bangladesh  <br/>
          </a>
          <a href="https://www.nawroj.com.bd/desktop/post/bangladesh/25148" target="new">
            7. Nawroj <br/>
          </a>
        </p>
        <p>
          <br/>
          Official Videos of the event in Bangladesh  <br/>
    
          <center><iframe width="560" height="315" src="https://www.youtube.com/embed/G8JJTDRk2uA" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
              
          <iframe width="560" height="315" src="https://www.youtube.com/embed/x7qwF6nfHHI" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe></center>
          <br/>
        </p>
      </div>
    </div>

    <script src="js/grid-gallery.min.js"></script>
    <script>
      gridGallery({
        selector: ".gallery",
        darkMode: true,
        layout: "square",
        gapLength: 10,
        rowHeight: 300,
        columnWidth: 300
      });
    </script>
  </body>
</html>