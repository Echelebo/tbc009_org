<html>
<title>Kringle.Cash</title>
<head>
    <meta http-equiv="Content-Type" content="application/xhtml+xml; charset=UTF-8" />
    <link rel="shortcut icon" href="favicon.ico" />
    <!-- mobile settings -->
    <meta name="viewport" content="width=device-width, maximum-scale=1, initial-scale=1, user-scalable=0" />	
    <meta property="og:image" content="https://kringle.cash/images/linkimage2c.jpg" />
	<meta property="og:description" content="Become a Millionaire automatically FREE of CHARGE.   This Cash Giveaway expires soon!  Click NOW and collect your GIFT!" />
	<meta property="og:url" content="https://kringle.cash/" />
    <meta property="og:title" content="Kringle.Cash" />
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css"/>
      
      <script type="text/javascript" src="js/jquery.js"></script> 
	  <script type="text/javascript" src="js/bootstrap.js"></script>
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
	<style>

	</style>
    <link href="css/style.css" media="screen" rel="stylesheet" type="text/css">
    <link href="css/ownstyle.css" media="screen" rel="stylesheet" type="text/css">
    <link href="css/mystyle.css" media="screen" rel="stylesheet" type="text/css">
    <link href="css/info1.css" media="screen" rel="stylesheet" type="text/css">
    <script type="text/javascript">
        function googleTranslateElementInit() {
            new google.translate.TranslateElement({pageLanguage: 'en', layout: google.translate.TranslateElement.InlineLayout.SIMPLE}, 'google_translate_element');
        }
    </script>
    <script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
    <!--<div id="google_translate_element"></div>-->
    <style>
        .goog-te-menu-value img {
           display: none;
        }
        .goog-te-gadget-simple img {
        background-image: url('images/KringleCoin.gif')!important;
        }
    </style>
</head>
<body>
<header>
    <div class="header-top" id="menuUser">
        <div class="container">
            <div class="row">
                <div class="col">
                <!--<div class="col-sm-2 col-xs-12" style="width: 13.666667%;    margin-top: -3px;" id="google_translate_element">
                </div>-->
                <div class="float-right" style="display: inline-block;margin-right: 16px;height: 36px;float: right;">
                    <div id="google_translate_element"></div>
                </div>
                    </div>
            </div>
        </div>
    </div>
</header>


<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://fonts.googleapis.com/css2?family=Fugaz+One&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Roboto+Condensed&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/grid-gallery.min.css">
    <link rel="stylesheet" href="css/style.css?20210128">
  </head>

  <body>
    <div class="goodwill-box d-flex align-center justify-space-around">
      <div class="box">
	
	      <h2>Syed Rahman has accepted the calling to become the newest Goodwill Ambassador for India.</h2>
        <img src="https://www.kluvcoin.io/img/Syed.jpg" />
        <p>
           It only took a month since the launch of the KLUV Coin and that with less than 1,000 people that have bought it, we raised $20,000. ($10,000 was used in Ivory Coast in February). That's amazing; KLUV has already raised $20,000 to buy food for the needy under the Kringle Society Goodwill program. $10,000 of food will be distributed to the poor and needy of an area of India on March 26th, 2022.
        </p>
		<img src="https://www.kluvcoin.io/img/sanowar.jpg" /><br/><br/>
		<a class="more-btn" href="india_excellency.php"><h2>Click Here for Sir Excellency's Goodwill Report</h2></a>
		<br/><br/>
		<p>
          $10,000 of BNB was sent to Ambassador Syed Rahman of India on March 20th, 2022 to purchase food:  
          <a href="https://bscscan.com/tx/0x8205485d543fd33bdeeaa4163335bab336a80098673c1c97f068a1249e7a078f" target="new">
            https://bscscan.com/tx/0x8205485d543fd33bdeeaa4163335bab336a80098673c1c97f068a1249e7a078f
          </a>
        </p>
		<p>Receipts:</p>
		 <div class="gg-container" style="padding: 0 30px;">
          <div class="gg-box gallery goodwill-gallery">
            <img src="https://www.kluvcoin.io/img/SyedReceipt/1.jpg" />
            <img src="https://www.kluvcoin.io/img/SyedReceipt/2.jpg" />
            <img src="https://www.kluvcoin.io/img/SyedReceipt/3.jpg" />
            <img src="https://www.kluvcoin.io/img/SyedReceipt/4.jpg" />
            <img src="https://www.kluvcoin.io/img/SyedReceipt/5.jpg" />
          </div>
        </div>
		
				<br/><br/>
		<p>
		      <b>SYED RAHMAN GOODWILL AMBASSADOR REPORT FOR INDIA - 2022</b><br/><br/>

			First of all I would like to Submit my first ever official report as one of the TBC Goodwill Ambassador of India , And I also would like to thank the TBC Admin for appointing me one of the TBC Goodwill Ambassador in the TBC community, for giving me this opportunity, my team and myself are so grateful and thanks to kismet international (KLUV), we would always please to serve the community in the days to come. <br/><br/>

			My team and myself have work in a short period, because of the Holi festival in India, tough all the agency are close, we started to manage to reach out. We manage working from 24th March 2022, same day on 24th March we called a meeting of all the tbcian leaders and to make a new working committee  for the Goodwill mission and on the same day we manage to buy foods items and we had given press conference meeting on the next day on 25th March we manage to pack  food items and we had accordingly distributed to 450 persons irrespective of caste, creed, and religion in the valley of Imphal Manipur. The needy people including of  blind, disable and widows and marginalized people etc. <br/><br/>

			Therefore, It should be noted that the TBC Administrator sent fund worth $10.000 to feed the needy people in the society.<br/><br/>

			And last 26th March 2022 we are delighted to share these to vulnerable people and destitute people for the 1st time in life place in Imphal East, kongba kshetri Leikai Manipur 450 persons included Orphan , Handicapped, Blind, Dump and widowed who is in a pathetic life. Presented 50kg of rice and (one liter eatable oil , 1kg masori dal,1kg chana dal, 1kg alu,1kg onion , 1kg salt, 1kg sugar, 250gms tea, and 250gms dry fist) all in one packet. <br/><br/>

			2nd Event on 3rd March 2022 at B.B Paul Mental Development Home (Special School) is located in Rural Areas of Imphal West District, Manipur India. The member presented in the conference were around 50 mentally disable orphanage, there we present 25kgs x 5begs of rice and eatable item packet 15 nos.<br/><br/>
        </p>
		
		
		
		<p>Committee in India being led by Mr. Syed Rahman</p>
		 <div class="gg-container" style="padding: 0 30px;">
          <div class="gg-box gallery goodwill-gallery">
            <img src="https://www.kluvcoin.io/img/SyedCommittee/1.jpg" />
            <img src="https://www.kluvcoin.io/img/SyedCommittee/2.jpg" />
          </div>
        </div>
		<p>TBC Goodwill report for India by our Goodwill Ambassador, Mr. Syed Rahman</p>
		 <div class="gg-container" style="padding: 0 30px;">
          <div class="gg-box gallery goodwill-gallery">
            <img src="https://www.kluvcoin.io/img/SyedStep1/1.jpg" />
            <img src="https://www.kluvcoin.io/img/SyedStep1/2.jpg" />
			<img src="https://www.kluvcoin.io/img/SyedStep1/3.jpg" />
            <img src="https://www.kluvcoin.io/img/SyedStep1/4.jpg" />
			<img src="https://www.kluvcoin.io/img/SyedStep1/5.jpg" />
            <img src="https://www.kluvcoin.io/img/SyedStep1/6.jpg" />
			<img src="https://www.kluvcoin.io/img/SyedStep1/7.jpg" />
            <img src="https://www.kluvcoin.io/img/SyedStep1/8.jpg" />
			<img src="https://www.kluvcoin.io/img/SyedStep1/9.jpg" />
            <img src="https://www.kluvcoin.io/img/SyedStep1/10.jpg" />
			<img src="https://www.kluvcoin.io/img/SyedStep1/11.jpg" />
            <img src="https://www.kluvcoin.io/img/SyedStep1/12.jpg" />
			<img src="https://www.kluvcoin.io/img/SyedStep1/13.jpg" />
            <img src="https://www.kluvcoin.io/img/SyedStep1/14.jpg" />
			<img src="https://www.kluvcoin.io/img/SyedStep1/17.jpg" />
            <img src="https://www.kluvcoin.io/img/SyedStep1/15.jpg" />
			<img src="https://www.kluvcoin.io/img/SyedStep1/19.jpg" />
			<img src="https://www.kluvcoin.io/img/SyedStep1/22.jpg" />
			<img src="https://www.kluvcoin.io/img/SyedStep1/23.jpg" />
            <img src="https://www.kluvcoin.io/img/SyedStep1/24.jpg" />
			<img src="https://www.kluvcoin.io/img/SyedStep1/25.jpg" />
            <img src="https://www.kluvcoin.io/img/SyedStep1/26.jpg" />
			<img src="https://www.kluvcoin.io/img/SyedStep1/27.jpg" />
			<img src="https://www.kluvcoin.io/img/SyedStep1/28.jpg" />
			<img src="https://www.kluvcoin.io/img/SyedStep1/29.jpg" />
			<img src="https://www.kluvcoin.io/img/SyedStep1/30.jpg" />
            <img src="https://www.kluvcoin.io/img/SyedStep1/31.jpg" />
			<img src="https://www.kluvcoin.io/img/SyedStep1/32.jpg" />
            <img src="https://www.kluvcoin.io/img/SyedStep1/33.jpg" />
			<img src="https://www.kluvcoin.io/img/SyedStep1/34.jpg" />
			<img src="https://www.kluvcoin.io/img/SyedStep1/36.jpg" />
          </div>
        </div>
		<p>Rice bags Distribution Helping our TBCIAN Leaders</p>
		 <div class="gg-container" style="padding: 0 30px;">
          <div class="gg-box gallery goodwill-gallery">
            <img src="https://www.kluvcoin.io/img/SyedStep2/1.jpg" />
            <img src="https://www.kluvcoin.io/img/SyedStep2/2.jpg" />
			<img src="https://www.kluvcoin.io/img/SyedStep2/3.jpg" />
            <img src="https://www.kluvcoin.io/img/SyedStep2/4.jpg" />
			<img src="https://www.kluvcoin.io/img/SyedStep2/5.jpg" />
			<img src="https://www.kluvcoin.io/img/SyedStep2/6.jpg" />
            <img src="https://www.kluvcoin.io/img/SyedStep2/7.jpg" />
			<img src="https://www.kluvcoin.io/img/SyedStep2/8.jpg" />
            <img src="https://www.kluvcoin.io/img/SyedStep2/9.jpg" />
			<img src="https://www.kluvcoin.io/img/SyedStep2/10.jpg" />
			<img src="https://www.kluvcoin.io/img/SyedStep2/11.jpg" />
          </div>
        </div>
	  <br/>
	  	<p>2nd Event on 3rd March, 2022 at B.B. Paul Special  School for mentally Disable persons</p>
		 <div class="gg-container" style="padding: 0 30px;">
          <div class="gg-box gallery goodwill-gallery">
            <img src="https://www.kluvcoin.io/img/SyedStep3/1.jpg" />
            <img src="https://www.kluvcoin.io/img/SyedStep3/2.jpg" />
			<img src="https://www.kluvcoin.io/img/SyedStep3/3.jpg" />
            <img src="https://www.kluvcoin.io/img/SyedStep3/4.jpg" />
			<img src="https://www.kluvcoin.io/img/SyedStep3/5.jpg" />
			<img src="https://www.kluvcoin.io/img/SyedStep3/6.jpg" />
            <img src="https://www.kluvcoin.io/img/SyedStep3/7.jpg" />
			<img src="https://www.kluvcoin.io/img/SyedStep3/8.jpg" />
            <img src="https://www.kluvcoin.io/img/SyedStep3/9.jpg" />
			<img src="https://www.kluvcoin.io/img/SyedStep3/10.jpg" />
          </div>
        </div>
	  <br/>
	  
	  <p>Events' Press Conference</p>
		 <div class="gg-container" style="padding: 0 30px;">
          <div class="gg-box gallery goodwill-gallery">
            <img src="https://www.kluvcoin.io/img/SyedPresscon/1.jpg" />
            <img src="https://www.kluvcoin.io/img/SyedPresscon/6.jpg" />
			<img src="https://www.kluvcoin.io/img/SyedPresscon/3.jpg" />
            <img src="https://www.kluvcoin.io/img/SyedPresscon/4.jpg" />
			<img src="https://www.kluvcoin.io/img/SyedPresscon/5.jpg" />
			<img src="https://www.kluvcoin.io/img/SyedPresscon/7.jpg" />
            <img src="https://www.kluvcoin.io/img/SyedPresscon/8.jpg" />
			<img src="https://www.kluvcoin.io/img/SyedPresscon/9.jpg" />
            <img src="https://www.kluvcoin.io/img/SyedPresscon/10.jpg" />
			<img src="https://www.kluvcoin.io/img/SyedPresscon/11.jpg" />
			<img src="https://www.kluvcoin.io/img/SyedPresscon/12.jpg" />
            <img src="https://www.kluvcoin.io/img/SyedPresscon/13.jpg" />
			<img src="https://www.kluvcoin.io/img/SyedPresscon/14.jpg" />
            <img src="https://www.kluvcoin.io/img/SyedPresscon/15.jpg" />
          </div>
        </div>
	  <br/>
	  		<p>
		Videos for the event in India  <br/>
		<center><iframe width="560" height="315" src="https://www.youtube.com/embed/LINX5vHcP_g" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
		 <iframe width="560" height="315" src="https://www.youtube.com/embed/z19Uk5RPzns" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
		 <iframe width="560" height="315" src="https://www.youtube.com/embed/5lG4AbcBvSc" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe></center>
		 <iframe width="560" height="315" src="https://www.youtube.com/embed/TdmSxJhQeOk" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe></center>
		<br/></p>
	
	  
	  
	   
      </div>
    </div>

    <script src="js/grid-gallery.min.js"></script>
    <script>
      gridGallery({
        selector: ".gallery",
        darkMode: true,
        layout: "square",
        gapLength: 10,
        rowHeight: 300,
        columnWidth: 300
      });
    </script>
  </body>
</html>