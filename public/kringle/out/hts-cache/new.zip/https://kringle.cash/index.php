<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css"
          integrity="sha384-hWVjflwFxL6sNzntih27bfxkr27PmbbK/iSvJ+a4+0owXq79v+lsFkW54bOGbiDQ" crossorigin="anonymous">
    <link href="content/css/style.css" rel="stylesheet"/>

    <title>Kringle.cash</title>
    <script type="text/javascript">
        function googleTranslateElementInit() {
            new google.translate.TranslateElement({
                pageLanguage: 'en',
                layout: google.translate.TranslateElement.InlineLayout.SIMPLE
            }, 'google_translate_element');
        }
    </script>
    <script type="text/javascript"
            src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
</head>
<body>

<nav id="TopNav" class="navbar navbar-dark bg-dark sticky-top">
    <a class="navbar-brand" href="#">
        <img id="logo" src="./content/img/SBC-75.png"/>
    </a>
    <!--<ul class="navbar-nav">
        <li class="nav-item active">
            <a class="nav-link navbar-header" href="#"><img id="logo" src="./content/img/dark_logo_50.png" /> </a>
        </li>
    </ul>-->
    <div class="navbar-expand" id="navbarNavAltMarkup">
        <div class="navbar-nav">
            <div id="google_translate_element" style="margin-top: 18px"></div>
            <div style="margin-top: 11px;margin-left: 45px;">
				<a href="https://youtu.be/V6b5XnjrIzo" target="_blank">
				 <!--<img src="content/img/facebook.png" />-->
				</a>
            </div>
        </div>
        <div class="navbar-nav">
            <a class="nav-item nav-link" href="https://kringle.cash/covid.php">Covid-19</a>
            <a class="nav-item nav-link" href="https://kringle.cash/portal/">Login</a>

        <li class="nav-item dropdown">
                    <a href="#" id="menu" data-toggle="dropdown" class="nav-link dropdown-toggle">Goodwill</a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="http://kringle.cash/ambassador-goodwill/">Ambassadors</a></li>
                        <li><a class="dropdown-item" href="https://kringle.cash/ambassador-goodwill/bangladesh.php">Banglasesh</a></li>
                        <li><a class="dropdown-item" href="https://kringle.cash/ambassador-goodwill/cameroon.php">Cameroon</a></li>
                        <li><a class="dropdown-item" href="https://kringle.cash/ambassador-goodwill/cameroon-round3.php">Cameroon - Round 3</a></li>
                        <li><a class="dropdown-item" href="https://kringle.cash/ambassador-goodwill/ghana.php">Ghana</a></li>
                        <li><a class="dropdown-item" href="https://kringle.cash/ambassador-goodwill/india.php">India</a></li>
                        <li><a class="dropdown-item" href="https://kringle.cash/ambassador-goodwill/india_excellency.php">India - Excellency</a></li>
                        <li><a class="dropdown-item" href="https://kringle.cash/ambassador-goodwill/india-round2.php">India - Round 2</a></li>
                        <li><a class="dropdown-item" href="https://kringle.cash/ambassador-goodwill/ivory-coast.php">Ivory Coast</a></li>
                        <li><a class="dropdown-item" href="https://kringle.cash/ambassador-goodwill/ivory-coast-round2.php">Ivory Coast - Round 2</a></li>
                        <li><a class="dropdown-item" href="https://kringle.cash/ambassador-goodwill/nigeria.php">Nigeria</a></li>
                        <li><a class="dropdown-item" href="https://kringle.cash/ambassador-goodwill/philippines.php">Philippines</a></li>
                        <li><a class="dropdown-item" href="https://kringle.cash/ambassador-goodwill/south-africa.php">South Africa</a></li>
                        <li><a class="dropdown-item" href="https://kringle.cash/ambassador-goodwill/togo.php">Togo</a></li>
                        <li><a class="dropdown-item" href="https://kringle.cash/ambassador-goodwill/uganda.php">Uganda</a></li>
                        </ul>
                </li>
            <!---<a class="nav-item nav-link" href="https://kringle.cash/merchant_locations.php">Merchant Locations</a>-->
            <!--<a class="nav-item nav-link" href="https://kringle.cash/publicnotice.php" target="_blank">Public Notice</a>-->
        </div>


    </div>

</nav>

<!-- Return to top button -->
<div id="scroll-to-top" style="position:fixed; top:91%; left:96%; z-index:99; display:none;">
    <a id="up-arrow-link" class="nav-link link-black" href="#"><span id="up-arrow-button" style="font-size:xx-large; ">&uarr;</span></a>
</div>


<div class="container-fluid img-container">
    <img src="content/img/bg1a.jpg" style="width:100%;"/>
    <!--<div class="bg1-text-top-right">-->
    </div>
</div>




<div id="footer" class="nav-background-footer text-center">
    <!--<a href="http://goldpricez.com/us/gram" style="font-size: small" target="_blank"> Today Gold Rates </a>-->
</div>
</body>
</html>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js"></script>
<script src="code/js/_main.js"></script>
<script>


</script>
