<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css"
          integrity="sha384-hWVjflwFxL6sNzntih27bfxkr27PmbbK/iSvJ+a4+0owXq79v+lsFkW54bOGbiDQ" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/smoothness/jquery-ui.css">
    <link href="../content/css/style.css" rel="stylesheet"/>
    <title>Kringle.cash</title>
    <script type="text/javascript">
        function googleTranslateElementInit() {
            new google.translate.TranslateElement({
                pageLanguage: 'en',
                layout: google.translate.TranslateElement.InlineLayout.SIMPLE
            }, 'google_translate_element');
        }
    </script>
    <script type="text/javascript"
            src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
</head>
<body>

<nav id="TopNav" class="navbar navbar-dark bg-dark sticky-top">
    <a class="navbar-brand" href="#">
        <img id="logo" src="../content/img/logo_75.png"/>
    </a>
    <!--<ul class="navbar-nav">
        <li class="nav-item active">
            <a class="nav-link navbar-header" href="#"><img id="logo" src="./content/img/dark_logo_50.png" /> </a>
        </li>
    </ul>-->
    <div class="navbar-expand" id="navbarNavAltMarkup">
        <div class="navbar-nav">
            <div id="google_translate_element" style="margin-top: 18px"></div>
            <div style="margin-top: 11px;margin-left: 45px;">
                <a href="https://youtu.be/V6b5XnjrIzo" target="_blank">
                    <img src="../content/img/noitulover.png"/>
                </a>
            </div>
        </div>
        <div class="navbar-nav">
            <a class="nav-item nav-link" href="//kringle.cash/covid.php">COVID-19</a>
            <a class="nav-item nav-link" href="//kringle.cash/portal/">Login</a>
            <a class="nav-item nav-link" href="//kringle.cash/ambassador-goodwill/">Goodwill</a>
            <a class="nav-item nav-link" href="//kringle.cash/merchant_locations.php">Merchant
                Locations</a>
            <a class="nav-item nav-link" href="//kringle.cash/publicnotice.php" target="_blank">Public Notice</a>
        </div>


    </div>

</nav>
<link href="content/css/registration_form.css?v3" rel="stylesheet"/>
<div class="container">
    <div class="row">
        <div class="col">&nbsp;</div>
    </div>
    <div class="row">
        <div class="col text-center">
            <ul id="breadcrumb">
                <li><a><span></span></a></li>
                <li><a href="#"><span class="far fa-check-square"></span> Validate Email &amp; Sponsor</a></li>
                <li><a href="#"><span class="far fa-check-square"></span>Complete Registration</a></li>
                <li><a href="#" class="active">FREE ACCOUNT</a></li>
            </ul>
        </div>
    </div>
    <div class="row">
        <div class="col text-center">
            <b>Your registration is complete. Please allow 15 Minutes and you may click the LOGIN menu item above. IF YOUR LOGIN SAYS INVALID CREDENTIAL, YOU DIDN'T WAIT LONG ENOUGH. Please note you will be required to enroll your FACE for access and if you wish to make a payment for your account please visit YOUR ACCOUNT after login.</b>
        </div>
    </div>


</div>

<div id="footer" class="nav-background-footer">

</div>
<div style="height:100px"></div> </body>
</html>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.20/js/dataTables.bootstrap4.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js"></script>
    <!-- I'm not sure if the menu is boggling this up or not. But somehow $.modal doesn't work -->
    <!-- I've just been re-importing it in my code below the include header -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
    <!-- Insure a fresh load of this each time. -->
    <script src="/code/js/_main_menu.js?random=65fad18acf470"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootbox.js/5.4.1/bootbox.min.js"></script>

<!-- MDB -->

<!-- BEGIN PHP Live! HTML Code [V3] -->
<span style="color: #0000FF; text-decoration: underline; line-height: 0px !important; cursor: pointer; position: fixed; bottom: 0px; right: 20px; z-index: 20000000;"
      id="phplive_btn_1588501606"></span>
<script data-cfasync="false" type="text/javascript">

    (function () {
        var phplive_e_1588501606 = document.createElement("script");
        phplive_e_1588501606.type = "text/javascript";
        phplive_e_1588501606.async = true;
        phplive_e_1588501606.src = "https://support.kringle.cash/phplive/js/phplive_v2.js.php?v=0%7C1588501606%7C2%7C&";
        document.getElementById("phplive_btn_1588501606").appendChild(phplive_e_1588501606);
        if ([].filter) {
            document.getElementById("phplive_btn_1588501606").addEventListener("click", function () {
                phplive_launch_chat_0()
            });
        } else {
            document.getElementById("phplive_btn_1588501606").attachEvent("onclick", function () {
                phplive_launch_chat_0()
            });
        }
    })();

</script>
<!-- END PHP Live! HTML Code [V3] -->