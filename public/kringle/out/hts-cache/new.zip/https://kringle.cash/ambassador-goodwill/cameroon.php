<html>
<title>Kringle.Cash</title>
<head>
    <meta http-equiv="Content-Type" content="application/xhtml+xml; charset=UTF-8" />
    <link rel="shortcut icon" href="favicon.ico" />
    <!-- mobile settings -->
    <meta name="viewport" content="width=device-width, maximum-scale=1, initial-scale=1, user-scalable=0" />	
    <meta property="og:image" content="https://kringle.cash/images/linkimage2c.jpg" />
	<meta property="og:description" content="Become a Millionaire automatically FREE of CHARGE.   This Cash Giveaway expires soon!  Click NOW and collect your GIFT!" />
	<meta property="og:url" content="https://kringle.cash/" />
    <meta property="og:title" content="Kringle.Cash" />
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css"/>
      
      <script type="text/javascript" src="js/jquery.js"></script> 
	  <script type="text/javascript" src="js/bootstrap.js"></script>
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
	<style>

	</style>
    <link href="css/style.css" media="screen" rel="stylesheet" type="text/css">
    <link href="css/ownstyle.css" media="screen" rel="stylesheet" type="text/css">
    <link href="css/mystyle.css" media="screen" rel="stylesheet" type="text/css">
    <link href="css/info1.css" media="screen" rel="stylesheet" type="text/css">
    <script type="text/javascript">
        function googleTranslateElementInit() {
            new google.translate.TranslateElement({pageLanguage: 'en', layout: google.translate.TranslateElement.InlineLayout.SIMPLE}, 'google_translate_element');
        }
    </script>
    <script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
    <!--<div id="google_translate_element"></div>-->
    <style>
        .goog-te-menu-value img {
           display: none;
        }
        .goog-te-gadget-simple img {
        background-image: url('images/KringleCoin.gif')!important;
        }
    </style>
</head>
<body>
<header>
    <div class="header-top" id="menuUser">
        <div class="container">
            <div class="row">
                <div class="col">
                <!--<div class="col-sm-2 col-xs-12" style="width: 13.666667%;    margin-top: -3px;" id="google_translate_element">
                </div>-->
                <div class="float-right" style="display: inline-block;margin-right: 16px;height: 36px;float: right;">
                    <div id="google_translate_element"></div>
                </div>
                    </div>
            </div>
        </div>
    </div>
</header>


<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://fonts.googleapis.com/css2?family=Fugaz+One&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Roboto+Condensed&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/grid-gallery.min.css">
    <link rel="stylesheet" href="css/style.css?20210128">
  </head>

  <body>

    <div class="goodwill-box d-flex align-center justify-space-around">
      <div class="box">
	      <h2>Cameroon Gets Second Round of Goodwill this April</h2>
        <img src="https://www.kluvcoin.io/img/mbeh.jpg" />
        <p>
          With over 600 Members of the Core Team coming from Cameroon they deserve a second round of Goodwill lead 
          by one of the original Ambassadors <b>Mbeh Derick</b>.  CONGRATULATIONS CAMEROON!  In less than 9 weeks 
          KLUV has been able to pull out $40,000.00 from the market to support the Goodwill Efforts of the Kringle 
          Society.  $10,000.00 of that will be spent on food to feed the poor in Cameroon on April 30th, 2022.
        </p>
        <p>
          $10,000 of BNB was sent to Ambassador Mbeh Derick of Cameroon on April 23rd, 2022 to purchase food:
          <a href="https://bscscan.com/tx/0xe5c596abcad16a5c03eb367981283021d7394a7f7e558919a8e9e81370bd673e " target="_blank">
          https://bscscan.com/tx/0xe5c596abcad16a5c03eb367981283021d7394a7f7e558919a8e9e81370bd673e 
          </a>
        </p>
        <p>Receipts:</p>
		    <p>
		      <b>TBC Goodwill report for Cameroon by Mbeh Derick</b>
          <br/><br/>
          Our Goodwill event in Cameroon that took place on the 30th of April was such a memorable moment for the 
          people in Douala- Cameroon. we had the blind, dumb, deaf crippled, people with special disabilities, 
          struggling parents and orphans.
          <br/><br/>
		  
		      We had a total of 500 persons receive food from the Kluv . we gave them 500bags of 10kg of rice each bag 
          per person and cooking oil, a bottle per person, Half a dozen of washing soap per person as well as 2kg 
          of (garri ) locally made fast food per person.This meeting was preceded by our Divisional delegate for 
          social affairs and some top government officials.
          <br/><br/>
		  
		      The receivers were so happy and expressed words of gratitude and blessings to kris kringle and kismet love.
		      My team and I also want to thank the TBC Admin who made all these possible and we pray that may God 
          continue to bless him with wisdom and strength to continue this great mission.
		      <br/><br/>
		      <b>Kluv shares, Kluv cares.<br/>Thanks</b>
        </p>
		
		<p>Receipts:</p>
        <div class="gg-container" style="padding: 0 30px;">
          <div class="gg-box gallery2 goodwill-gallery">
            <img src="https://www.kluvcoin.io/img/mbehreceipt/1.jpg" />
            <img src="https://www.kluvcoin.io/img/mbehreceipt/2.jpg" />
            <img src="https://www.kluvcoin.io/img/mbehreceipt/3.jpg" />
            <img src="https://www.kluvcoin.io/img/mbehreceipt/4.jpg" />
            <img src="https://www.kluvcoin.io/img/mbehreceipt/5.jpg" />
            <img src="https://www.kluvcoin.io/img/mbehreceipt/6.jpg" />
            <img src="https://www.kluvcoin.io/img/mbehreceipt/7.jpg" />
            <img src="https://www.kluvcoin.io/img/mbehreceipt/8.jpg" />
          </div>
          <br/>
        </div>

        <p>Event Photos in Douala - Cameroon( Distribution, Perfomances and Ceremony</p>
        <div class="gg-container" style="padding: 0 30px;">
          <div class="gg-box gallery2 goodwill-gallery">
            <img src="https://www.kluvcoin.io/img/mbehstep1/1.jpg" />
            <img src="https://www.kluvcoin.io/img/mbehstep1/2.jpg" />
            <img src="https://www.kluvcoin.io/img/mbehstep1/3.jpg" />
            <img src="https://www.kluvcoin.io/img/mbehstep1/4.jpg" />
            <img src="https://www.kluvcoin.io/img/mbehstep1/5.jpg" />
            <img src="https://www.kluvcoin.io/img/mbehstep1/6.jpg" />
            <img src="https://www.kluvcoin.io/img/mbehstep1/7.jpg" />
            <img src="https://www.kluvcoin.io/img/mbehstep1/8.jpg" />
            <img src="https://www.kluvcoin.io/img/mbehstep1/9.jpg" />
            <img src="https://www.kluvcoin.io/img/mbehstep1/10.jpg" />
            <img src="https://www.kluvcoin.io/img/mbehstep1/11.jpg" />
            <img src="https://www.kluvcoin.io/img/mbehstep1/12.jpg" />
            <img src="https://www.kluvcoin.io/img/mbehstep1/13.jpg" />
            <img src="https://www.kluvcoin.io/img/mbehstep1/14.jpg" />
            <img src="https://www.kluvcoin.io/img/mbehstep1/15.jpg" />
            <img src="https://www.kluvcoin.io/img/mbehstep1/16.jpg" />
            <img src="https://www.kluvcoin.io/img/mbehstep1/17.jpg" />
            <img src="https://www.kluvcoin.io/img/mbehstep1/18.jpg" />
            <img src="https://www.kluvcoin.io/img/mbehstep1/19.jpg" />
            <img src="https://www.kluvcoin.io/img/mbehstep1/20.jpg" />
            <img src="https://www.kluvcoin.io/img/mbehstep1/21.jpg" />
            <img src="https://www.kluvcoin.io/img/mbehstep1/22.jpg" />
            <img src="https://www.kluvcoin.io/img/mbehstep1/23.jpg" />
            <img src="https://www.kluvcoin.io/img/mbehstep1/24.jpg" />
            <img src="https://www.kluvcoin.io/img/mbehstep1/25.jpg" />
            <img src="https://www.kluvcoin.io/img/mbehstep1/26.jpg" />
            <img src="https://www.kluvcoin.io/img/mbehstep1/27.jpg" />
            <img src="https://www.kluvcoin.io/img/mbehstep1/28.jpg" />
            <img src="https://www.kluvcoin.io/img/mbehstep1/29.jpg" />
            <img src="https://www.kluvcoin.io/img/mbehstep1/30.jpg" />
			      <img src="https://www.kluvcoin.io/img/mbehstep1/31.jpg" />
            <img src="https://www.kluvcoin.io/img/mbehstep1/32.jpg" />
            <img src="https://www.kluvcoin.io/img/mbehstep1/33.jpg" />
            <img src="https://www.kluvcoin.io/img/mbehstep1/34.jpg" />
            <img src="https://www.kluvcoin.io/img/mbehstep1/35.jpg" />
            <img src="https://www.kluvcoin.io/img/mbehstep1/36.jpg" />
            <img src="https://www.kluvcoin.io/img/mbehstep1/37.jpg" />
            <img src="https://www.kluvcoin.io/img/mbehstep1/38.jpg" />
            <img src="https://www.kluvcoin.io/img/mbehstep1/39.jpg" />
            <img src="https://www.kluvcoin.io/img/mbehstep1/40.jpg" />
            <img src="https://www.kluvcoin.io/img/mbehstep1/41.jpg" />
            <img src="https://www.kluvcoin.io/img/mbehstep1/42.jpg" />
            <img src="https://www.kluvcoin.io/img/mbehstep1/43.jpg" />
            <img src="https://www.kluvcoin.io/img/mbehstep1/44.jpg" />
            <img src="https://www.kluvcoin.io/img/mbehstep1/45.jpg" />
            <img src="https://www.kluvcoin.io/img/mbehstep1/46.jpg" />
            <img src="https://www.kluvcoin.io/img/mbehstep1/47.jpg" />
            <img src="https://www.kluvcoin.io/img/mbehstep1/48.jpg" />
            <img src="https://www.kluvcoin.io/img/mbehstep1/49.jpg" />
            <img src="https://www.kluvcoin.io/img/mbehstep1/50.jpg" />
            <img src="https://www.kluvcoin.io/img/mbehstep1/51.jpg" />
            <img src="https://www.kluvcoin.io/img/mbehstep1/52.jpg" />
            <img src="https://www.kluvcoin.io/img/mbehstep1/53.jpg" />
            <img src="https://www.kluvcoin.io/img/mbehstep1/54.jpg" />
            <img src="https://www.kluvcoin.io/img/mbehstep1/55.jpg" />
          </div>
          <br/>
        </div>
		   
        <p>
          Official Videos of the event in Cameroon
          <br/>
          <center>
            <iframe width="560" height="315" src="https://www.youtube.com/embed/uqSpTz9gGBU" title="YouTube video player" 
              frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
              allowfullscreen
            ></iframe>
          </center>
        </p>
      </div>
    </div>

    <script src="js/grid-gallery.min.js"></script>
    <script>
      gridGallery({
        selector: ".gallery2",
        darkMode: true,
        layout: "square",
        gapLength: 10,
        rowHeight: 300,
        columnWidth: 300
      });
    </script>
  </body>
</html>