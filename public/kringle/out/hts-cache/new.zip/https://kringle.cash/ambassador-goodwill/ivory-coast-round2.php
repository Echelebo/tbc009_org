<html>
<title>Kringle.Cash</title>
<head>
    <meta http-equiv="Content-Type" content="application/xhtml+xml; charset=UTF-8" />
    <link rel="shortcut icon" href="favicon.ico" />
    <!-- mobile settings -->
    <meta name="viewport" content="width=device-width, maximum-scale=1, initial-scale=1, user-scalable=0" />	
    <meta property="og:image" content="https://kringle.cash/images/linkimage2c.jpg" />
	<meta property="og:description" content="Become a Millionaire automatically FREE of CHARGE.   This Cash Giveaway expires soon!  Click NOW and collect your GIFT!" />
	<meta property="og:url" content="https://kringle.cash/" />
    <meta property="og:title" content="Kringle.Cash" />
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css"/>
      
      <script type="text/javascript" src="js/jquery.js"></script> 
	  <script type="text/javascript" src="js/bootstrap.js"></script>
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
	<style>

	</style>
    <link href="css/style.css" media="screen" rel="stylesheet" type="text/css">
    <link href="css/ownstyle.css" media="screen" rel="stylesheet" type="text/css">
    <link href="css/mystyle.css" media="screen" rel="stylesheet" type="text/css">
    <link href="css/info1.css" media="screen" rel="stylesheet" type="text/css">
    <script type="text/javascript">
        function googleTranslateElementInit() {
            new google.translate.TranslateElement({pageLanguage: 'en', layout: google.translate.TranslateElement.InlineLayout.SIMPLE}, 'google_translate_element');
        }
    </script>
    <script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
    <!--<div id="google_translate_element"></div>-->
    <style>
        .goog-te-menu-value img {
           display: none;
        }
        .goog-te-gadget-simple img {
        background-image: url('images/KringleCoin.gif')!important;
        }
    </style>
</head>
<body>
<header>
    <div class="header-top" id="menuUser">
        <div class="container">
            <div class="row">
                <div class="col">
                <!--<div class="col-sm-2 col-xs-12" style="width: 13.666667%;    margin-top: -3px;" id="google_translate_element">
                </div>-->
                <div class="float-right" style="display: inline-block;margin-right: 16px;height: 36px;float: right;">
                    <div id="google_translate_element"></div>
                </div>
                    </div>
            </div>
        </div>
    </div>
</header>


<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://fonts.googleapis.com/css2?family=Fugaz+One&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Roboto+Condensed&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/grid-gallery.min.css">
    <link rel="stylesheet" href="css/style.css?20210128">
  </head>

  <body>
    <div class="goodwill-box d-flex align-center justify-space-around">
      <div class="box">
	      <h2>Ambassador Innocent Keiba of Ivory Coast has truly become a Leader of Leaders and the list of Ivory Coast Leaders in TBC is far too many to list here.</h2>
        <img src="https://www.kluvcoin.io/img/R2_Keiba.jpg" />
        <p>
          We currently have about 14,000 Active Members in the world and about 3,000 of them can be found in Ivory Coast on the Core and Back Up Teams.
          <br/><br/>
          We must support the strength we find within this TBC community and that is why it makes sense to do Round 2 of Goodwill in Ivory Coast. We only have about 2,700 Holders of the KLUV coin and this second round of Goodwill will mean that we have raised the total amount of money for Goodwill to $90,000.00 within the first 6 months of the existence of the KLUV coin. THAT'S AMAZING! $10,000.00 of that will be spent on food to feed the poor again in Ivory Coast on August 20th, 2022.
        </p>
        <p>
          $10,000 of BNB was sent to Ambassador Innocent Keiba of Ivory Coast on August 15th, 2022 to purchase food:
          <a href="https://bscscan.com/tx/0x531af7c5aca4fcd9517ae2401d7ca489837fdc82129fdeecaf1b4383a205b453" target="new">
            https://bscscan.com/tx/0x531af7c5aca4fcd9517ae2401d7ca489837fdc82129fdeecaf1b4383a205b453
          </a>
        </p>
        <p><b>Receipts</b></p>
		    <div class="gg-container" style="padding: 0 30px;">
          <div class="gg-box gallery goodwill-gallery">
            <img src="https://www.kluvcoin.io/img/keiba_round2/receipt/1.jpg" />
            <img src="https://www.kluvcoin.io/img/keiba_round2/receipt/2.jpg" />
            <img src="https://www.kluvcoin.io/img/keiba_round2/receipt/3.jpg" />
            <img src="https://www.kluvcoin.io/img/keiba_round2/receipt/4.jpg" />
            <img src="https://www.kluvcoin.io/img/keiba_round2/receipt/5.jpg" />
          </div>
        </div>

        <br/><br/>
        <p><b>Promo Ad and Flyer</b></p>
		    <div class="gg-container" style="padding: 0 30px;">
          <div class="gg-box gallery goodwill-gallery">
            <img src="https://www.kluvcoin.io/img/keiba_round2/ads/1.jpg" />
            <img src="https://www.kluvcoin.io/img/keiba_round2/ads/2.jpg" />
          </div>
        </div>

        <br/><br/>
        <p><b>Preparation: Packs</b></p>
		    <div class="gg-container" style="padding: 0 30px;">
          <div class="gg-box gallery goodwill-gallery">
            <img src="https://www.kluvcoin.io/img/keiba_round2/preparations/1.jpg" />
            <img src="https://www.kluvcoin.io/img/keiba_round2/preparations/2.jpg" />
            <img src="https://www.kluvcoin.io/img/keiba_round2/preparations/3.jpg" />
          </div>
        </div>

        <br/><br/>
        <p><b>Welcom Banner</b></p>
		    <div class="gg-container" style="padding: 0 30px;">
          <div class="gg-box gallery goodwill-gallery">
            <img src="https://www.kluvcoin.io/img/keiba_round2/banner/1.jpg" />
          </div>
        </div>

        <br/><br/><br/>
        <p><b>THE MARCHING BAND WITH ALL DELEGATION FROM COUNTRY SIDE and ORIENTATION</b></p>
		    <div class="gg-container" style="padding: 0 30px;">
          <div class="gg-box gallery goodwill-gallery">
            <img src="https://www.kluvcoin.io/img/keiba_round2/marching_band/1.jpg" />
            <img src="https://www.kluvcoin.io/img/keiba_round2/marching_band/2.jpg" />
            <img src="https://www.kluvcoin.io/img/keiba_round2/marching_band/7.jpg" />
            <img src="https://www.kluvcoin.io/img/keiba_round2/marching_band/3.jpg" />
            <img src="https://www.kluvcoin.io/img/keiba_round2/marching_band/4.jpg" />
            <img src="https://www.kluvcoin.io/img/keiba_round2/marching_band/5.jpg" />
            <img src="https://www.kluvcoin.io/img/keiba_round2/marching_band/6.jpg" />
          </div>
        </div>

        <br/><br/>
        <p><b>OPENING OFFICIAL CEREMONY & THE WELCOME SPEECHES</b></p>
		    <div class="gg-container" style="padding: 0 30px;">
          <div class="gg-box gallery goodwill-gallery">
            <img src="https://www.kluvcoin.io/img/keiba_round2/opening_official/1.jpg" />
            <img src="https://www.kluvcoin.io/img/keiba_round2/opening_official/2.jpg" />
            <img src="https://www.kluvcoin.io/img/keiba_round2/opening_official/7.jpg" />
            <img src="https://www.kluvcoin.io/img/keiba_round2/opening_official/3.jpg" />
            <img src="https://www.kluvcoin.io/img/keiba_round2/opening_official/4.jpg" />
            <img src="https://www.kluvcoin.io/img/keiba_round2/opening_official/5.jpg" />
            <img src="https://www.kluvcoin.io/img/keiba_round2/opening_official/6.jpg" />
          </div>
        </div>

        <br/><br/>
        <p><b>The official delivery of donations to the authorities for the population</b></p>
		    <div class="gg-container" style="padding: 0 30px;">
          <div class="gg-box gallery goodwill-gallery">
            <img src="https://www.kluvcoin.io/img/keiba_round2/official_delivery/1.jpg" />
            <img src="https://www.kluvcoin.io/img/keiba_round2/official_delivery/2.jpg" />
            <img src="https://www.kluvcoin.io/img/keiba_round2/official_delivery/3.jpg" />
            <img src="https://www.kluvcoin.io/img/keiba_round2/official_delivery/4.jpg" />
            <img src="https://www.kluvcoin.io/img/keiba_round2/official_delivery/5.jpg" />
            <img src="https://www.kluvcoin.io/img/keiba_round2/official_delivery/6.jpg" />
            <img src="https://www.kluvcoin.io/img/keiba_round2/official_delivery/7.jpg" />
            <img src="https://www.kluvcoin.io/img/keiba_round2/official_delivery/8.jpg" />
            <img src="https://www.kluvcoin.io/img/keiba_round2/official_delivery/9.jpg" />
            <img src="https://www.kluvcoin.io/img/keiba_round2/official_delivery/10.jpg" />
            <img src="https://www.kluvcoin.io/img/keiba_round2/official_delivery/11.jpg" />
            <img src="https://www.kluvcoin.io/img/keiba_round2/official_delivery/12.jpg" />
            <img src="https://www.kluvcoin.io/img/keiba_round2/official_delivery/13.jpg" />
            <img src="https://www.kluvcoin.io/img/keiba_round2/official_delivery/14.jpg" />
            <img src="https://www.kluvcoin.io/img/keiba_round2/official_delivery/15.jpg" />
            <img src="https://www.kluvcoin.io/img/keiba_round2/official_delivery/16.jpg" />
            <img src="https://www.kluvcoin.io/img/keiba_round2/official_delivery/17.jpg" />
            <img src="https://www.kluvcoin.io/img/keiba_round2/official_delivery/18.jpg" />
            <img src="https://www.kluvcoin.io/img/keiba_round2/official_delivery/19.jpg" />
          </div>
        </div>

        <br/><br/>
        <p><b>General distribution of the Food to all families, poor and vulnerable people as well as Charitable Organizations</b></p>
		    <div class="gg-container" style="padding: 0 30px;">
          <div class="gg-box gallery goodwill-gallery">
            <img src="https://www.kluvcoin.io/img/keiba_round2/general_distribution/1.jpg" />
            <img src="https://www.kluvcoin.io/img/keiba_round2/general_distribution/2.jpg" />
            <img src="https://www.kluvcoin.io/img/keiba_round2/general_distribution/3.jpg" />
            <img src="https://www.kluvcoin.io/img/keiba_round2/general_distribution/4.jpg" />
            <img src="https://www.kluvcoin.io/img/keiba_round2/general_distribution/5.jpg" />
            <img src="https://www.kluvcoin.io/img/keiba_round2/general_distribution/6.jpg" />
            <img src="https://www.kluvcoin.io/img/keiba_round2/general_distribution/7.jpg" />
            <img src="https://www.kluvcoin.io/img/keiba_round2/general_distribution/8.jpg" />
            <img src="https://www.kluvcoin.io/img/keiba_round2/general_distribution/9.jpg" />
            <img src="https://www.kluvcoin.io/img/keiba_round2/general_distribution/10.jpg" />
            <img src="https://www.kluvcoin.io/img/keiba_round2/general_distribution/11.jpg" />
            <img src="https://www.kluvcoin.io/img/keiba_round2/general_distribution/12.jpg" />
            <img src="https://www.kluvcoin.io/img/keiba_round2/general_distribution/13.jpg" />
            <img src="https://www.kluvcoin.io/img/keiba_round2/general_distribution/14.jpg" />
            <img src="https://www.kluvcoin.io/img/keiba_round2/general_distribution/15.jpg" />
            <img src="https://www.kluvcoin.io/img/keiba_round2/general_distribution/16.jpg" />
            <img src="https://www.kluvcoin.io/img/keiba_round2/general_distribution/17.jpg" />
            <img src="https://www.kluvcoin.io/img/keiba_round2/general_distribution/18.jpg" />
            <img src="https://www.kluvcoin.io/img/keiba_round2/general_distribution/19.jpg" />
            <img src="https://www.kluvcoin.io/img/keiba_round2/general_distribution/20.jpg" />
            <img src="https://www.kluvcoin.io/img/keiba_round2/general_distribution/21.jpg" />
            <img src="https://www.kluvcoin.io/img/keiba_round2/general_distribution/22.jpg" />
            <img src="https://www.kluvcoin.io/img/keiba_round2/general_distribution/23.jpg" />
            <img src="https://www.kluvcoin.io/img/keiba_round2/general_distribution/24.jpg" />
            <img src="https://www.kluvcoin.io/img/keiba_round2/general_distribution/25.jpg" />
            <img src="https://www.kluvcoin.io/img/keiba_round2/general_distribution/26.jpg" />
            <img src="https://www.kluvcoin.io/img/keiba_round2/general_distribution/27.jpg" />
            <img src="https://www.kluvcoin.io/img/keiba_round2/general_distribution/28.jpg" />
            <img src="https://www.kluvcoin.io/img/keiba_round2/general_distribution/29.jpg" />
            <img src="https://www.kluvcoin.io/img/keiba_round2/general_distribution/30.jpg" />
            <img src="https://www.kluvcoin.io/img/keiba_round2/general_distribution/31.jpg" />
            <img src="https://www.kluvcoin.io/img/keiba_round2/general_distribution/32.jpg" />
            <img src="https://www.kluvcoin.io/img/keiba_round2/general_distribution/33.jpg" />
            <img src="https://www.kluvcoin.io/img/keiba_round2/general_distribution/34.jpg" />
            <img src="https://www.kluvcoin.io/img/keiba_round2/general_distribution/35.jpg" />
          </div>
        </div>

        <br/>
        <br/>
        <hr/>
        <p><b>Event Videos:</b></p>
        <br/><br/>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/9KckiiaaCcM" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/550J-UtHFEI" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/JuWVBgKTEvk" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/rVmltAAXmfw" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/APAJmKmlavY" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/uD3WfC3TyOc" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/nbk1W--NlBk" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/OjBAvSDtWQQ" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/sJpCOv047mk" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/S0MOqJknC50" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/Y8-vEv9Peps" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/NiSgpm3eMXs" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/7j21tS7zyKw" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/NiSgpm3eMXs" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/JWgZOVZ2V_E" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/ILYiALNFEj8" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/_QlMbl2Cvok" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/glIZt33aQ_s" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/a_2-exBzZVw" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/Oqkasi93EAs" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/Z4UGo1ulOiA" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <iframe width="560" height="315" src="https://www.youtube.com/embed/CZNp1MUrATk" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
      </div>
    </div>

    <script src="js/grid-gallery.min.js"></script>
    <script>
      gridGallery({
        selector: ".gallery",
        darkMode: true,
        layout: "square",
        gapLength: 10,
        rowHeight: 300,
        columnWidth: 300
      });
    </script>
  </body>
</html>