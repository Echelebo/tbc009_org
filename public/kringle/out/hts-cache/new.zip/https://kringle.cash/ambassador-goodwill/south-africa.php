<html>
<title>Kringle.Cash</title>
<head>
    <meta http-equiv="Content-Type" content="application/xhtml+xml; charset=UTF-8" />
    <link rel="shortcut icon" href="favicon.ico" />
    <!-- mobile settings -->
    <meta name="viewport" content="width=device-width, maximum-scale=1, initial-scale=1, user-scalable=0" />	
    <meta property="og:image" content="https://kringle.cash/images/linkimage2c.jpg" />
	<meta property="og:description" content="Become a Millionaire automatically FREE of CHARGE.   This Cash Giveaway expires soon!  Click NOW and collect your GIFT!" />
	<meta property="og:url" content="https://kringle.cash/" />
    <meta property="og:title" content="Kringle.Cash" />
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css"/>
      
      <script type="text/javascript" src="js/jquery.js"></script> 
	  <script type="text/javascript" src="js/bootstrap.js"></script>
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
	<style>

	</style>
    <link href="css/style.css" media="screen" rel="stylesheet" type="text/css">
    <link href="css/ownstyle.css" media="screen" rel="stylesheet" type="text/css">
    <link href="css/mystyle.css" media="screen" rel="stylesheet" type="text/css">
    <link href="css/info1.css" media="screen" rel="stylesheet" type="text/css">
    <script type="text/javascript">
        function googleTranslateElementInit() {
            new google.translate.TranslateElement({pageLanguage: 'en', layout: google.translate.TranslateElement.InlineLayout.SIMPLE}, 'google_translate_element');
        }
    </script>
    <script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
    <!--<div id="google_translate_element"></div>-->
    <style>
        .goog-te-menu-value img {
           display: none;
        }
        .goog-te-gadget-simple img {
        background-image: url('images/KringleCoin.gif')!important;
        }
    </style>
</head>
<body>
<header>
    <div class="header-top" id="menuUser">
        <div class="container">
            <div class="row">
                <div class="col">
                <!--<div class="col-sm-2 col-xs-12" style="width: 13.666667%;    margin-top: -3px;" id="google_translate_element">
                </div>-->
                <div class="float-right" style="display: inline-block;margin-right: 16px;height: 36px;float: right;">
                    <div id="google_translate_element"></div>
                </div>
                    </div>
            </div>
        </div>
    </div>
</header>


<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://fonts.googleapis.com/css2?family=Fugaz+One&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Roboto+Condensed&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/grid-gallery.min.css">
    <link rel="stylesheet" href="css/style.css?20210128">
    <title>Kluv Coin</title>
  </head>

  <body>

  <div class="goodwill-box d-flex align-center justify-space-around">
      <div class="box">
	      <h2>Victoria Edmond Egejuru aka Victorious Flourish has Accepted the Call to Become the Goodwill Ambassador of South Africa</h2>
        <img src="https://www.kluvcoin.io/img/victoria_edmond.jpg" />
        <p>
          It was difficult to choose a Goodwill Ambassador for South Africa because there are many great Kringle Leaders residing in South Africa. Victoria Edmond Egejuru aka Victorious Flourish has Accepted the call to become the Goodwill Ambassador of South Africa and she was chosen mostly because she persisted in her requests to have Goodwill done in South Africa. Ask and you shall receive, as the saying goes. We have spent most of the year 2022 supporting the fastest growing countries within the Kringle Society and now it is time to branch out to other countries like South Africa. We believe that by bringing Goodwill to South Africa that it will help us to grow our Kringle communtiy there faster. We want to speed up our growth in countries like South Africa. We hope all the great Kringle Leaders of South Africa will unite and fully support our effort to do Goodwill in their country having Victoria Edmond Egejuru as their Goodwill Ambassador. Our Active Membership globally continues to grow and now we have about 24,000 Active Members and just under 4,000 Holders of the KLUV coin. We have raised the total amount of money for Goodwill to $120,000.00 within the first 8 months of the existence of the KLUV coin. THAT'S AMAZING! $10,000.00 of that will be spent on food to feed the poor in South Africa on November 19th, 2022.
        </p>
        <p>
          $10,000 of BNB was sent to Ambassador Victoria Edmond Egejuru on November 14th, 2022 to purchase food:
          <a href="https://bscscan.com/tx/0x05d271a4ec78a5f4ec134e7694dcc3f5c2e4dc4f31550cede5783ae61054ac37" target="new">
            https://bscscan.com/tx/0x05d271a4ec78a5f4ec134e7694dcc3f5c2e4dc4f31550cede5783ae61054ac37
          </a>
          <br/><br/>
        </p>
        <p><b>APPRECIATION</b></p>
        <p>
          First and foremost, I want to give Glory to God for our wonderful
          community and the great Admin God blessed us with, special thanks to our Admin. I also
          want to thank Admin for finding me worthy to be the Goodwill Ambassador for South Africa,
          it’s a great honour, thank you sir. We are in a divine project.
          <br/><br/>
          I thank God Almighty for a very successful event, special thanks to our great South African
          Leaders that contributed immensely to the great success of the goodwill: My Dear Husband,
          Mr. Edmond, Mr Henry, Madam Given, Mama H, Madam Ntombi, Mr David, Mr Daniel,
          Madam Happy, Mr Banjo, Mr Yomi, Mr Xaba and all other great leaders and members of
          South African Chapter, God bless you all. Special thanks goes to Chief Justice, Mr
          Augustine, (I call him Professor) and Mr Optimistic for their great supports. To the entire
          community, thanks a million for your words of encouragement.
          <br/><br/>
        </p>
        <p><b>PLANNING COMMITTEES</b></p>
        <p>
          As soon as South African Goodwill was announced by our
          Precious Admin, we formed “A Committee Members” comprising of Madam
          Flourish/Husband, Madam Given, Mr David, Mama H, Madam Ntombi, Mr Daniel and
          Madam Happy. We agreed that each will go for a market survey to get best prices on food
          items; it was also agreed that we come up with necessary food items that will be used for the
          goodwill. At the end of week 2, we agreed on stable food (Rice, Maizemeal, Fishoil and later
          added Potatoes). At the end of the day, we chose the cheapest supplier.
          <br/><br/>
        </p>
        <div class="gg-container" style="padding: 0 30px;">
          <div class="gg-box gallery goodwill-gallery">
            <img src="https://www.kluvcoin.io/img/south-africa/committees/1.jpg" />
            <img src="https://www.kluvcoin.io/img/south-africa/committees/2.jpg" />
            <img src="https://www.kluvcoin.io/img/south-africa/committees/3.jpg" />
            <img src="https://www.kluvcoin.io/img/south-africa/committees/4.jpg" />
            <img src="https://www.kluvcoin.io/img/south-africa/committees/5.jpg" />
            <img src="https://www.kluvcoin.io/img/south-africa/committees/6.jpg" />
            <img src="https://www.kluvcoin.io/img/south-africa/committees/7.jpg" />
          </div>
        </div>
        <br/><br/>
        <p><b>PROVINCIAL LEADERS</b></p>
        <p>
          We also appointed ‘Provincial Leaders’ to represent our
          community in the various provinces. They are: Madam Given for Guateng, Mama H for
          KZN, Mr Daniel for Limpopo, Mr Xaba for Free State, Mr Piet for Northern Cape, Mr Gad
          for Eastern Cape, and Madam Masuku for Mpumalanga. Two provinces are still vacant of
          leaders. Each province has a Provincial leader, Assistant and a Secretary.
          <br/><br/>
        </p>
        <p><b>RADIO TALKSHOW</b></p>
        <p>
          Three provinces were chosen for a Radio talkshow to talk about our
          goodwill; almost at the dying minutes, we decided that there was no need to go on Radio to
          talk about our goodwill, we however agreed to talk about our Kringle Society so as to create
          more awareness for us here in South Africa. We budgeted R21,000 for the Radio TalkShow
          and the money is still intact in kluv. We will do the talkshow before the end of November for
          the 3 provinces so that we can take advantage of the December promo.
          <br/><br/>
        </p>
        <p><b>LOCATION FOR THE EVENT</b></p>
        <p>
          Next was to identify the location of the goodwill; it was
          agreed that since The Goodwill Ambassador lives in Johannesburg Gauteng, we should start
          from there and the best location for the goodwill is Alexandra in Johannesburg, one of the
          poorest communities in Johannesburg and also a very high risk area.
          <br/><br/>
          We started looking out for a Government property for the venue so we can have a free venue.
          We approached government personnel in charge of the various properties including
          Alexandra Stadium but we were told that all Government Properties will go through same
          process. Once approved, we can choose from among any.
          <br/><br/>
          We filled their form, wrote a letter and waited for when we will be called for presentation.
          Eventually, we were called for presentation and we were told that the process can cost about
          R30,000 then they told us that the venue will be free; I couldn’t hold back my laughter. We
          hurried out of the place in search of a private venue. We got one for R5,000 but were told that
          all weekend have been booked except for 18th. All attempt to get Admin to approve the date
          proved abortive hence our continuous search. My husband and Mr Henry spoke to the
          councillor of Alexandra who eventually got the attention of the person in charge of the Youth
          Centre and we found a free venue.
          <br/><br/>
        </p>
        <p><b>RANDS VALUE OF BNB RECEIVED</b></p>
        <p>
          We got our goodwill money on Monday the 14th
          of November from Admin; the moment I received the $10,000, I logged into Binance to get
          the Rands equivalent, below is the equivalent:
          <div class="gg-container" style="padding: 0 30px;">
            <div class="gg-box gallery goodwill-gallery">
              <img src="https://www.kluvcoin.io/img/south-africa/rands/1.jpg" />
            </div>
          </div>
          </p>
          <p>
          I transferred 30 BNB immediately to Binance and choose to trade with Williams, a verified
          Binance trader whom I have traded with like 6 times, the amount was R102,981.90. He
          indicated paid about 17 Minutes after I initiated the trade and I did not receive the funds in
          my account. I became very worried after 45 minutes then I put up a group call with the
          committee members including my kringle sponsor Mr Yomi. It was Mr Yomi that calmed the
          situation down by saying that South African Bank may have held back the fund to verify
          from the buyer before releasing the fund. My BP went very high when I waited for almost 2
          hours on a trade that was supposed to be completed within 15 Minutes. I was almost
          involving the police when I got the alert and we all were so excited and thanked God for his
          faithfulness. This delay brought about value reduction from R167,342.35 to R165,342.35 and
          based on the value reduction, I swapped the remaining BNB to Kluv in metamask for fear of
          more reductions.
          <br/><br/>
          <b>
            AFTER PAYING FOR FIRST BATCHES OF ITEMS, WE NEEDED TO PAY FOR
            THE REST AND THAT WAS WHEN I NOTICED THAT KLUV WAS DOWN; NOT
            KNOWING WHAT TO DO, I CONTACTED THE TEAM TO INFORM THEM AND
            THEY SAID I SHOULD GIVE IT TIME, WAITED TILL VERY LATE AND KLUV
            WAS STILL DOWN, I DECIDED TO CONSULT WITH MR. AUGUSTINE WHOM I
            FEEL UNDERSTANDS THE MOVEMENT OF THE MARKET BETTER BUT I
            STILL DIDN’T GET A SOLUTION. THE NEXT DAY KLUV WAS STILL DOWN SO
            I DECIDED TO LEAVE THE FUNDS IN KLUV TILL IT RECOVERS. THE MONEY
            WHICH IS STILL IN KLUV WILL HOWEVER BE USED FOR RADIO
            TALKSHOW.
            <br/><br/>
            TOTAL MONEY RECEIVED FROM ADMIN WAS $10,000 WHICH I
            IMMEDIATELY SCREENSHOT IN BINANCE AS CAN BE SEEN IN ABOVE
            WHICH IS R167, 342.35, WHICH LATER REDUCED IN VALUE TO R165,342.35 SO
            OUR WORKING CAPITAL WAS R165,342.35
          </b>
          <br/><br/>
        </p>
        <p><b>LOGISTICS/REFRESHMENT OF COMMITTEE MEMBERS</b></p>
        <p>
          EXPENSES OF MEMBERS’ COMMITTEE MARKET SURVEY AND REFRESHMENT
          WITH THEIR TEAM AFTER THE EVENT
          <table class="simple-table" cellspacing="1">
            <tr>
              <td>Madam Flourish/Husband</td>
              <td>R3,600</td>
            </tr>
            <tr>
              <td>Madam Given</td>
              <td>R2,100</td>
            </tr>
            <tr>
              <td>Madam Ntombi</td>
              <td>R1,650</td>
            </tr>
            <tr>
              <td>Mama H</td>
              <td>R1,500</td>
            </tr>
            <tr>
              <td>Mr. David</td>
              <td>R1,500</td>
            </tr>
            <tr>
              <td>Madam Happy</td>
              <td>R700</td>
            </tr>
            <tr>
              <td>Mr Daniel</td>
              <td>NIL</td>
            </tr>
            <tr>
              <td><b>TOTAL</b></td>
              <td><b>R11,050</b></td>
            </tr>
          </table>
          <br/><br/>
        </p>
        <p><b>TOTAL SUM UP</b></p>
        <p>
          300 BAGS OF 10KG RICE
          <br/><br/>
          300 BAGS OF 10KG MAIZEMILL
          <br/><br/>
          300 OF 2 LITERS OF FISHOIL
          <br/><br/>
          300 BAGS OF 7KG PATATOES
          <br/><br/>
          VAT, BRANDING AND LOGISTCS
          <br/><br/>
          TOTAL = R109,143
          <br/><br/>
          COST OF EVENT = R21,950
          <br/><br/>
          CRYPTO CHARGES/BANK CHARGES = R1,500
          <br/><br/>
          CASH AT HAND FOR RADIO TALK SHOW R21,699.35
          <br/><br/>
          R11,050
          <br/>
          R109,143
          <br/>
          R21,950
          <br/>
          R1,500
          <br/>
          R21,699.35
          <br/><br/>
          <b>SUB TOTAL COST = R165,342.35</b>
          <div class="gg-container" style="padding: 0 30px;">
            <div class="gg-box gallery goodwill-gallery">
            <img src="https://www.kluvcoin.io/img/south-africa/invoice/1.jpg" />
            <img src="https://www.kluvcoin.io/img/south-africa/invoice/2.jpg" />
          </div>
        </div>
          <br/><br/>
        </p>
        <p><b>CONCLUSION:</b></p>
        <p>
          The hall was full with about 500 people, we had much more than 100
          people outside the hall and close to 50 people outside the gate; We printed tickets for 300
          beneficiaries and those without tickets were already crying and murmuring therefore, we
          decided to give 4 items (Rice, Maizemeal, Potatoes and Fishoil) each to the physically
          challenged and the very old helpless women among the beneficiaries. After which we gave
          the rest 2 items (Rice and Fishoil or Maizemeal and Potatoes) each. We were able to give to
          about 700 or more beneficiaries.
          <br/><br/>
          Everyone present was so excited, beneficiaries were over joyed, Government representatives
          were amazed and promised to take words back to the Government, South African Kringle
          Society leaders/members were so happy.
          <br/><br/>
          We thank God for a beautiful and successful event. We appreciate our TBC Admin and
          promise to take this community to greater heights in South Africa.
          <br/><br/>
          A professional media coverage will be handed over to the Admin as soon as possible. It was a
          great event.
          <br/><br/>
        </p>
      </div>
    </div>

    <script src="../js/grid-gallery.min.js"></script>
    
    <script>
      gridGallery({
        selector: ".gallery",
        darkMode: true,
        layout: "square",
        gapLength: 10,
        rowHeight: 300,
        columnWidth: 300
      });
    </script>
  </body>
</html>