<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css"
          integrity="sha384-hWVjflwFxL6sNzntih27bfxkr27PmbbK/iSvJ+a4+0owXq79v+lsFkW54bOGbiDQ" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/smoothness/jquery-ui.css">
    <link href="../content/css/style.css" rel="stylesheet"/>
    <title>Kringle.cash</title>
    <script type="text/javascript">
        function googleTranslateElementInit() {
            new google.translate.TranslateElement({
                pageLanguage: 'en',
                layout: google.translate.TranslateElement.InlineLayout.SIMPLE
            }, 'google_translate_element');
        }
    </script>
    <script type="text/javascript"
            src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
</head>
<body>

<nav id="TopNav" class="navbar navbar-dark bg-dark sticky-top">
    <a class="navbar-brand" href="#">
        <img id="logo" src="../content/img/logo_75.png"/>
    </a>
    <!--<ul class="navbar-nav">
        <li class="nav-item active">
            <a class="nav-link navbar-header" href="#"><img id="logo" src="./content/img/dark_logo_50.png" /> </a>
        </li>
    </ul>-->
    <div class="navbar-expand" id="navbarNavAltMarkup">
        <div class="navbar-nav">
            <div id="google_translate_element" style="margin-top: 18px"></div>
            <div style="margin-top: 11px;margin-left: 45px;">
                <a href="https://youtu.be/V6b5XnjrIzo" target="_blank">
                    <img src="../content/img/noitulover.png"/>
                </a>
            </div>
        </div>
        <div class="navbar-nav">
            <a class="nav-item nav-link" href="//kringle.cash/covid.php">COVID-19</a>
            <a class="nav-item nav-link" href="//kringle.cash/portal/">Login</a>
            <a class="nav-item nav-link" href="//kringle.cash/ambassador-goodwill/">Goodwill</a>
            <a class="nav-item nav-link" href="//kringle.cash/merchant_locations.php">Merchant
                Locations</a>
            <a class="nav-item nav-link" href="//kringle.cash/publicnotice.php" target="_blank">Public Notice</a>
        </div>


    </div>

</nav>

<nav aria-label="breadcrumb">
    <ol class="breadcrumb">
        <li class="breadcrumb-item">
            <a href="index.php">Dashboard</a>
        </li>
        <li class="breadcrumb-item active" aria-current="page">Account</li>
        <li class="breadcrumb-item active" aria-current="page">Merchant Locations</li>
    </ol>
</nav>

<link href="wsc-plugin/plugin/merchantlocations/css/main.min.css" rel="stylesheet" />
<main class="wsc-body">
    <section class="search-wrapper">
        <h2>Find Merchants</h2>
        <div id="formAlert" class="alert"></div>
        <form action="#" id="merchantSearchForm" data-action="getListings">
            <div class="basic-search">
                <label for="city" class="label-bold">Street Address</label>
                <input type="text" name="address" id="address" placeholder="Street Address">
                <label for="city" class="label-bold">City</label>
                <input type="text" name="city" id="city" placeholder="City">
                <div class="state-prov">
                    <label for="state" class="label-bold">State/Province</label>
                    <input type="text" name="state" id="state_province" placeholder="State/Province">
                </div>
                <div class="country">
                    <label for="country" class="label-bold">Country</label>
                    <input type="text" name="country" id="country" placeholder="Country">
                </div>
            </div>
            <h3 id="advanceToggle">Advanced Search<span id="arrow"></span></h3>
            <div class="advanced-search">
                <label for="participation-level" class="label-bold">Participation Level</label>
                <div class="custom-select-wsc">
                    <select name="participation_level" id="participation_level">
                        <option value="">Select An Option</option>
                        <option value="">All Levels</option>
                        <option value="Distributor Only">Distributor</option>
                        <option value="10">10%</option>
                        <option value="20">20%</option>
                        <option value="30">30%</option>
                        <option value="40">40%</option>
                        <option value="50">50%</option>
                        <option value="60">60%</option>
                        <option value="70">70%</option>
                        <option value="80">80%</option>
                        <option value="90">90%</option>
                        <option value="100">100%</option>
                    </select>
                </div>
                <label for="merchant-name" class="label-bold">Merchant Name</label>
                <input type="text" name="merchant_name" id="merchant_name" placeholder="Acme Supply">
            </div>
            <input type="submit" value="Search" id="searchMerchants">
        </form>
    </section>
    <section class="results-wrapper">
        <img src="/wsc-plugin/plugin/merchantlocations/images/spendmerch.jpg">
    </section>
    <template id="merchant-search-no-results">
    <h2 class="no-results">No Results.</h2>
</template>
<template id="merchant-search-template">
    <div class="card-wsc">
        <div class="store-front">
            <img class='card-image' src="https://images.unsplash.com/photo-1464869372688-a93d806be852?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1350&q=80"
                alt="Image">
        </div>
        <div class="details">
            <h2 class="card-name">Stumptown Brew Bar</h2>
            <address class="card-address">
                123 Some St City, State 12345, US
            </address>
            <h3 class="card-type">Small Business</h3>
            <h3 class="card-participation">100% Participation</h3>
            <button class="view-details" data-mid="">View Details</button>
        </div>
    </div>
</template></main>
<div class="wsc-overlay">
    <div class="modal">
    <span class="close-modal">Close <i class="fas fa-times"></i></span>
    <div id="merchant-details-wrapper">

    </div>
</div>
<template id="merchant-full-details-template">
    <div class="image-overview">
        <h2>Storefront</h2>
        <img class="store-image" src="https://images.unsplash.com/photo-1464869372688-a93d806be852?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1350&q=80"
            alt="Image">
        <h2 class="public">Merchant</h2>
        <img class="user-image" src="https://images.unsplash.com/photo-1580880783095-f6fdf668361e?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60"
            alt="image">
        <button class="view-sponsor">View Sponsor</button>
    </div>
    <div class="listing-details">
        <h2 class="merch-name"></h2>
        <address class="merch-address">
            123 Some St City, State 12345, US
        </address>
        <div class="contact-box">
            <div class="container contact">
                <div class="title">Phone:</div>
                <div class="info"><a href="tel:+#" class="phone">123-123-4567</a></div>
            </div>
            <div class="container contact public">
                <div class="title public">Email:</div>
                <div class="info"><a href="/cdn-cgi/l/email-protection#795a" class="email"><span class="__cf_email__" data-cfemail="ee8d81809a8f8d9aae9d9a9b839e9a819980c38c9c8b99c08d8183">[email&#160;protected]</span></a></div>
            </div>
            <div class="container contact public">
                <div class="title public">Website:</div>
                <div class="info"><a href="#" class="web">https://stumptown-brew.com</a></div>
            </div>
        </div>
        <div class="contact-box space-top">
            <div class="container contact">
                <div class="title">Participation:</div>
                <div class="info participation">100%</div>
            </div>
            <div class="container contact">
                <div class="title">Category:</div>
                <div class="info merch-category">Small Business</div>
            </div>
        </div>
        <iframe class="video-full" src="https://www.youtube.com/embed/xcJtL7QggTI" frameborder="0"
            allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen
            class="space-top hide-mobile"></iframe>
        <div class="social hide-mobile public">
            <i class="fab fa-facebook-square"></i> <a href="#" class="facebook-link">https://facebook.com/stumptown-brew</a>
        </div>
        <div class="contact-box space-top sponsor-info">
            <h2>Sponsor Information</h2>
            <div class="container contact">
                <div class="title">Name:</div>
                <div class="info s-name">Sponsor Name</div>
            </div>
            <div class="container contact">
                <div class="title">Email:</div>
                <div class="info s-email">Sponsor Email</div>
            </div>
            <div class="container contact">
                <div class="title">Phone:</div>
                <div class="info s-phone">Sponsor Phone</div>
            </div>
            <div class="container contact">
                <div class="title">Facebook:</div>
                <div class="info s-facebook">Sponsor Facebook</div>
            </div>
            <button class="hide-sponsor">Hide Sponsor</button>
        </div>
        <div class="image-overview mobile-only">
            <h2>Storefront</h2>
            <img class="store-image-m" src="https://images.unsplash.com/photo-1464869372688-a93d806be852?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1350&q=80"
                alt="Image">
            <div class="social">
                <a href="#" class="facebook-social public"><i class="fab fa-facebook-square"></i></a>
                <a href="#" class="video-m public"><i class="fas fa-video"></i></a>
            </div>
            <div class="sponsor-info">
                <h2>Sponsor Information</h2>
                <div class="container contact">
                    <div class="title">Name:</div>
                    <div class="info s-name">Sponsor Name</div>
                </div>
                <div class="container contact">
                    <div class="title">Email:</div>
                    <div class="info s-email">Sponsor Email</div>
                </div>
                <div class="container contact">
                    <div class="title">Phone:</div>
                    <div class="info s-phone">Sponsor Phone</div>
                </div>
                <div class="container contact">
                    <div class="title">Facebook:</div>
                    <div class="info s-facebook">Sponsor Facebook</div>
                </div>
                <button class="hide-sponsor">Hide Sponsor</button>
            </div>
            <button class="view-sponsor">View Sponsor</button>
        </div>
    </div>
</template></div>
<script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script src="/wsc-plugin/plugin/merchantlocations/js/customElements.js"></script>
<script src="/wsc-plugin/plugin/merchantlocations/js/searchMerchants.js?v=1.0"></script>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDhHiW-LW59jL2gbZgVT4BRx6ybuZuM6BE" async defer></script>

<div id="footer" class="nav-background-footer">

</div>
<div style="height:100px"></div> </body>
</html>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.20/js/dataTables.bootstrap4.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js"></script>
    <!-- I'm not sure if the menu is boggling this up or not. But somehow $.modal doesn't work -->
    <!-- I've just been re-importing it in my code below the include header -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
    <!-- Insure a fresh load of this each time. -->
    <script src="/code/js/_main_menu.js?random=65fad151daa3e"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootbox.js/5.4.1/bootbox.min.js"></script>

<!-- MDB -->

<!-- BEGIN PHP Live! HTML Code [V3] -->
<span style="color: #0000FF; text-decoration: underline; line-height: 0px !important; cursor: pointer; position: fixed; bottom: 0px; right: 20px; z-index: 20000000;"
      id="phplive_btn_1588501606"></span>
<script data-cfasync="false" type="text/javascript">

    (function () {
        var phplive_e_1588501606 = document.createElement("script");
        phplive_e_1588501606.type = "text/javascript";
        phplive_e_1588501606.async = true;
        phplive_e_1588501606.src = "https://support.kringle.cash/phplive/js/phplive_v2.js.php?v=0%7C1588501606%7C2%7C&";
        document.getElementById("phplive_btn_1588501606").appendChild(phplive_e_1588501606);
        if ([].filter) {
            document.getElementById("phplive_btn_1588501606").addEventListener("click", function () {
                phplive_launch_chat_0()
            });
        } else {
            document.getElementById("phplive_btn_1588501606").attachEvent("onclick", function () {
                phplive_launch_chat_0()
            });
        }
    })();

</script>
<!-- END PHP Live! HTML Code [V3] -->