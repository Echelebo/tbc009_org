<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css"
          integrity="sha384-hWVjflwFxL6sNzntih27bfxkr27PmbbK/iSvJ+a4+0owXq79v+lsFkW54bOGbiDQ" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/smoothness/jquery-ui.css">
    <link href="/content/css/style.css" rel="stylesheet"/>
    <link href="/content/css/login.css" rel="stylesheet"/>
    <title>Kringle.cash</title>
    <script type="text/javascript">
        function googleTranslateElementInit() {
            new google.translate.TranslateElement({
                pageLanguage: 'en',
                layout: google.translate.TranslateElement.InlineLayout.SIMPLE
            }, 'google_translate_element');
        }
    </script>
    <script type="text/javascript"
            src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
</head>
<body>

<nav id="TopNav" class="navbar navbar-dark bg-dark sticky-top">
    <a class="navbar-brand" href="#">
        <img id="logo" src="/content/img/SBC-75.png"/>
    </a>
    <!--<ul class="navbar-nav">
        <li class="nav-item active">
            <a class="nav-link navbar-header" href="#"><img id="logo" src="./content/img/dark_logo_50.png" /> </a>
        </li>
    </ul>-->
    <div class="navbar-expand" id="navbarNavAltMarkup">
        <div class="navbar-nav">
            <div style="margin-top: 13px;margin-right: 45px;">
                <a href="https://youtu.be/V6b5XnjrIzo" target="_blank">
                    <img src="/content/img/noitulover.png"/>
                </a>
            </div>
            <div id="google_translate_element" style="margin-top: 18px"></div>
        </div>
        <div class="navbar-nav">

        </div>


    </div>

</nav>


<div class="container text-center">
    <br>
    <img class="mb-4" src="../content/img/SBC-100.png" alt=""/>
    <br>
    <br>
    <div class="row">
        <div class="col">
            <form id="signin_form" class="form-signin">
                <div id='rkform' style="display:none">
                    Enter your current address
                    <input type="text" id="rkaddress" name="rkaddress">
                </div>

                <h1 class="h3 mb-3 font-weight-normal">Please sign in</h1>

                <div class="row">
                    <div class="col">
                        <br/><br/>
                        <div id="feedback"></div>
                    </div>
                </div>
                <label for="uiEmail" class="sr-only">Email address</label>
                <input type="text" id="uiEmail" class="form-control" placeholder="Username or Email address" required
                       autofocus/>
                <label for="uiPassword" class="sr-only">Password</label>

                <input type="password" id="uiPassword" class="form-control" placeholder="Password" required/>

                <label for="stay_logged_in">Stay Logged In for 14 days</label>&nbsp;<input type="checkbox"
                                                                                           name="stay_logged_in"
                                                                                           id="stay_logged_in"
                                                                                           value="Y">

                <button class="btn btn-lg btn-success btn-block" id="loginbtn" name="loginbtn" type="submit">Continue
                </button>
                or<br/>
                <!-- <a class='btn btn-success' href='../registration_step1.php?link=theadmin'>Register without a Sponsor</a> -->
                <a class='btn btn-success' href='../registration_form.php?link=theadmin'>Register without a Sponsor</a>

                <div class="checkbox mb-3">
                    <label>
                        <br/>
                        If you would like to make your KCBO payment and are having difficulty with facial recognition,
                        please <a href="login_bfr.php">click here</a> to login and be permitted to make payment and
                        remain on the A-Team of Mass Adoption.<br/>
                        <a href="../A-Team Payment.pdf" target="_blank">
                            Download PDF Instructions to make payment and remain on the A-Team</a>
                        <br/>
                        <hr/>
                        If you are unable to login due to password or invalid credential, please
                        <a href="https://support.kringle.cash/kcbo/reset/password/request">click here</a> to reset your
                        password.
                        <br/>
                        <a href="../pdfeducation/password reset tutorial.pdf" target="_blank">Download PDF Instructions
                            for Password Reset.</a>
                        <br/>
                        <hr/>
                        If you have having trouble with logging in using facial recognition, you can
                        <a href="https://support.kringle.cash/user/request/access">click here</a>
                        to create a help desk ticket.
                        <hr/>
                        <br/>
                        If you require password reset or to request a link for the help desk you MUST whitelist
                        kringle.cash in your email account.
                        <br/>
                        <a class="text-leftjustified" href="https://support.kringle.cash/kcbo/reset/password/request">Change
                            or Forgot Password?</a>
                        <p style="text-align:left;">NOTICE: Password reset will be an email from kringle.cash, please
                            make sure you whitelist this
                            domain BEFORE requesting the link. You may request a password link once every 24 hours. If
                            the
                            email is delayed, you have up to 48 hours to use the one time link.</p>
                        <a href="../pdfeducation/password reset tutorial.pdf" target="_blank">Download PDF Instructions
                            for Password Reset.</a>
                        <br/>
                        <hr/>
                        <br/>
                        <a class="text-leftjustified" href="https://support.kringle.cash/user/request/access">Help
                            Desk.</a>
                        <p style="text-align:left;">
                            NOTICE: Help Desk requests should be made within KCBO, if you are unable to login you can
                            create a help desk ticket with this link.
                            The request will be an email from kringle.cash, please make sure you whitelist this Domain
                            BEFORE requesting the link. You may request a help ticket only once until your ticket is
                            closed.
                            If the email is delayed, you have up to 48 hours to use the one time link.</p>
                        <a href="../pdfeducation/Email desk tutorial.pdf" target="_blank">Download PDF Instructions for
                            Help Desk By Email</a>
                        <br/>
                        <br/>
                        <hr/>
                        <br/>


                    </label>
                </div>

                <p class="mt-5 mb-3 text-muted">&copy; 2017-2023</p>
            </form>
        </div>
    </div>
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/react/16.13.1/umd/react.production.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/react-dom/16.13.1/umd/react-dom.production.min.js"></script>

<div id="footer" class="nav-background-footer">

</div>
<div style="height:100px"></div> </body>
</html>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.20/js/dataTables.bootstrap4.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js"></script>
    <!-- I'm not sure if the menu is boggling this up or not. But somehow $.modal doesn't work -->
    <!-- I've just been re-importing it in my code below the include header -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
    <!-- Insure a fresh load of this each time. -->
    <script src="/code/js/_main_menu.js?random=65fad18d0d20e"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootbox.js/5.4.1/bootbox.min.js"></script>

<!-- MDB -->

<!-- BEGIN PHP Live! HTML Code [V3] -->
<span style="color: #0000FF; text-decoration: underline; line-height: 0px !important; cursor: pointer; position: fixed; bottom: 0px; right: 20px; z-index: 20000000;"
      id="phplive_btn_1588501606"></span>
<script data-cfasync="false" type="text/javascript">

    (function () {
        var phplive_e_1588501606 = document.createElement("script");
        phplive_e_1588501606.type = "text/javascript";
        phplive_e_1588501606.async = true;
        phplive_e_1588501606.src = "https://support.kringle.cash/phplive/js/phplive_v2.js.php?v=0%7C1588501606%7C2%7C&";
        document.getElementById("phplive_btn_1588501606").appendChild(phplive_e_1588501606);
        if ([].filter) {
            document.getElementById("phplive_btn_1588501606").addEventListener("click", function () {
                phplive_launch_chat_0()
            });
        } else {
            document.getElementById("phplive_btn_1588501606").attachEvent("onclick", function () {
                phplive_launch_chat_0()
            });
        }
    })();

</script>
<!-- END PHP Live! HTML Code [V3] -->

<script src="https://www.google.com/recaptcha/api.js?render=6Lc-WwYkAAAAAPQ09GeF97hcv4c1zM706MrEUwyi"></script>

<script>
    $(".form-signin").submit(function (e) {
        e.preventDefault();
        grecaptcha.ready(function () {
            grecaptcha.execute('6Lc-WwYkAAAAAPQ09GeF97hcv4c1zM706MrEUwyi', {action: 'login'}).then(function (token) {
                console.log(token);
                $('#signin_form').prepend('<input type="hidden" name="rktoken" id="rktoken" value="' + token + '">');
                $('#signin_form').prepend('<input type="hidden" name="recaction" id="recaction" value="login">');
                //$('#signin_form').unbind('submit').submit();
                submitForm();
            });
        });
    });

    var response_token;
    // jQuery main
    $(document).ready(function () {

        $("#up-arrow-link").click(scrollToTop);
        $(window).bind('mousewheel DOMMouseScroll', function (event) {
            setStickyBackground();
        });

        // Catch the uncaught error and send it to the error_log so we can see
        // what the heck is holding up the user
        window.addEventListener('error', function (e) {
            var stack = e.error.stack;
            var message = e.error.toString();

            if (stack) {
                message += '\n' + stack;
            }

            var xhr = new XMLHttpRequest();
            xhr.open('POST', '/portal/logweberror.php', true);
            xhr.send('/home/baneofexistence/public_html/portal/login.php: javascript error: ' + message);
        });

        $(document).ajaxError(function () {
            processFail('System Error : Response has invalid format');
        });
    });

    // Scrolls page to top after refresh
    $(window).on('beforeunload', function () {
        $(window).scrollTop(0);
    });

    // scroll top top of page - called after refresh
    function scrollToTop() {
        document.body.scrollTop = 0;
        document.documentElement.scrollTop = 0;
    }

    function submitForm() {
        console.log('submitting form');
        //$(".form-signinx").submit(function (e) {

        //This is the flag that gets set if the user elects the stay logged in option
        var stayLoggedIn = "N";
        if (document.getElementById('stay_logged_in').checked) {
            var stayLoggedIn = "Y";
        } else {
            var stayLoggedIn = "N";
        }
        //Clear out any previous alerts or warnings
        $("#feedback").html('');

        var loginBtn = document.getElementById('loginbtn');
        loginBtn.disabled = true;
        loginBtn.innerHTML = 'Processing...';
        var username = $("#uiEmail").val();
        var password = $("#uiPassword").val();
        var url = '/portal/index.php';
        var token = '3bd4017318837e92a66298c7855f4427';

        console.log('making request');
        $.ajax({
            type: 'POST',
            url: '../code/ajax/_login.php',
            data: {
                username: username,
                password: password,
                token: token,
                staylog: stayLoggedIn,
                url: url,
                rrtk: $("#token").val(),
                action: "LoginHash",
                rkaction: $("#recaction").val(),
                rktoken: $("#rktoken").val(),
                rkaddress: $("#rkaddress").val()
            },
            // dataType: 'json',
            success: function (data) {
                console.log('success');
                //Try and process JSON response. If Invalid then alert the user
                //There may be system issues.
                try {
                    var jdata = JSON.parse(data);
                } catch (e) {
                    processFail('System Error : Response has invalid format', true);
                    if (e instanceof SyntaxError) {
                        extrapolateError(e, true);
                    } else {
                        extrapolateError(e, false);
                    }
                    return;
                }
                if (jdata.valid) {
                    loginBtn.innerHTML = 'LOGGED IN';
                    location.href = jdata.url;
                } else {
                    if (jdata.message && jdata.message != '') {
                        processFail(jdata.message);
                    } else {
                        processFail('A System Error has occurred. Please try again later. If the problem persists, contact support.', true);
                    }
                }

            },
            error: function (xhr, ajaxOptions, thrownError) {
                console.log('failed');
                processFail("A System Issue has occurred\"\r\n" + thrownError + "\r\n" + xhr.statusText + "\r\n" + xhr.responseText, true);
            }
        });
    }

    //Use this to get what the error is with JSON Parse fail
    function extrapolateError(error, explicit) {
        console.log(`[${explicit ? 'EXPLICIT' : 'INEXPLICIT'}] ${error.name}: ${error.message}`);
    }

    function processFail(message, logError) {
        var loginBtn = document.getElementById('loginbtn');
        //alert(message);
        $("#feedback").html("<div class='alert alert-danger' role='alert' >" + message + "</div>");
        loginBtn.innerHTML = 'LOGIN';
        loginBtn.disabled = false;

        logError = typeof logError !== 'undefined' ? logError : false;
        if (logError) {
            var xhr = new XMLHttpRequest();
            xhr.open('POST', '/portal/logweberror.php', true);
            xhr.send('/home/baneofexistence/public_html/portal/login.php: javascript error: ' + message);
        }
    }

</script>
